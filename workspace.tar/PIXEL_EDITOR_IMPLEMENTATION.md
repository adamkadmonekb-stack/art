# Реализация редактора пиксель-арта

## Обзор

Добавлен полнофункциональный редактор пиксель-арта в игру "Сортировка". Редактор позволяет создавать пиксельные изображения размером от 8×8 до 64×64 пикселей с возможностью экспорта в PNG и сохранения в пресеты.

## Архитектура

### Компонент PixelEditor

**Файл:** `src/components/PixelEditor.tsx`

Основные возможности:
- Рисование на холсте с сеткой
- 5 инструментов рисования
- Палитра из 32 цветов + выбор произвольного цвета
- Undo/Redo система
- Экспорт в PNG
- Сохранение в пресеты

### Состояние

```typescript
const [gridSize, setGridSize] = useState(16);
const [pixels, setPixels] = useState<(string | null)[][]>(
  Array(16).fill(null).map(() => Array(16).fill(null))
);
const [currentColor, setCurrentColor] = useState('#000000');
const [currentTool, setCurrentTool] = useState<Tool>('pencil');
const [brushSize, setBrushSize] = useState(1);
const [showGrid, setShowGrid] = useState(true);
const [transparentBg, setTransparentBg] = useState(true);
const [isDrawing, setIsDrawing] = useState(false);
const [history, setHistory] = useState<(string | null)[][][]>([]);
const [redoStack, setRedoStack] = useState<(string | null)[][][]>([]);
```

## Инструменты

### 1. Карандаш (pencil)
- Рисование одиночных пикселей
- Использует текущий цвет и размер кисти

### 2. Кисть (brush)
- Рисование с размером кисти (1-4 пикселя)
- Квадратная кисть N×N пикселей

### 3. Заливка (fill)
- Flood fill алгоритм
- Заполняет область одинакового цвета

### 4. Пипетка (eyedropper)
- Выбор цвета из пикселя на холсте
- Устанавливает выбранный цвет как текущий

### 5. Ластик (eraser)
- Стирание пикселей (установка в null)
- Работает с размером кисти

## Реализация рисования

### Обработка событий мыши

```typescript
const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
  const coords = getPixelCoords(e);
  if (!coords) return;

  saveToHistory();
  setIsDrawing(true);

  const { x, y } = coords;

  switch (currentTool) {
    case 'pencil':
    case 'brush':
      setPixel(x, y, currentColor);
      break;
    case 'eraser':
      setPixel(x, y, null);
      break;
    case 'fill':
      floodFill(x, y, currentColor);
      break;
    case 'eyedropper':
      if (pixels[y][x]) {
        setCurrentColor(pixels[y][x]!);
      }
      break;
  }
};
```

### Алгоритм Flood Fill

```typescript
const floodFill = (startX: number, startY: number, fillColor: string) => {
  const targetColor = pixels[startY][startX];
  if (targetColor === fillColor) return;

  const newPixels = pixels.map(row => [...row]);
  const stack = [{ x: startX, y: startY }];

  while (stack.length > 0) {
    const { x, y } = stack.pop()!;
    if (x < 0 || x >= gridSize || y < 0 || y >= gridSize) continue;
    if (newPixels[y][x] !== targetColor) continue;

    newPixels[y][x] = fillColor;
    stack.push({ x: x + 1, y });
    stack.push({ x: x - 1, y });
    stack.push({ x, y: y + 1 });
    stack.push({ x, y: y - 1 });
  }

  setPixels(newPixels);
};
```

## Undo/Redo система

### Сохранение в историю

```typescript
const saveToHistory = () => {
  setHistory([...history, pixels.map(row => [...row])]);
  setRedoStack([]);
};
```

### Отмена действия

```typescript
const undo = () => {
  if (history.length === 0) return;
  const previous = history[history.length - 1];
  setRedoStack([...redoStack, pixels.map(row => [...row])]);
  setPixels(previous);
  setHistory(history.slice(0, -1));
};
```

### Повтор действия

```typescript
const redo = () => {
  if (redoStack.length === 0) return;
  const next = redoStack[redoStack.length - 1];
  setHistory([...history, pixels.map(row => [...row])]);
  setPixels(next);
  setRedoStack(redoStack.slice(0, -1));
};
```

## Экспорт и сохранение

### Экспорт в PNG

```typescript
const exportPNG = () => {
  const canvas = document.createElement('canvas');
  const scale = 32; // Каждый пиксель = 32×32 пикселя в PNG
  canvas.width = gridSize * scale;
  canvas.height = gridSize * scale;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  if (!transparentBg) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  for (let y = 0; y < gridSize; y++) {
    for (let x = 0; x < gridSize; x++) {
      if (pixels[y][x]) {
        ctx.fillStyle = pixels[y][x]!;
        ctx.fillRect(x * scale, y * scale, scale, scale);
      }
    }
  }

  const link = document.createElement('a');
  link.download = `pixel-art-${gridSize}x${gridSize}.png`;
  link.href = canvas.toDataURL('image/png');
  link.click();
};
```

### Сохранение в пресет

```typescript
const saveToPreset = async () => {
  const canvas = document.createElement('canvas');
  canvas.width = gridSize;
  canvas.height = gridSize;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  if (!transparentBg) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  for (let y = 0; y < gridSize; y++) {
    for (let x = 0; x < gridSize; x++) {
      if (pixels[y][x]) {
        ctx.fillStyle = pixels[y][x]!;
        ctx.fillRect(x, y, 1, 1);
      }
    }
  }

  const dataURL = canvas.toDataURL('image/png');

  if (newPresetName.trim()) {
    const newPreset: EmojiPreset = {
      id: `preset_${Date.now()}`,
      name: newPresetName.trim(),
      emojis: [dataURL],
      createdAt: Date.now(),
    };
    const updatedPresets = [...emojiPresets, newPreset];
    setEmojiPresets(updatedPresets);
    await saveEmojiPresets(updatedPresets);
    setNewPresetName('');
  }

  setShowSaveModal(false);
  setToast('Картинка сохранена!');
  setTimeout(() => setToast(null), 3000);
};
```

## Палитра цветов

### Стандартная палитра (32 цвета)

```typescript
const DEFAULT_PALETTE = [
  '#000000', '#1D2B53', '#7E2553', '#008751',
  '#AB5236', '#5F574F', '#C2C3C7', '#FFF1E8',
  '#FF004D', '#FFA300', '#FFEC27', '#00E436',
  '#29ADFF', '#83769C', '#FF77A8', '#FFCCAA',
  '#291814', '#111D35', '#422136', '#125359',
  '#742F29', '#49333B', '#A28879', '#F3EF7D',
  '#BE1250', '#FF6C24', '#A8E72E', '#00B543',
  '#065AB5', '#754665', '#FF6E59', '#FF9D81',
];
```

### Выбор произвольного цвета

```typescript
<input
  type="color"
  value={currentColor}
  onChange={(e) => setCurrentColor(e.target.value)}
  className="w-full mt-2 h-8 rounded cursor-pointer"
/>
```

## Интеграция в приложение

### Добавление в главное меню

```typescript
<button onClick={onPixelEditor} className="bg-pink-600 hover:bg-pink-500 text-white font-bold text-lg px-6 py-3 rounded-xl transition-colors duration-150 mb-3">
  🎨 Редактор
</button>
```

### Рендеринг экрана

```typescript
if (screen === 'pixelEditor') {
  return (
    <PixelEditor
      onBack={() => setScreen('menu')}
      emojiPresets={emojiPresets}
      setEmojiPresets={setEmojiPresets}
    />
  );
}
```

## Особенности реализации

### 1. Рендеринг холста

Холст рендерится через Canvas API с использованием `useEffect`:

```typescript
useEffect(() => {
  const canvas = canvasRef.current;
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const cellSize = canvas.width / gridSize;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw transparent background pattern
  if (transparentBg) {
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        ctx.fillStyle = (x + y) % 2 === 0 ? '#ffffff' : '#e0e0e0';
        ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
      }
    }
  } else {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  // Draw pixels
  for (let y = 0; y < gridSize; y++) {
    for (let x = 0; x < gridSize; x++) {
      if (pixels[y][x]) {
        ctx.fillStyle = pixels[y][x]!;
        ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
      }
    }
  }

  // Draw grid
  if (showGrid) {
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= gridSize; i++) {
      ctx.beginPath();
      ctx.moveTo(i * cellSize, 0);
      ctx.lineTo(i * cellSize, canvas.height);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * cellSize);
      ctx.lineTo(canvas.width, i * cellSize);
      ctx.stroke();
    }
  }
}, [pixels, gridSize, showGrid, transparentBg]);
```

### 2. Преобразование координат мыши

```typescript
const getPixelCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
  const canvas = canvasRef.current;
  if (!canvas) return null;

  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  const x = Math.floor(((e.clientX - rect.left) * scaleX) / (canvas.width / gridSize));
  const y = Math.floor(((e.clientY - rect.top) * scaleY) / (canvas.height / gridSize));

  if (x < 0 || x >= gridSize || y < 0 || y >= gridSize) return null;
  return { x, y };
};
```

### 3. Рисование с размером кисти

```typescript
const setPixel = (x: number, y: number, color: string | null) => {
  const newPixels = pixels.map(row => [...row]);
  for (let dy = 0; dy < brushSize; dy++) {
    for (let dx = 0; dx < brushSize; dx++) {
      const px = x + dx - Math.floor(brushSize / 2);
      const py = y + dy - Math.floor(brushSize / 2);
      if (px >= 0 && px < gridSize && py >= 0 && py < gridSize) {
        newPixels[py][px] = color;
      }
    }
  }
  setPixels(newPixels);
};
```

## Использование

1. **Открытие редактора:** Нажмите кнопку "🎨 Редактор" в главном меню
2. **Выбор инструмента:** Нажмите на иконку инструмента в панели справа
3. **Выбор цвета:** Нажмите на цвет в палитре или используйте color picker
4. **Рисование:** Нажмите и перетащите мышь по холсту
5. **Изменение размера кисти:** Нажмите на кнопку размера (1-4)
6. **Изменение размера холста:** Нажмите на кнопку размера (8×8, 16×16, 32×32, 64×64)
7. **Отмена/повтор:** Используйте кнопки ↶ и ↷
8. **Экспорт PNG:** Нажмите кнопку "📥 Скачать PNG"
9. **Сохранение в пресет:** Нажмите кнопку "💾", введите название пресета и нажмите "Сохранить"

## Интеграция с другими режимами

Сохранённые в пресет изображения автоматически доступны во всех режимах игры:
- Режим "Свои картинки"
- Режим "Пазл"
- Режим "Математика" (ручной)

## Размер бандла

- До: 252.03 kB (gzip: 67.84 kB)
- После: 262.82 kB (gzip: 70.53 kB)
- Увеличение: +10.79 kB (+2.69 kB gzip)

Увеличение обусловлено добавлением компонента PixelEditor с полной функциональностью редактора.

## Файлы изменены

1. `src/components/PixelEditor.tsx` - новый компонент редактора
2. `src/App.tsx` - добавлена кнопка в меню и рендеринг экрана

## Заключение

Редактор пиксель-арта полностью интегрирован в игру и предоставляет все необходимые инструменты для создания пиксельных изображений. Изображения могут быть экспортированы в PNG или сохранены в пресеты для использования в других режимах игры.
