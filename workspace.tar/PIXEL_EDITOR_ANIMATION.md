# Реализация системы анимации в редакторе пиксель-арта

## Обзор

Реализована полноценная система анимации для редактора пиксель-арта с поддержкой множественных кадров, плеером анимации и экспортом в различных форматах.

## Реализованные функции

### 1. Система кадров (Frames)

**Состояние:**
```typescript
const [frames, setFrames] = useState<(string | null)[][][]>([
  Array(16).fill(null).map(() => Array(16).fill(null))
]);
const [currentFrame, setCurrentFrame] = useState(0);
```

**Функции управления кадрами:**
- `addFrame()` - добавляет пустой кадр
- `duplicateFrame()` - дублирует текущий кадр
- `deleteFrame()` - удаляет текущий кадр (минимум 1 кадр)
- `switchFrame(index)` - переключается на указанный кадр

**Лента кадров (Timeline):**
- Отображает миниатюры всех кадров (64×64 px)
- Активный кадр выделен синей рамкой
- Клик по кадру переключает на него
- Горизонтальная прокрутка при большом количестве кадров
- Счётчик кадров: "Кадр X из Y"

**UI ленты кадров:**
```tsx
<div className="flex gap-2 overflow-x-auto pb-2">
  {frames.map((frame, index) => (
    <button
      key={index}
      onClick={() => !isPlaying && switchFrame(index)}
      className={`flex-shrink-0 w-16 h-16 border-2 rounded overflow-hidden ${
        index === currentFrame ? 'border-blue-500 scale-110' : 'border-zinc-600'
      }`}
    >
      <canvas width={64} height={64} />
    </button>
  ))}
</div>
```

### 2. Плеер анимации

**Состояние:**
```typescript
const [isPlaying, setIsPlaying] = useState(false);
const [playbackSpeed, setPlaybackSpeed] = useState(100); // мс между кадрами
```

**Логика воспроизведения:**
```typescript
useEffect(() => {
  if (!isPlaying) return;

  const interval = setInterval(() => {
    setCurrentFrame(prev => (prev + 1) % frames.length);
  }, playbackSpeed);

  return () => clearInterval(interval);
}, [isPlaying, playbackSpeed, frames.length]);
```

**UI плеера:**
- Кнопка ▶ Просмотр / ⏸ Стоп
- Ползунок скорости: 50-500 мс
- При воспроизведении рисование отключено
- Циклическое воспроизведение

**Особенности:**
- Автоматическое переключение кадров
- Блокировка рисования во время воспроизведения
- Регулируемая скорость
- Циклическое воспроизведение

### 3. Синхронизация кадров

**Автоматическая синхронизация:**
```typescript
// При изменении pixels обновляется текущий кадр
useEffect(() => {
  const newFrames = [...frames];
  newFrames[currentFrame] = pixels.map(row => [...row]);
  setFrames(newFrames);
}, [pixels]);

// При переключении кадра загружаются его данные
useEffect(() => {
  if (isPlaying) {
    setPixels(frames[currentFrame].map(row => [...row]));
  }
}, [currentFrame, isPlaying]);
```

### 4. Экспорт анимации

#### 4.1. Экспорт текущего кадра (PNG)
```typescript
const exportPNG = () => {
  const canvas = document.createElement('canvas');
  const scale = 32;
  canvas.width = gridSize * scale;
  canvas.height = gridSize * scale;
  // ... рисование пикселей
  link.download = `pixel-art-${gridSize}x${gridSize}-frame${currentFrame + 1}.png`;
};
```

#### 4.2. Экспорт спрайт-листа
```typescript
const exportSpriteSheet = () => {
  const canvas = document.createElement('canvas');
  const scale = 32;
  const frameSize = gridSize * scale;
  canvas.width = frameSize * frames.length;
  canvas.height = frameSize;
  
  frames.forEach((frame, frameIndex) => {
    // Рисование каждого кадра в строку
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        if (frame[y][x]) {
          ctx.fillStyle = frame[y][x]!;
          ctx.fillRect(frameIndex * frameSize + x * scale, y * scale, scale, scale);
        }
      }
    }
  });
  
  link.download = `sprite-sheet-${gridSize}x${gridSize}-${frames.length}frames.png`;
};
```

**Пример:**
- 16×16 пикселей, 4 кадра
- Размер кадра: 16 × 32 = 512 px
- Итоговое изображение: 2048 × 512 px

#### 4.3. Сохранение всех кадров в пресет
```typescript
const saveAllFramesToPreset = async () => {
  const frameDataURLs: string[] = [];

  frames.forEach(frame => {
    const canvas = document.createElement('canvas');
    canvas.width = gridSize;
    canvas.height = gridSize;
    // ... рисование кадра
    frameDataURLs.push(canvas.toDataURL('image/png'));
  });

  // Сохранение в существующий или новый пресет
  if (saveMode === 'existing' && selectedPresetId) {
    updatedPresets[presetIndex] = {
      ...updatedPresets[presetIndex],
      emojis: [...updatedPresets[presetIndex].emojis, ...frameDataURLs],
    };
  } else if (saveMode === 'new' && newPresetName.trim()) {
    const newPreset: EmojiPreset = {
      id: `preset_${Date.now()}`,
      name: newPresetName.trim(),
      emojis: frameDataURLs,
      createdAt: Date.now(),
    };
    updatedPresets.push(newPreset);
  }
};
```

### 5. Хранение в localStorage

**Автоматическое сохранение:**
```typescript
useEffect(() => {
  const data = {
    frames,
    gridSize,
    fps: playbackSpeed,
  };
  localStorage.setItem('pixelEditorAnimation', JSON.stringify(data));
}, [frames, gridSize, playbackSpeed]);
```

**Автоматическая загрузка:**
```typescript
useEffect(() => {
  const saved = localStorage.getItem('pixelEditorAnimation');
  if (saved) {
    try {
      const data = JSON.parse(saved);
      if (data.frames && data.frames.length > 0) {
        setFrames(data.frames);
        setGridSize(data.gridSize || 16);
        setPlaybackSpeed(data.fps || 100);
        setPixels(data.frames[0].map((row: (string | null)[]) => [...row]));
      }
    } catch (e) {
      console.error('Failed to load animation:', e);
    }
  }
}, []);
```

**Формат данных:**
```json
{
  "frames": [
    [[null, "#000000", ...], ...],
    [[null, "#FF0000", ...], ...]
  ],
  "gridSize": 16,
  "fps": 100
}
```

### 6. Модальное окно экспорта

**Опции экспорта:**
1. 📥 Скачать текущий кадр (PNG)
2. 🎞️ Скачать спрайт-лист (все кадры в одну строку)
3. 💾 Сохранить все кадры в пресет
   - Добавить в существующий пресет
   - Создать новый пресет

**UI модального окна:**
```tsx
<div className="space-y-3">
  <button onClick={exportPNG}>
    📥 Скачать текущий кадр (PNG)
  </button>

  <button onClick={exportSpriteSheet} disabled={frames.length < 2}>
    🎞️ Скачать спрайт-лист ({frames.length} кадров)
  </button>

  <div className="border-t border-zinc-700 pt-3">
    <h3>Сохранить все кадры в пресет</h3>
    {/* Радио-кнопки для выбора режима */}
    {/* Поля для выбора/создания пресета */}
  </div>
</div>
```

## Технические детали

### Рендеринг миниатюр кадров

Каждая миниатюра рендерится через отдельный canvas:
```tsx
<canvas
  width={64}
  height={64}
  className="w-full h-full pixel-art"
  ref={(canvas) => {
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.imageSmoothingEnabled = false;
        ctx.clearRect(0, 0, 64, 64);
        const cellSize = 64 / gridSize;
        for (let y = 0; y < gridSize; y++) {
          for (let x = 0; x < gridSize; x++) {
            if (frame[y][x]) {
              ctx.fillStyle = frame[y][x]!;
              ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
            }
          }
        }
      }
    }
  }}
/>
```

### Блокировка рисования при воспроизведении

```tsx
<canvas
  className={`pixel-art ${isPlaying ? 'cursor-not-allowed' : 'cursor-crosshair'}`}
  style={{ pointerEvents: isPlaying ? 'none' : 'auto' }}
/>
```

### Оптимизация производительности

1. **Ленивый рендеринг миниатюр** - каждый canvas рендерится только при монтировании
2. **Автоматическая синхронизация** - обновление только текущего кадра
3. **Дебаунс сохранения** - сохранение в localStorage только при изменении данных

## Использование

### Создание анимации

1. Нарисуйте первый кадр
2. Нажмите "+ Добавить" для добавления нового кадра
3. Нарисуйте второй кадр
4. Повторите для создания последовательности кадров
5. Нажмите "▶ Просмотр" для воспроизведения

### Настройка скорости

1. Нажмите "▶ Просмотр"
2. Используйте ползунок "Скорость" для настройки (50-500 мс)
3. Меньшее значение = быстрее анимация

### Экспорт

1. Нажмите кнопку "📥 Экспорт"
2. Выберите вариант:
   - **Скачать текущий кадр** - экспортирует только активный кадр
   - **Скачать спрайт-лист** - все кадры в одну строку
   - **Сохранить в пресет** - все кадры как отдельные картинки

### Спрайт-лист

Формат спрайт-листа:
- Все кадры расположены в одну строку
- Каждый кадр имеет размер `gridSize × 32` пикселей
- Итоговый размер: `(gridSize × 32 × frames.length) × (gridSize × 32)`

**Пример:**
- Сетка: 16×16
- Кадров: 4
- Размер кадра: 16 × 32 = 512 px
- Итоговое изображение: 2048 × 512 px

## Проверка

### Создание анимации:
1. ✅ Нарисуйте кадр
2. ✅ Нажмите "+ Добавить"
3. ✅ Нарисуйте второй кадр
4. ✅ Повторите несколько раз
5. ✅ Лента кадров отображает все кадры

### Воспроизведение:
1. ✅ Нажмите "▶ Просмотр"
2. ✅ Кадры переключаются автоматически
3. ✅ Измените скорость ползунком
4. ✅ Нажмите "⏸ Стоп" для остановки
5. ✅ Во время воспроизведения рисование заблокировано

### Экспорт:
1. ✅ Нажмите "📥 Экспорт"
2. ✅ "Скачать текущий кадр" - работает
3. ✅ "Скачать спрайт-лист" - создаёт PNG со всеми кадрами
4. ✅ "Сохранить в пресет" - сохраняет все кадры

### Автосохранение:
1. ✅ Создайте анимацию
2. ✅ Обновите страницу
3. ✅ Анимация восстанавливается из localStorage

## Размер бандла

- До: 265.34 kB (gzip: 71.25 kB)
- После: 273.53 kB (gzip: 72.73 kB)
- Увеличение: +8.19 kB (+1.48 kB gzip)

Увеличение обусловлено добавлением системы анимации, плеера и экспорта.

## Файлы изменены

1. `src/components/PixelEditor.tsx`
   - Добавлены состояния для кадров и плеера
   - Реализованы функции управления кадрами
   - Добавлена лента кадров с миниатюрами
   - Реализован плеер анимации
   - Добавлены функции экспорта
   - Реализовано автосохранение в localStorage
   - Добавлено модальное окно экспорта

## Заключение

Реализована полноценная система анимации с:
- ✅ Управлением кадрами (добавление, дублирование, удаление, переключение)
- ✅ Плеером анимации с регулируемой скоростью
- ✅ Экспортом в различных форматах (PNG, спрайт-лист, пресет)
- ✅ Автосохранением в localStorage
- ✅ Интуитивным UI с лентой кадров

Редактор пиксель-арта теперь поддерживает создание и экспорт анимаций.
