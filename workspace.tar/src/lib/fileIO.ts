/**
 * Универсальное сохранение файлов — браузер + Android APK
 */

export async function saveFile(
  filename: string,
  content: string,
  mime: string = 'text/plain;charset=utf-8'
): Promise<void> {
  const bridge = (window as any).AndroidBridge;

  if (bridge?.saveFile) {
    try {
      await bridge.saveFile(filename, content, mime);
      return;
    } catch (e) {
      console.warn('Android bridge failed, fallback to browser:', e);
    }
  }

  // Браузер
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 100);
}

/**
 * Сохранение бинарных данных (PNG) через Android-мост
 */
export async function saveBinaryFile(
  filename: string,
  bytes: Uint8Array,
  mime: string = 'application/octet-stream'
): Promise<void> {
  const bridge = (window as any).AndroidBridge;

  if (!bridge?.beginChunkedSave) {
    // Браузер
    const blob = new Blob([bytes as unknown as BlobPart], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 100);
    return;
  }

  // Android
  const token = bridge.beginChunkedSave(filename, mime);
  if (!token) return;

  try {
    const CHUNK = 256 * 1024;
    for (let i = 0; i < bytes.length; i += CHUNK) {
      const slice = bytes.slice(i, i + CHUNK);
      let binary = '';
      for (let j = 0; j < slice.length; j++) {
        binary += String.fromCharCode(slice[j]);
      }
      const b64 = btoa(binary);
      const ok = bridge.appendChunk(token, b64);
      if (!ok) throw new Error('appendChunk failed');
    }
    bridge.finishChunkedSave(token);
  } catch (e) {
    bridge.abortChunkedSave?.(token);
    throw e;
  }
}

/**
 * Скопировать текст в буфер обмена
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // Fallback
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try {
      document.execCommand('copy');
      return true;
    } catch {
      return false;
    } finally {
      document.body.removeChild(textarea);
    }
  }
}
