/**
 * Построение сигилы — Световая Матрица Адама Кадмона
 * Финальная версия: капсулы для повторных отрезков + круги с точками
 */

import { getLetterCoords, isValidRussianLetter } from './rosaCross';

export interface SigilPoint {
  x: number; y: number; letter: string; isRepeat: boolean; originalIndex: number;
}

type Pt = { x: number; y: number };

const fmt = (n: number): string => (Math.round(n * 100) / 100).toString();
const dist = (a: Pt, b: Pt): number => Math.hypot(a.x - b.x, a.y - b.y);

const GAP = 14;              // расстояние между параллельными линиями
const R_TURN = GAP / 2;      // радиус полукруга-разворота (7)
const R_CIRCLE = 10;         // радиус круга на повторной букве

export function normalizeWord(word: string): { letters: string[]; skipped: string[] } {
  const upper = word.toUpperCase();
  const letters: string[] = [];
  const skipped: string[] = [];
  for (const ch of upper) {
    if (isValidRussianLetter(ch)) letters.push(ch);
    else if (/[A-Z0-9]/.test(ch)) { /* игнорируем */ }
    else if (ch.trim()) skipped.push(ch);
  }
  return { letters, skipped };
}

/** A→B и B→A — один ключ */
function canonical(a: SigilPoint, b: SigilPoint): [SigilPoint, SigilPoint] {
  return (a.x < b.x || (a.x === b.x && a.y <= b.y)) ? [a, b] : [b, a];
}

interface Edge {
  i: number;
  key: string;
  a: Pt; b: Pt;
  off: number;
  count: number;
  isFirst: boolean;
}

export function buildSigil(letters: string[]): {
  points: SigilPoint[];
  fullPath: string;
  startPoint: Pt;
  endPoint: Pt;
  lastDirection: Pt;
} {
  const points: SigilPoint[] = [];
  const seen = new Set<string>();
  
  for (let i = 0; i < letters.length; i++) {
    const letter = letters[i];
    const coords = getLetterCoords(letter);
    if (!coords) continue;
    points.push({ 
      x: coords.x, 
      y: coords.y, 
      letter, 
      isRepeat: seen.has(letter), 
      originalIndex: i 
    });
    seen.add(letter);
  }
  
  if (points.length < 2) {
    return { 
      points, 
      fullPath: '', 
      startPoint: points[0] || {x:0,y:0}, 
      endPoint: points[0] || {x:0,y:0}, 
      lastDirection: {x:1,y:0} 
    };
  }

  const n = points.length;
  const edges: Edge[] = [];
  const counts = new Map<string, number>();

  // Проход 1: собираем рёбра и считаем повторы
  for (let i = 0; i < n - 1; i++) {
    const a = points[i], b = points[i + 1];
    const [p, q] = canonical(a, b);
    const key = `${fmt(p.x)}:${fmt(p.y)}|${fmt(q.x)}:${fmt(q.y)}`;
    edges.push({ i, key, a, b, off: 0, count: 0, isFirst: false });
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }

  // Проход 2: распределяем смещения
  const drawn = new Map<string, number>();
  for (const e of edges) {
    const total = counts.get(e.key) ?? 1;
    e.count = total;
    const k = drawn.get(e.key) ?? 0;
    drawn.set(e.key, k + 1);
    e.isFirst = k === 0;
    e.off = (k - (total - 1) / 2) * GAP;
  }

  // Проход 3: строим путь с капсулами
  let fullPath = '';
  let startPoint: Pt = points[0];
  let endPoint: Pt = points[0];
  let lastDirection: Pt = { x: 1, y: 0 };

  // Начинаем путь
  fullPath = `M ${fmt(points[0].x)} ${fmt(points[0].y)}`;

  // Обрабатываем каждое ребро
  for (let i = 0; i < edges.length; i++) {
    const e = edges[i];
    const dx = e.b.x - e.a.x;
    const dy = e.b.y - e.a.y;
    const len = Math.hypot(dx, dy);
    
    if (len === 0) continue;
    
    const nx = -dy / len; // нормаль от канонического направления
    const ny = dx / len;

    if (e.count === 1) {
      // Обычная линия
      const fromX = e.a.x + nx * e.off;
      const fromY = e.a.y + ny * e.off;
      let toX = e.b.x + nx * e.off;
      let toY = e.b.y + ny * e.off;
      
      // Баг 3: Если следующая точка - повторная, обрезаем линию на окружности круга
      const targetPoint = points[e.i + 1];
      if (targetPoint.isRepeat) {
        // Сдвигаем конечную точку назад по направлению на радиус круга
        toX = e.b.x - (dx / len) * R_CIRCLE;
        toY = e.b.y - (dy / len) * R_CIRCLE;
      }
      
      fullPath += ` L ${fmt(toX)} ${fmt(toY)}`;
      endPoint = { x: toX, y: toY };
      lastDirection = { x: dx / len, y: dy / len };
      
    } else if (e.isFirst) {
      // Капсула: две параллельные линии + полукруги на концах
      const a1x = e.a.x + nx * (-GAP / 2);
      const a1y = e.a.y + ny * (-GAP / 2);
      const b1x = e.b.x + nx * (-GAP / 2);
      const b1y = e.b.y + ny * (-GAP / 2);
      
      const a2x = e.a.x + nx * (GAP / 2);
      const a2y = e.a.y + ny * (GAP / 2);
      const b2x = e.b.x + nx * (GAP / 2);
      const b2y = e.b.y + ny * (GAP / 2);
      
      // Полукруг на конце B
      const arcB = ` A ${R_TURN} ${R_TURN} 0 0 1 ${fmt(b2x)} ${fmt(b2y)}`;
      // Полукруг на конце A
      const arcA = ` A ${R_TURN} ${R_TURN} 0 0 1 ${fmt(a1x)} ${fmt(a1y)}`;
      
      // Замкнутый контур: A1 → B1 → (полукруг) → B2 → A2 → (полукруг)
      fullPath += ` L ${fmt(a1x)} ${fmt(a1y)}`;
      fullPath += ` L ${fmt(b1x)} ${fmt(b1y)}`;
      fullPath += arcB;
      fullPath += ` L ${fmt(a2x)} ${fmt(a2y)}`;
      fullPath += arcA;
      
      // Баг 4: Возвращаем перо в центр точки A, чтобы следующее ребро шло от центра
      fullPath += ` M ${fmt(e.a.x)} ${fmt(e.a.y)}`;
      
      endPoint = { x: e.a.x, y: e.a.y };
      lastDirection = { x: dx / len, y: dy / len };
    }
  }

  return { 
    points, 
    fullPath, 
    startPoint, 
    endPoint, 
    lastDirection 
  };
}

export function formatWord(word: string): string {
  const clean = word.trim();
  if (!clean) return '';
  return clean.charAt(0).toUpperCase() + clean.slice(1).toLowerCase();
}

export function buildNormalizedString(letters: string[]): string {
  const seen = new Set<string>();
  return letters.map((letter, i) => {
    if (i === 0) { seen.add(letter); return letter; }
    if (seen.has(letter)) return `${letter}*`;
    seen.add(letter);
    return letter;
  }).join(' → ');
}
