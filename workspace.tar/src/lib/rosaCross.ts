/**
 * Световая Матрица Адама Кадмона
 * 4 уровня колец с буквами русского алфавита
 */

export type Ring = 'outer' | 'middle' | 'inner' | 'center';

export interface RingConfig {
  letters: string[];
  radius: number;
  total: number;
}

export const RINGS: Record<Ring, RingConfig> = {
  outer: {
    letters: ['А', 'Е', 'Р', 'И', 'Н', 'М', 'С', 'К', 'Х', 'Т', 'Я'],
    radius: 195, // Центр между 160 и 230: (160 + 230) / 2
    total: 11,
  },
  middle: {
    letters: ['О', 'Ф', 'У', 'Л', 'Д', 'В', 'П', 'Б', 'З', 'Ц', 'Ш'],
    radius: 125, // Центр между 90 и 160: (90 + 160) / 2
    total: 11,
  },
  inner: {
    letters: ['Г', 'Й', 'Э', 'Ж', 'Ь', 'Ч'],
    radius: 60, // Центр между 30 и 90: (30 + 90) / 2
    total: 6,
  },
  center: {
    letters: ['Ё', 'Щ', 'Ъ', 'Ы', 'Ю'],
    radius: 15, // Уменьшено для плотной группки в центре
    total: 5,
  },
};

// Радиусы окружностей для отрисовки матрицы
export const RING_BOUNDARIES = {
  outer: 230,
  middle: 160,
  inner: 90,
  center: 30,
};

export const CENTER = { x: 300, y: 300 };

/**
 * Найти букву в матрице
 */
export function findLetter(letter: string): { ring: Ring; index: number } | null {
  const upper = letter.toUpperCase();
  for (const ring of ['outer', 'middle', 'inner', 'center'] as Ring[]) {
    const idx = RINGS[ring].letters.indexOf(upper);
    if (idx !== -1) {
      return { ring, index: idx };
    }
  }
  return null;
}

/**
 * Координаты буквы — центрированы в секторе
 * Формула: angle = (index * sectorAngle) + (sectorAngle / 2) - 90
 * где sectorAngle = 360 / total
 * 
 * ВАЖНО: Это отличается от формулы для линий секторов!
 * Линии секторов: angle = i * sectorAngle - 90 (границы секторов)
 * Буквы: angle = i * sectorAngle + sectorAngle/2 - 90 (центры секторов)
 */
export function getLetterCoords(letter: string): { x: number; y: number; ring: Ring; index: number } | null {
  const found = findLetter(letter);
  if (!found) return null;

  const config = RINGS[found.ring];
  const sectorAngle = 360 / config.total;
  
  // Буква центрирована в секторе: добавляем половину угла сектора
  const letterAngle = (found.index * sectorAngle) + (sectorAngle / 2) - 90;
  const rad = (letterAngle * Math.PI) / 180;

  return {
    x: CENTER.x + config.radius * Math.cos(rad),
    y: CENTER.y + config.radius * Math.sin(rad),
    ring: found.ring,
    index: found.index,
  };
}

/**
 * Проверить, есть ли буква на матрице
 */
export function isOnMatrix(letter: string): boolean {
  return findLetter(letter) !== null;
}

/**
 * Все буквы матрицы (33 буквы русского алфавита)
 */
export const ALL_MATRIX_LETTERS: string[] = [
  ...RINGS.outer.letters,
  ...RINGS.middle.letters,
  ...RINGS.inner.letters,
  ...RINGS.center.letters,
];

/**
 * Проверить, является ли буква валидной (А-Я, Ё)
 */
export function isValidRussianLetter(ch: string): boolean {
  const code = ch.charCodeAt(0);
  // А-Я: 1040-1071, Ё: 1025, ё: 1105
  return (code >= 1040 && code <= 1071) || code === 1025 || code === 1105;
}
