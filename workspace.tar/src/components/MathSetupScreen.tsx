import { useState } from 'react';
import { EmojiPreset } from '../game/types';

interface MathSetupScreenProps {
  onStart: (operations: string[], difficulty: 'easy' | 'medium' | 'hard', mode: 'auto' | 'manual', presetId?: string, squareSize?: number, slotCount?: number) => void;
  onBack: () => void;
  emojiPresets: EmojiPreset[];
  initialPresetId?: string | null;
  initialSquareSize?: number;
  initialSlotCount?: number;
}

export default function MathSetupScreen({ onStart, onBack, emojiPresets, initialPresetId, initialSquareSize, initialSlotCount }: MathSetupScreenProps) {
  const [operations, setOperations] = useState<string[]>(['+', '-']);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('easy');
  const [mode, setMode] = useState<'auto' | 'manual'>('auto');
  const [selectedPreset, setSelectedPreset] = useState<string | null>(initialPresetId || null);
  const [squareSize, setSquareSize] = useState(initialSquareSize || 100);
  const [slotCount, setSlotCount] = useState(initialSlotCount || 12);
  
  const toggleOperation = (op: string) => {
    if (operations.includes(op)) {
      setOperations(operations.filter(o => o !== op));
    } else {
      setOperations([...operations, op]);
    }
  };
  
  const handleStart = () => {
    if (mode === 'auto' && operations.length === 0) {
      alert('Выберите хотя бы одну операцию!');
      return;
    }
    if (mode === 'manual' && !selectedPreset) {
      alert('Выберите пресет для ручного режима!');
      return;
    }
    onStart(operations, difficulty, mode, selectedPreset || undefined, squareSize, slotCount);
  };
  
  return (
    <div className="w-full h-full bg-gradient-to-b from-zinc-900 to-zinc-800 flex flex-col items-center p-6 overflow-y-auto">
      <h1 className="text-3xl font-bold text-white mb-6">🔢 Настройка математики</h1>
      
      <div className="max-w-md w-full space-y-6">
        {/* Game Mode */}
        <div className="bg-zinc-800 rounded-xl p-4">
          <h2 className="text-white font-semibold mb-3">Режим игры:</h2>
          <div className="flex gap-3">
            <button
              onClick={() => setMode('auto')}
              className={`flex-1 p-3 rounded-xl transition-colors duration-150 ${
                mode === 'auto'
                  ? 'bg-orange-600 text-white'
                  : 'bg-zinc-700 text-zinc-300'
              }`}
            >
              <div className="text-2xl mb-1">🤖</div>
              <div className="font-medium">Авто</div>
              <div className="text-xs opacity-80">Генерация примеров</div>
            </button>
            <button
              onClick={() => setMode('manual')}
              className={`flex-1 p-3 rounded-xl transition-colors duration-150 ${
                mode === 'manual'
                  ? 'bg-orange-600 text-white'
                  : 'bg-zinc-700 text-zinc-300'
              }`}
            >
              <div className="text-2xl mb-1">✋</div>
              <div className="font-medium">Ручной</div>
              <div className="text-xs opacity-80">Конструктор</div>
            </button>
          </div>
        </div>
        
        {/* Auto mode settings */}
        {mode === 'auto' && (
          <>
            {/* Operations */}
            <div className="bg-zinc-800 rounded-xl p-4">
              <h2 className="text-white font-semibold mb-3">Операции:</h2>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => toggleOperation('+')}
                  className={`p-4 rounded-xl text-2xl font-bold transition-colors duration-150 ${
                    operations.includes('+')
                      ? 'bg-green-600 text-white'
                      : 'bg-zinc-700 text-zinc-400'
                  }`}
                >
                  + Сложение
                </button>
                <button
                  onClick={() => toggleOperation('-')}
                  className={`p-4 rounded-xl text-2xl font-bold transition-colors duration-150 ${
                    operations.includes('-')
                      ? 'bg-green-600 text-white'
                      : 'bg-zinc-700 text-zinc-400'
                  }`}
                >
                  − Вычитание
                </button>
                <button
                  onClick={() => toggleOperation('×')}
                  className={`p-4 rounded-xl text-2xl font-bold transition-colors duration-150 ${
                    operations.includes('×')
                      ? 'bg-green-600 text-white'
                      : 'bg-zinc-700 text-zinc-400'
                  }`}
                >
                  × Умножение
                </button>
                <button
                  onClick={() => toggleOperation('÷')}
                  className={`p-4 rounded-xl text-2xl font-bold transition-colors duration-150 ${
                    operations.includes('÷')
                      ? 'bg-green-600 text-white'
                      : 'bg-zinc-700 text-zinc-400'
                  }`}
                >
                  ÷ Деление
                </button>
              </div>
            </div>
            
            {/* Difficulty */}
            <div className="bg-zinc-800 rounded-xl p-4">
              <h2 className="text-white font-semibold mb-3">Сложность:</h2>
              <div className="space-y-2">
                <button
                  onClick={() => setDifficulty('easy')}
                  className={`w-full p-3 rounded-xl text-left transition-colors duration-150 ${
                    difficulty === 'easy'
                      ? 'bg-blue-600 text-white'
                      : 'bg-zinc-700 text-zinc-300'
                  }`}
                >
                  <div className="font-semibold">Легко</div>
                  <div className="text-sm opacity-80">Числа от 1 до 10</div>
                </button>
                <button
                  onClick={() => setDifficulty('medium')}
                  className={`w-full p-3 rounded-xl text-left transition-colors duration-150 ${
                    difficulty === 'medium'
                      ? 'bg-blue-600 text-white'
                      : 'bg-zinc-700 text-zinc-300'
                  }`}
                >
                  <div className="font-semibold">Средне</div>
                  <div className="text-sm opacity-80">Числа от 10 до 100</div>
                </button>
                <button
                  onClick={() => setDifficulty('hard')}
                  className={`w-full p-3 rounded-xl text-left transition-colors duration-150 ${
                    difficulty === 'hard'
                      ? 'bg-blue-600 text-white'
                      : 'bg-zinc-700 text-zinc-300'
                  }`}
                >
                  <div className="font-semibold">Сложно</div>
                  <div className="text-sm opacity-80">Числа от 100 до 1000 (только + и −)</div>
                </button>
              </div>
            </div>
          </>
        )}
        
        {/* Manual mode settings */}
        {mode === 'manual' && (
          <>
            {/* Preset selection */}
            <div className="bg-zinc-800 rounded-xl p-4">
              <h2 className="text-white font-semibold mb-3">Выберите пресет:</h2>
              {emojiPresets.length === 0 ? (
                <div className="text-zinc-400 text-center py-4">
                  <p>Нет сохранённых пресетов</p>
                  <p className="text-sm mt-2">Создайте пресет в разделе «Пресеты изображений»</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {emojiPresets.map(preset => (
                    <button
                      key={preset.id}
                      onClick={() => setSelectedPreset(preset.id)}
                      className={`w-full p-3 rounded-lg text-left transition-colors duration-150 ${
                        selectedPreset === preset.id
                          ? 'bg-orange-600 text-white'
                          : 'bg-zinc-700 text-zinc-300 hover:bg-zinc-600'
                      }`}
                    >
                      <div className="font-medium">{preset.name}</div>
                      <div className="text-xs opacity-80 mt-1">{preset.emojis.length} картинок</div>
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            {/* Slot count selection */}
            <div className="bg-zinc-800 rounded-xl p-4">
              <h2 className="text-white font-semibold mb-3">Количество квадратиков в ряду:</h2>
              <div className="grid grid-cols-5 gap-2">
                {[8, 12, 16, 20, 24].map(count => (
                  <button
                    key={count}
                    onClick={() => setSlotCount(count)}
                    className={`p-3 rounded-xl text-lg font-bold transition-colors duration-150 ${
                      slotCount === count
                        ? 'bg-orange-600 text-white'
                        : 'bg-zinc-700 text-zinc-300 hover:bg-zinc-600'
                    }`}
                  >
                    {count}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Square size slider */}
            <div className="bg-zinc-800 rounded-xl p-4">
              <h2 className="text-white font-semibold mb-3">Размер квадратиков: {squareSize}%</h2>
              <input
                type="range"
                min={50}
                max={200}
                step={10}
                value={squareSize}
                onChange={(e) => setSquareSize(Number(e.target.value))}
                className="w-full h-2 bg-zinc-600 rounded-lg appearance-none cursor-pointer accent-orange-500"
              />
              <div className="flex justify-between text-xs text-zinc-400 mt-1">
                <span>50%</span>
                <span>200%</span>
              </div>
            </div>
          </>
        )}
        
        {/* Buttons */}
        <div className="flex gap-3">
          <button
            onClick={onBack}
            className="bg-zinc-700 hover:bg-zinc-600 text-white px-5 py-3 rounded-xl transition-colors duration-150"
          >
            ← Назад
          </button>
          <button
            onClick={handleStart}
            className="flex-1 bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
          >
            ▶ Начать
          </button>
        </div>
      </div>
    </div>
  );
}
