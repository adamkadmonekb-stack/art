// dist/gif.js обращается к navigator.userAgent на этапе импорта (browser.coffee).
// Vite pre-bundling может выполнять модуль вне браузерного контекста,
// поэтому подставляем заглушку, если navigator отсутствует.
const g = globalThis as unknown as { navigator?: { userAgent: string; platform: string } };
if (!g.navigator) {
  g.navigator = { userAgent: 'mozilla', platform: '' };
}

export {};
