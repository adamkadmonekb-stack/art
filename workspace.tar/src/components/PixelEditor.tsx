import { useState, useRef, useEffect } from 'react';
import { EmojiPreset } from '../game/types';
import { saveEmojiPresets } from '../game/storage';

interface PixelEditorProps {
  onBack: () => void;
  emojiPresets: EmojiPreset[];
  setEmojiPresets: (presets: EmojiPreset[]) => void;
}

type Tool = 'brush' | 'fill' | 'eyedropper' | 'eraser';

const DEFAULT_PALETTE = [
  '#000000', '#1D2B53', '#7E2553', '#008751',
  '#AB5236', '#5F574F', '#C2C3C7', '#FFF1E8',
  '#FF004D', '#FFA300', '#FFEC27', '#00E436',
  '#29ADFF', '#83769C', '#FF77A8', '#FFCCAA',
  '#291814', '#111D35', '#422136', '#125359',
  '#742F29', '#49333B', '#A28879', '#F3EF7D',
  '#BE1250', '#FF6C24', '#A8E72E', '#00B543',
  '#065AB5', '#754665', '#FF6E59', '#FF9D81',
];

export default function PixelEditor({ onBack, emojiPresets, setEmojiPresets }: PixelEditorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gridSize, setGridSize] = useState(16);
  const [pixels, setPixels] = useState<(string | null)[][]>(
    Array(16).fill(null).map(() => Array(16).fill(null))
  );
  const [currentColor, setCurrentColor] = useState('#000000');
  const [currentTool, setCurrentTool] = useState<Tool>('brush');
  const [brushSize, setBrushSize] = useState(1);
  const [showGrid, setShowGrid] = useState(true);
  const [transparentBg, setTransparentBg] = useState(true);
  const [isDrawing, setIsDrawing] = useState(false);
  const [history, setHistory] = useState<(string | null)[][][]>([]);
  const [redoStack, setRedoStack] = useState<(string | null)[][][]>([]);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [newPresetName, setNewPresetName] = useState('');
  const [saveMode, setSaveMode] = useState<'existing' | 'new'>('existing');
  const [selectedPresetId, setSelectedPresetId] = useState<string>('');
  const [toast, setToast] = useState<string | null>(null);
  
  // Анимация
  const [frames, setFrames] = useState<(string | null)[][][]>([
    Array(16).fill(null).map(() => Array(16).fill(null))
  ]);
  const [currentFrame, setCurrentFrame] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(100); // мс между кадрами
  const [showExportModal, setShowExportModal] = useState(false);

  // Синхронизация pixels с frames
  useEffect(() => {
    const newFrames = [...frames];
    newFrames[currentFrame] = pixels.map(row => [...row]);
    setFrames(newFrames);
  }, [pixels]);

  // Загрузка из localStorage
  useEffect(() => {
    const saved = localStorage.getItem('pixelEditorAnimation');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        if (data.frames && data.frames.length > 0) {
          setFrames(data.frames);
          setGridSize(data.gridSize || 16);
          setPlaybackSpeed(data.fps || 100);
          setPixels(data.frames[0].map((row: (string | null)[]) => [...row]));
        }
      } catch (e) {
        console.error('Failed to load animation:', e);
      }
    }
  }, []);

  // Сохранение в localStorage
  useEffect(() => {
    const data = {
      frames,
      gridSize,
      fps: playbackSpeed,
    };
    localStorage.setItem('pixelEditorAnimation', JSON.stringify(data));
  }, [frames, gridSize, playbackSpeed]);

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // БАГ 4 FIX: Отключаем сглаживание для резких пикселей
    ctx.imageSmoothingEnabled = false;

    const cellSize = canvas.width / gridSize;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // БАГ 7 FIX: НЕ рисуем шахматный фон на canvas - он только в CSS
    // Canvas остаётся прозрачным

    // Draw pixels
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        if (pixels[y][x]) {
          ctx.fillStyle = pixels[y][x]!;
          ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
        }
      }
    }

    // Draw grid
    if (showGrid) {
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
      ctx.lineWidth = 1;
      for (let i = 0; i <= gridSize; i++) {
        ctx.beginPath();
        ctx.moveTo(i * cellSize, 0);
        ctx.lineTo(i * cellSize, canvas.height);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, i * cellSize);
        ctx.lineTo(canvas.width, i * cellSize);
        ctx.stroke();
      }
    }
  }, [pixels, gridSize, showGrid]);

  const saveToHistory = () => {
    setHistory([...history, pixels.map(row => [...row])]);
    setRedoStack([]);
  };

  const undo = () => {
    if (history.length === 0) return;
    const previous = history[history.length - 1];
    setRedoStack([...redoStack, pixels.map(row => [...row])]);
    setPixels(previous);
    setHistory(history.slice(0, -1));
  };

  const redo = () => {
    if (redoStack.length === 0) return;
    const next = redoStack[redoStack.length - 1];
    setHistory([...history, pixels.map(row => [...row])]);
    setPixels(next);
    setRedoStack(redoStack.slice(0, -1));
  };

  const getPixelCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const x = Math.floor(((e.clientX - rect.left) * scaleX) / (canvas.width / gridSize));
    const y = Math.floor(((e.clientY - rect.top) * scaleY) / (canvas.height / gridSize));

    if (x < 0 || x >= gridSize || y < 0 || y >= gridSize) return null;
    return { x, y };
  };

  const setPixel = (x: number, y: number, color: string | null) => {
    const newPixels = pixels.map(row => [...row]);
    for (let dy = 0; dy < brushSize; dy++) {
      for (let dx = 0; dx < brushSize; dx++) {
        const px = x + dx - Math.floor(brushSize / 2);
        const py = y + dy - Math.floor(brushSize / 2);
        if (px >= 0 && px < gridSize && py >= 0 && py < gridSize) {
          newPixels[py][px] = color;
        }
      }
    }
    setPixels(newPixels);
  };

  const floodFill = (startX: number, startY: number, fillColor: string) => {
    const targetColor = pixels[startY][startX];
    if (targetColor === fillColor) return;

    const newPixels = pixels.map(row => [...row]);
    const stack = [{ x: startX, y: startY }];

    while (stack.length > 0) {
      const { x, y } = stack.pop()!;
      if (x < 0 || x >= gridSize || y < 0 || y >= gridSize) continue;
      if (newPixels[y][x] !== targetColor) continue;

      newPixels[y][x] = fillColor;
      stack.push({ x: x + 1, y });
      stack.push({ x: x - 1, y });
      stack.push({ x, y: y + 1 });
      stack.push({ x, y: y - 1 });
    }

    setPixels(newPixels);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const coords = getPixelCoords(e);
    if (!coords) return;

    saveToHistory();
    setIsDrawing(true);

    const { x, y } = coords;

    switch (currentTool) {
      case 'brush':
        setPixel(x, y, currentColor);
        break;
      case 'eraser':
        setPixel(x, y, null);
        break;
      case 'fill':
        floodFill(x, y, currentColor);
        break;
      case 'eyedropper':
        if (pixels[y][x]) {
          setCurrentColor(pixels[y][x]!);
        }
        break;
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const coords = getPixelCoords(e);
    if (!coords) return;

    const { x, y } = coords;

    if (currentTool === 'brush') {
      setPixel(x, y, currentColor);
    } else if (currentTool === 'eraser') {
      setPixel(x, y, null);
    }
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
  };

  const changeGridSize = (newSize: number) => {
    if (pixels.some(row => row.some(p => p !== null))) {
      if (!confirm('Очистить холст?')) return;
    }
    setGridSize(newSize);
    const emptyFrame = Array(newSize).fill(null).map(() => Array(newSize).fill(null));
    setPixels(emptyFrame);
    setFrames([emptyFrame]);
    setCurrentFrame(0);
    setHistory([]);
    setRedoStack([]);
  };

  // Управление кадрами
  const addFrame = () => {
    const emptyFrame = Array(gridSize).fill(null).map(() => Array(gridSize).fill(null));
    setFrames([...frames, emptyFrame]);
    setCurrentFrame(frames.length);
    setPixels(emptyFrame);
  };

  const duplicateFrame = () => {
    const duplicated = frames[currentFrame].map(row => [...row]);
    setFrames([...frames, duplicated]);
    setCurrentFrame(frames.length);
    setPixels(duplicated);
  };

  const deleteFrame = () => {
    if (frames.length <= 1) return;
    const newFrames = frames.filter((_, i) => i !== currentFrame);
    setFrames(newFrames);
    const newCurrentFrame = Math.min(currentFrame, newFrames.length - 1);
    setCurrentFrame(newCurrentFrame);
    setPixels(newFrames[newCurrentFrame].map(row => [...row]));
  };

  const switchFrame = (index: number) => {
    setCurrentFrame(index);
    setPixels(frames[index].map(row => [...row]));
    setHistory([]);
    setRedoStack([]);
  };

  // Плеер анимации
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setCurrentFrame(prev => (prev + 1) % frames.length);
    }, playbackSpeed);

    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed, frames.length]);

  useEffect(() => {
    if (isPlaying) {
      setPixels(frames[currentFrame].map(row => [...row]));
    }
  }, [currentFrame, isPlaying]);

  const exportPNG = () => {
    const canvas = document.createElement('canvas');
    const scale = 32;
    canvas.width = gridSize * scale;
    canvas.height = gridSize * scale;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.imageSmoothingEnabled = false;

    if (!transparentBg) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        if (pixels[y][x]) {
          ctx.fillStyle = pixels[y][x]!;
          ctx.fillRect(x * scale, y * scale, scale, scale);
        }
      }
    }

    const link = document.createElement('a');
    link.download = `pixel-art-${gridSize}x${gridSize}-frame${currentFrame + 1}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const exportSpriteSheet = () => {
    const canvas = document.createElement('canvas');
    const scale = 32;
    const frameSize = gridSize * scale;
    canvas.width = frameSize * frames.length;
    canvas.height = frameSize;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.imageSmoothingEnabled = false;

    if (!transparentBg) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    frames.forEach((frame, frameIndex) => {
      for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
          if (frame[y][x]) {
            ctx.fillStyle = frame[y][x]!;
            ctx.fillRect(frameIndex * frameSize + x * scale, y * scale, scale, scale);
          }
        }
      }
    });

    const link = document.createElement('a');
    link.download = `sprite-sheet-${gridSize}x${gridSize}-${frames.length}frames.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const saveAllFramesToPreset = async () => {
    const frameDataURLs: string[] = [];

    console.log('Saving preset with frames:', frames.length, 'frames');

    frames.forEach((frame, index) => {
      const canvas = document.createElement('canvas');
      canvas.width = gridSize;
      canvas.height = gridSize;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.imageSmoothingEnabled = false;

      if (!transparentBg) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
          if (frame[y][x]) {
            ctx.fillStyle = frame[y][x]!;
            ctx.fillRect(x, y, 1, 1);
          }
        }
      }

      const dataURL = canvas.toDataURL('image/png');
      frameDataURLs.push(dataURL);
      console.log(`Frame ${index + 1} saved, dataURL length: ${dataURL.length}`);
    });

    console.log('Total frames to save:', frameDataURLs.length);

    let updatedPresets = [...emojiPresets];

    if (saveMode === 'existing' && selectedPresetId) {
      const presetIndex = updatedPresets.findIndex(p => p.id === selectedPresetId);
      if (presetIndex !== -1) {
        updatedPresets[presetIndex] = {
          ...updatedPresets[presetIndex],
          emojis: [...updatedPresets[presetIndex].emojis, ...frameDataURLs],
        };
        console.log('Added to existing preset:', updatedPresets[presetIndex].name, 'Total emojis:', updatedPresets[presetIndex].emojis.length);
      }
    } else if (saveMode === 'new' && newPresetName.trim()) {
      const newPreset: EmojiPreset = {
        id: `preset_${Date.now()}`,
        name: newPresetName.trim(),
        emojis: frameDataURLs,
        createdAt: Date.now(),
      };
      updatedPresets.push(newPreset);
      console.log('Created new preset:', newPreset.name, 'with', newPreset.emojis.length, 'emojis');
    }

    setEmojiPresets(updatedPresets);
    await saveEmojiPresets(updatedPresets);
    setNewPresetName('');
    setSelectedPresetId('');

    setShowExportModal(false);
    setToast(`${frameDataURLs.length} кадров сохранено!`);
    setTimeout(() => setToast(null), 3000);
  };

  const saveToPreset = async () => {
    const canvas = document.createElement('canvas');
    canvas.width = gridSize;
    canvas.height = gridSize;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // БАГ 4 FIX: Отключаем сглаживание
    ctx.imageSmoothingEnabled = false;

    // БАГ 7 FIX: НЕ рисуем шахматный фон - только пиксели
    if (!transparentBg) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        if (pixels[y][x]) {
          ctx.fillStyle = pixels[y][x]!;
          ctx.fillRect(x, y, 1, 1);
        }
      }
    }

    const dataURL = canvas.toDataURL('image/png');

    // БАГ 6 FIX: Сохранение в существующий или новый пресет
    let updatedPresets = [...emojiPresets];

    if (saveMode === 'existing' && selectedPresetId) {
      // Добавляем в существующий пресет
      const presetIndex = updatedPresets.findIndex(p => p.id === selectedPresetId);
      if (presetIndex !== -1) {
        updatedPresets[presetIndex] = {
          ...updatedPresets[presetIndex],
          emojis: [...updatedPresets[presetIndex].emojis, dataURL],
        };
      }
    } else if (saveMode === 'new' && newPresetName.trim()) {
      // Создаём новый пресет
      const newPreset: EmojiPreset = {
        id: `preset_${Date.now()}`,
        name: newPresetName.trim(),
        emojis: [dataURL],
        createdAt: Date.now(),
      };
      updatedPresets.push(newPreset);
    }

    setEmojiPresets(updatedPresets);
    await saveEmojiPresets(updatedPresets);
    setNewPresetName('');
    setSelectedPresetId('');

    setShowSaveModal(false);
    setToast('Картинка сохранена!');
    setTimeout(() => setToast(null), 3000);
  };

  return (
    <div className="w-full h-full bg-gradient-to-b from-zinc-900 to-zinc-800 flex flex-col p-4 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <button
          onClick={onBack}
          className="bg-zinc-700 hover:bg-zinc-600 text-white px-4 py-2 rounded-xl transition-colors duration-150"
        >
          ← Назад
        </button>
        <h1 className="text-2xl font-bold text-white">🎨 Редактор пиксель-арта</h1>
        <button
          onClick={() => {
            setShowSaveModal(true);
            // БАГ 6 FIX: Устанавливаем режим по умолчанию
            setSaveMode(emojiPresets.length > 0 ? 'existing' : 'new');
            if (emojiPresets.length > 0) {
              setSelectedPresetId(emojiPresets[0].id);
            }
          }}
          className="bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded-xl transition-colors duration-150"
        >
          💾
        </button>
      </div>

      <div className="flex gap-4 flex-1">
        {/* Canvas */}
        <div className="flex-1 flex flex-col items-center">
          {/* Плеер анимации */}
          <div className="w-[512px] mb-2 flex items-center gap-2 bg-zinc-800 rounded-xl p-2">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              disabled={frames.length < 2}
              className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                isPlaying
                  ? 'bg-red-600 hover:bg-red-500 text-white'
                  : 'bg-green-600 hover:bg-green-500 text-white'
              } disabled:bg-zinc-600 disabled:cursor-not-allowed`}
            >
              {isPlaying ? '⏸ Стоп' : '▶ Просмотр'}
            </button>
            <div className="flex-1 flex items-center gap-2">
              <span className="text-zinc-400 text-xs">Скорость:</span>
              <input
                type="range"
                min="50"
                max="500"
                step="50"
                value={playbackSpeed}
                onChange={(e) => setPlaybackSpeed(Number(e.target.value))}
                disabled={isPlaying}
                className="flex-1 h-2 bg-zinc-600 rounded-lg appearance-none cursor-pointer accent-blue-500 disabled:opacity-50"
              />
              <span className="text-zinc-400 text-xs w-12">{playbackSpeed}мс</span>
            </div>
          </div>

          <div
            className="border-2 border-zinc-600 rounded-lg overflow-hidden"
            style={{
              width: '512px',
              height: '512px',
              backgroundImage: transparentBg
                ? 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)'
                : 'none',
              backgroundSize: '20px 20px',
              backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px',
              backgroundColor: transparentBg ? '#fff' : '#fff',
            }}
          >
            <canvas
              ref={canvasRef}
              width={512}
              height={512}
              className={`pixel-art ${isPlaying ? 'cursor-not-allowed' : 'cursor-crosshair'}`}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              style={{ pointerEvents: isPlaying ? 'none' : 'auto' }}
            />
          </div>

          {/* Лента кадров */}
          <div className="w-[512px] mt-2 bg-zinc-800 rounded-xl p-3">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-zinc-400 text-xs font-semibold">КАДРЫ:</span>
              <div className="flex-1" />
              <button
                onClick={addFrame}
                className="px-2 py-1 bg-green-600 hover:bg-green-500 text-white text-xs rounded transition-colors"
              >
                + Добавить
              </button>
              <button
                onClick={duplicateFrame}
                className="px-2 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs rounded transition-colors"
              >
                📄 Дубл.
              </button>
              <button
                onClick={deleteFrame}
                disabled={frames.length <= 1}
                className="px-2 py-1 bg-red-600 hover:bg-red-500 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white text-xs rounded transition-colors"
              >
                🗑 Удалить
              </button>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2">
              {frames.map((frame, index) => (
                <button
                  key={index}
                  onClick={() => !isPlaying && switchFrame(index)}
                  disabled={isPlaying}
                  className={`flex-shrink-0 w-16 h-16 border-2 rounded overflow-hidden transition-all ${
                    index === currentFrame
                      ? 'border-blue-500 scale-110'
                      : 'border-zinc-600 hover:border-zinc-500'
                  } ${isPlaying ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                  style={{
                    backgroundImage: transparentBg
                      ? 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)'
                      : 'none',
                    backgroundSize: '8px 8px',
                    backgroundPosition: '0 0, 0 4px, 4px -4px, -4px 0px',
                    backgroundColor: '#fff',
                  }}
                >
                  <canvas
                    width={64}
                    height={64}
                    className="w-full h-full pixel-art"
                    ref={(canvas) => {
                      if (canvas) {
                        const ctx = canvas.getContext('2d');
                        if (ctx) {
                          ctx.imageSmoothingEnabled = false;
                          ctx.clearRect(0, 0, 64, 64);
                          const cellSize = 64 / gridSize;
                          for (let y = 0; y < gridSize; y++) {
                            for (let x = 0; x < gridSize; x++) {
                              if (frame[y][x]) {
                                ctx.fillStyle = frame[y][x]!;
                                ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
                              }
                            }
                          }
                        }
                      }
                    }}
                  />
                </button>
              ))}
            </div>
            <div className="text-zinc-400 text-xs mt-1">
              Кадр {currentFrame + 1} из {frames.length}
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="w-64 space-y-4">
          {/* Palette - сверху */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Палитра:</label>
            <div className="grid grid-cols-8 gap-1">
              {DEFAULT_PALETTE.map((color, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentColor(color)}
                  className={`w-6 h-6 rounded border-2 transition-transform ${
                    currentColor === color ? 'border-white scale-110' : 'border-zinc-600'
                  }`}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
            <input
              type="color"
              value={currentColor}
              onChange={(e) => setCurrentColor(e.target.value)}
              className="w-full mt-2 h-8 rounded cursor-pointer"
            />
          </div>

          {/* Current color - снизу */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Текущий цвет:</label>
            <div
              className="w-full h-12 rounded-lg border-2 border-zinc-600"
              style={{ backgroundColor: currentColor }}
            />
          </div>

          {/* Tools */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Инструменты:</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setCurrentTool('brush')}
                className={`p-2 rounded-lg transition-colors ${
                  currentTool === 'brush' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Кисть"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M9.06 11.9l8.07-8.06a2.85 2.85 0 114.03 4.03l-8.06 8.08"/>
                  <path d="M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 00-3-3.02z"/>
                </svg>
              </button>
              <button
                onClick={() => setCurrentTool('fill')}
                className={`p-2 rounded-lg transition-colors ${
                  currentTool === 'fill' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Заливка"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M2.5 16.5c0-2 1.5-3.5 3.5-3.5s3.5 1.5 3.5 3.5-1.5 3.5-3.5 3.5-3.5-1.5-3.5-3.5z"/>
                  <path d="M12 2l4 4-8 8-4-4 8-8z"/>
                  <path d="M16 6l4 4"/>
                </svg>
              </button>
              <button
                onClick={() => setCurrentTool('eyedropper')}
                className={`p-2 rounded-lg transition-colors ${
                  currentTool === 'eyedropper' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Пипетка"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M2 22l1-1h3l9-9"/>
                  <path d="M3 21v-3l9-9"/>
                  <path d="M14.5 5.5l4 4"/>
                  <path d="M18.5 1.5a2.12 2.12 0 013 3l-1 1-4-4 1-1z"/>
                  <path d="M12 8l4 4"/>
                </svg>
              </button>
              <button
                onClick={() => setCurrentTool('eraser')}
                className={`p-2 rounded-lg transition-colors ${
                  currentTool === 'eraser' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Ластик"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M20 20H7L3 16c-.8-.8-.8-2 0-2.8L14.2 2c.8-.8 2-.8 2.8 0L21.8 6.8c.8.8.8 2 0 2.8L11 20"/>
                  <path d="M6 11l4 4"/>
                </svg>
              </button>
              <button
                onClick={undo}
                className="p-2 rounded-lg bg-zinc-700 hover:bg-zinc-600 transition-colors"
                title="Отменить"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 7v6h6"/>
                  <path d="M21 17a9 9 0 00-9-9 9 9 0 00-6 2.3L3 13"/>
                </svg>
              </button>
              <button
                onClick={redo}
                className="p-2 rounded-lg bg-zinc-700 hover:bg-zinc-600 transition-colors"
                title="Повторить"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 7v6h-6"/>
                  <path d="M3 17a9 9 0 019-9 9 9 0 016 2.3l3 2.7"/>
                </svg>
              </button>
            </div>
          </div>

          {/* Brush size */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Размер кисти:</label>
            <div className="grid grid-cols-4 gap-2">
              {[1, 2, 3, 4].map(size => (
                <button
                  key={size}
                  onClick={() => setBrushSize(size)}
                  className={`p-2 rounded-lg text-sm font-bold transition-colors ${
                    brushSize === size ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Grid size */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Размер холста:</label>
            <div className="grid grid-cols-2 gap-2">
              {[8, 16, 32, 64].map(size => (
                <button
                  key={size}
                  onClick={() => changeGridSize(size)}
                  className={`p-2 rounded-lg text-sm font-bold transition-colors ${
                    gridSize === size ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                  }`}
                >
                  {size}×{size}
                </button>
              ))}
            </div>
          </div>

          {/* Options */}
          <div className="bg-zinc-800 rounded-xl p-4 space-y-2">
            <label className="flex items-center gap-2 text-white text-sm">
              <input
                type="checkbox"
                checked={showGrid}
                onChange={(e) => setShowGrid(e.target.checked)}
                className="w-4 h-4"
              />
              Показать сетку
            </label>
            <label className="flex items-center gap-2 text-white text-sm">
              <input
                type="checkbox"
                checked={transparentBg}
                onChange={(e) => setTransparentBg(e.target.checked)}
                className="w-4 h-4"
              />
              Прозрачный фон
            </label>
          </div>

          {/* Export */}
          <button
            onClick={() => setShowExportModal(true)}
            className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
          >
            📥 Экспорт
          </button>
        </div>
      </div>

      {/* Save Modal */}
      {showSaveModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="bg-zinc-800 rounded-2xl p-6 max-w-md w-full mx-4">
            <h2 className="text-xl font-bold text-white mb-4">Сохранить в пресет</h2>
            
            <div className="space-y-4">
              {/* БАГ 6 FIX: Радио-кнопки для выбора режима сохранения */}
              {emojiPresets.length > 0 && (
                <div>
                  <label className="flex items-center gap-2 text-white text-sm mb-2">
                    <input
                      type="radio"
                      checked={saveMode === 'existing'}
                      onChange={() => setSaveMode('existing')}
                      className="w-4 h-4"
                    />
                    Добавить в существующий пресет:
                  </label>
                  <select
                    value={selectedPresetId}
                    onChange={(e) => setSelectedPresetId(e.target.value)}
                    disabled={saveMode !== 'existing'}
                    className="w-full bg-zinc-700 text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                  >
                    <option value="">Выберите пресет...</option>
                    {emojiPresets.map(preset => (
                      <option key={preset.id} value={preset.id}>
                        {preset.name} ({preset.emojis.length} картинок)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="flex items-center gap-2 text-white text-sm mb-2">
                  <input
                    type="radio"
                    checked={saveMode === 'new'}
                    onChange={() => setSaveMode('new')}
                    className="w-4 h-4"
                  />
                  Создать новый пресет:
                </label>
                <input
                  type="text"
                  value={newPresetName}
                  onChange={(e) => setNewPresetName(e.target.value)}
                  placeholder="Название пресета"
                  disabled={saveMode !== 'new'}
                  className="w-full bg-zinc-700 text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowSaveModal(false);
                    setNewPresetName('');
                    setSelectedPresetId('');
                  }}
                  className="flex-1 bg-zinc-700 hover:bg-zinc-600 text-white py-2 rounded-lg transition-colors duration-150"
                >
                  Отмена
                </button>
                <button
                  onClick={saveToPreset}
                  disabled={
                    (saveMode === 'existing' && !selectedPresetId) ||
                    (saveMode === 'new' && !newPresetName.trim())
                  }
                  className="flex-1 bg-green-600 hover:bg-green-500 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white font-bold py-2 rounded-lg transition-colors duration-150"
                >
                  Сохранить
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="bg-zinc-800 rounded-2xl p-6 max-w-md w-full mx-4">
            <h2 className="text-xl font-bold text-white mb-4">Экспорт анимации</h2>
            
            <div className="space-y-3">
              <button
                onClick={() => {
                  exportPNG();
                  setShowExportModal(false);
                }}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
              >
                📥 Скачать текущий кадр (PNG)
              </button>

              <button
                onClick={() => {
                  exportSpriteSheet();
                  setShowExportModal(false);
                  setToast('Спрайт-лист экспортирован!');
                  setTimeout(() => setToast(null), 3000);
                }}
                disabled={frames.length < 2}
                className="w-full bg-purple-600 hover:bg-purple-500 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white font-bold py-3 rounded-xl transition-colors duration-150"
              >
                🎞️ Скачать спрайт-лист ({frames.length} кадров)
              </button>

              <div className="border-t border-zinc-700 pt-3">
                <h3 className="text-white font-semibold mb-3">Сохранить все кадры в пресет</h3>
                
                {emojiPresets.length > 0 && (
                  <div className="mb-3">
                    <label className="flex items-center gap-2 text-white text-sm mb-2">
                      <input
                        type="radio"
                        checked={saveMode === 'existing'}
                        onChange={() => setSaveMode('existing')}
                        className="w-4 h-4"
                      />
                      Добавить в существующий пресет:
                    </label>
                    <select
                      value={selectedPresetId}
                      onChange={(e) => setSelectedPresetId(e.target.value)}
                      disabled={saveMode !== 'existing'}
                      className="w-full bg-zinc-700 text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                    >
                      <option value="">Выберите пресет...</option>
                      {emojiPresets.map(preset => (
                        <option key={preset.id} value={preset.id}>
                          {preset.name} ({preset.emojis.length} картинок)
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="mb-3">
                  <label className="flex items-center gap-2 text-white text-sm mb-2">
                    <input
                      type="radio"
                      checked={saveMode === 'new'}
                      onChange={() => setSaveMode('new')}
                      className="w-4 h-4"
                    />
                    Создать новый пресет:
                  </label>
                  <input
                    type="text"
                    value={newPresetName}
                    onChange={(e) => setNewPresetName(e.target.value)}
                    placeholder="Название пресета"
                    disabled={saveMode !== 'new'}
                    className="w-full bg-zinc-700 text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowExportModal(false);
                      setNewPresetName('');
                      setSelectedPresetId('');
                    }}
                    className="flex-1 bg-zinc-700 hover:bg-zinc-600 text-white py-2 rounded-lg transition-colors duration-150"
                  >
                    Отмена
                  </button>
                  <button
                    onClick={saveAllFramesToPreset}
                    disabled={
                      (saveMode === 'existing' && !selectedPresetId) ||
                      (saveMode === 'new' && !newPresetName.trim())
                    }
                    className="flex-1 bg-green-600 hover:bg-green-500 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white font-bold py-2 rounded-lg transition-colors duration-150"
                  >
                    Сохранить {frames.length} кадров
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-4 right-4 bg-green-600 text-white px-6 py-3 rounded-xl shadow-lg animate-pulse">
          {toast}
        </div>
      )}
    </div>
  );
}
