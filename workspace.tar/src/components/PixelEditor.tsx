import './gifNavigatorShim'; // должен быть ПЕРЕД импортом gif.js (см. комментарий в шиме)
import GIF from 'gif.js';
import { useState, useRef, useEffect } from 'react';
import { EmojiPreset } from '../game/types';
import { saveEmojiPresets } from '../game/storage';

interface PixelEditorProps {
  onBack: () => void;
  emojiPresets: EmojiPreset[];
  setEmojiPresets: (presets: EmojiPreset[]) => void;
}

type Tool = 'brush' | 'fill' | 'eyedropper' | 'eraser' | 'select';

interface SelectionRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface ClipboardData {
  width: number;
  height: number;
  pixels: (string | null)[][];
}

type MirrorMode = 'off' | 'x' | 'y' | 'xy';

const DEFAULT_PALETTE = [
  '#000000', '#1D2B53', '#7E2553', '#008751',
  '#AB5236', '#5F574F', '#C2C3C7', '#FFF1E8',
  '#FF004D', '#FFA300', '#FFEC27', '#00E436',
  '#29ADFF', '#83769C', '#FF77A8', '#FFCCAA',
  '#291814', '#111D35', '#422136', '#125359',
  '#742F29', '#49333B', '#A28879', '#F3EF7D',
  '#BE1250', '#FF6C24', '#A8E72E', '#00B543',
  '#065AB5', '#754665', '#FF6E59', '#FF9D81',
];

export default function PixelEditor({ onBack, emojiPresets, setEmojiPresets }: PixelEditorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gridSize, setGridSize] = useState(16);
  const [pixels, setPixels] = useState<(string | null)[][]>(
    Array(16).fill(null).map(() => Array(16).fill(null))
  );
  const [currentColor, setCurrentColor] = useState('#000000');
  const [currentTool, setCurrentTool] = useState<Tool>('brush');
  const [brushSize, setBrushSize] = useState(1);
  const [showGrid, setShowGrid] = useState(true);
  const [transparentBg, setTransparentBg] = useState(true);
  const [isDrawing, setIsDrawing] = useState(false);
  const [history, setHistory] = useState<(string | null)[][][]>([]);
  const [redoStack, setRedoStack] = useState<(string | null)[][][]>([]);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [newPresetName, setNewPresetName] = useState('');
  const [saveMode, setSaveMode] = useState<'existing' | 'new'>('existing');
  const [selectedPresetId, setSelectedPresetId] = useState<string>('');
  const [toast, setToast] = useState<string | null>(null);
  
  // Выделение
  const [selection, setSelection] = useState<SelectionRect | null>(null);
  const [isSelecting, setIsSelecting] = useState(false);
  const [selectionStart, setSelectionStart] = useState<{x: number, y: number} | null>(null);
  const [clipboard, setClipboard] = useState<ClipboardData | null>(null);
  const [floatingSelection, setFloatingSelection] = useState<{pixels: (string | null)[][], x: number, y: number} | null>(null);
  const [isDraggingSelection, setIsDraggingSelection] = useState(false);
  const [dragOffset, setDragOffset] = useState<{x: number, y: number}>({x: 0, y: 0});
  
  // Анимация
  const [frames, setFrames] = useState<(string | null)[][][]>([
    Array(16).fill(null).map(() => Array(16).fill(null))
  ]);
  const [currentFrame, setCurrentFrame] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(100); // мс между кадрами
  const [showExportModal, setShowExportModal] = useState(false);

  // Зеркало
  const [mirrorMode, setMirrorMode] = useState<MirrorMode>('off');

  // Курсор и кнопка рисования
  const [cursorPos, setCursorPos] = useState<{x: number, y: number} | null>(null);
  const [drawingEnabled, setDrawingEnabled] = useState(true);
  
  // Тип курсора
  type CursorStyle = 'pointer' | 'crosshair' | 'dot';
  const [cursorStyle, setCursorStyle] = useState<CursorStyle>('pointer');

  // Смещение точки рисования над пальцем (для курсора «Палочка»)
  const [pointerOffset, setPointerOffset] = useState(60);

  // Загрузка сохранённого смещения
  useEffect(() => {
    const saved = localStorage.getItem('pixelEditorPointerOffset');
    if (saved) setPointerOffset(parseInt(saved, 10));
  }, []);

  // Сохранение смещения
  useEffect(() => {
    localStorage.setItem('pixelEditorPointerOffset', String(pointerOffset));
  }, [pointerOffset]);

  // Калька (Onion Skin)
  const [onionSkinEnabled, setOnionSkinEnabled] = useState(false);

  // Зум
  const [zoom, setZoom] = useState(1);
  
  // Тач-жесты для пинч-зума
  const [touchStartDist, setTouchStartDist] = useState<number | null>(null);
  const [touchStartZoom, setTouchStartZoom] = useState(1);

  // Режим взаимодействия: рисование / панорамирование / просмотр
  type InteractionMode = 'draw' | 'pan' | 'view';
  const [interactionMode, setInteractionMode] = useState<InteractionMode>('draw');
  
  // Ref для контейнера с прокруткой
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  
  // Состояние для панорамирования
  const panState = useRef<{
    startX: number;
    startY: number;
    startScrollX: number;
    startScrollY: number;
  } | null>(null);

  // Загрузка настройки кальки из localStorage
  useEffect(() => {
    const saved = localStorage.getItem('pixelEditorOnionSkin');
    if (saved === 'true') {
      setOnionSkinEnabled(true);
    }
  }, []);

  // Сохранение настройки кальки при изменении
  useEffect(() => {
    localStorage.setItem('pixelEditorOnionSkin', String(onionSkinEnabled));
  }, [onionSkinEnabled]);

  // Загрузка зума из localStorage
  useEffect(() => {
    const savedZoom = localStorage.getItem('pixelEditorZoom');
    if (savedZoom) {
      setZoom(parseFloat(savedZoom));
    }
  }, []);

  // Сохранение зума при изменении
  useEffect(() => {
    localStorage.setItem('pixelEditorZoom', String(zoom));
  }, [zoom]);

  // Синхронизация pixels с frames
  useEffect(() => {
    const newFrames = [...frames];
    newFrames[currentFrame] = pixels.map(row => [...row]);
    setFrames(newFrames);
  }, [pixels]);

  // Загрузка из localStorage
  useEffect(() => {
    const saved = localStorage.getItem('pixelEditorAnimation');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        if (data.frames && data.frames.length > 0) {
          setFrames(data.frames);
          setGridSize(data.gridSize || 16);
          setPlaybackSpeed(data.fps || 100);
          setPixels(data.frames[0].map((row: (string | null)[]) => [...row]));
        }
        // Загрузка режима зеркала
        if (data.mirrorMode) {
          setMirrorMode(data.mirrorMode);
        }
      } catch (e) {
        console.error('Failed to load animation:', e);
      }
    }
    // Загрузка стиля курсора
    const savedCursor = localStorage.getItem('pixelEditorCursorStyle') as CursorStyle;
    if (savedCursor && ['pointer', 'crosshair', 'dot'].includes(savedCursor)) {
      setCursorStyle(savedCursor);
    }
  }, []);

  // Сохранение в localStorage
  useEffect(() => {
    const data = {
      frames,
      gridSize,
      fps: playbackSpeed,
      mirrorMode,
    };
    localStorage.setItem('pixelEditorAnimation', JSON.stringify(data));
  }, [frames, gridSize, playbackSpeed, mirrorMode]);

  // Сохранение стиля курсора
  useEffect(() => {
    localStorage.setItem('pixelEditorCursorStyle', cursorStyle);
  }, [cursorStyle]);

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // БАГ 4 FIX: Отключаем сглаживание для резких пикселей
    ctx.imageSmoothingEnabled = false;

    const cellSize = canvas.width / gridSize;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // БАГ 7 FIX: НЕ рисуем шахматный фон на canvas - он только в CSS
    // Canvas остаётся прозрачным

    // Draw pixels
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        if (pixels[y][x]) {
          ctx.fillStyle = pixels[y][x]!;
          ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
        }
      }
    }

    // Рисуем кальку (onion skin) ПЕРВЫМ слоем - под текущим кадром
    if (onionSkinEnabled) {
      const cellSize = canvas.width / gridSize;
      
      // Предыдущий кадр (красный)
      if (currentFrame > 0) {
        const prevFrame = frames[currentFrame - 1];
        ctx.globalAlpha = 0.3;
        for (let y = 0; y < gridSize; y++) {
          for (let x = 0; x < gridSize; x++) {
            if (prevFrame[y][x]) {
              ctx.fillStyle = '#ff5050';
              ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
            }
          }
        }
        ctx.globalAlpha = 1;
      }
      
      // Следующий кадр (синий)
      if (currentFrame < frames.length - 1) {
        const nextFrame = frames[currentFrame + 1];
        ctx.globalAlpha = 0.3;
        for (let y = 0; y < gridSize; y++) {
          for (let x = 0; x < gridSize; x++) {
            if (nextFrame[y][x]) {
              ctx.fillStyle = '#5078ff';
              ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
            }
          }
        }
        ctx.globalAlpha = 1;
      }
    }

    // Draw grid
    if (showGrid) {
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
      ctx.lineWidth = 1;
      for (let i = 0; i <= gridSize; i++) {
        ctx.beginPath();
        ctx.moveTo(i * cellSize, 0);
        ctx.lineTo(i * cellSize, canvas.height);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, i * cellSize);
        ctx.lineTo(canvas.width, i * cellSize);
        ctx.stroke();
      }
    }
    
    // Draw mirror lines
    if (mirrorMode !== 'off') {
      ctx.strokeStyle = 'rgba(76, 175, 80, 0.5)';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      
      // Вертикальная линия (зеркало X)
      if (mirrorMode === 'x' || mirrorMode === 'xy') {
        const centerX = (gridSize / 2) * cellSize;
        ctx.beginPath();
        ctx.moveTo(centerX, 0);
        ctx.lineTo(centerX, canvas.height);
        ctx.stroke();
      }
      
      // Горизонтальная линия (зеркало Y)
      if (mirrorMode === 'y' || mirrorMode === 'xy') {
        const centerY = (gridSize / 2) * cellSize;
        ctx.beginPath();
        ctx.moveTo(0, centerY);
        ctx.lineTo(canvas.width, centerY);
        ctx.stroke();
      }
      
      ctx.setLineDash([]);
    }

    // Draw selection rectangle
    if (selection && currentTool === 'select') {
      const selX = selection.x * cellSize;
      const selY = selection.y * cellSize;
      const selW = selection.width * cellSize;
      const selH = selection.height * cellSize;

      // Рисуем floating selection поверх холста
      if (floatingSelection) {
        for (let dy = 0; dy < floatingSelection.pixels.length; dy++) {
          for (let dx = 0; dx < floatingSelection.pixels[dy].length; dx++) {
            const px = floatingSelection.x + dx;
            const py = floatingSelection.y + dy;
            const pixel = floatingSelection.pixels[dy][dx];
            if (pixel) {
              ctx.fillStyle = pixel;
              ctx.fillRect(px * cellSize, py * cellSize, cellSize, cellSize);
            }
          }
        }
      }

      // Пунктирная рамка выделения
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.strokeRect(selX, selY, selW, selH);
      
      // Уголки рамки
      ctx.setLineDash([]);
      ctx.fillStyle = '#3b82f6';
      const cornerSize = 4;
      ctx.fillRect(selX - cornerSize/2, selY - cornerSize/2, cornerSize, cornerSize);
      ctx.fillRect(selX + selW - cornerSize/2, selY - cornerSize/2, cornerSize, cornerSize);
      ctx.fillRect(selX - cornerSize/2, selY + selH - cornerSize/2, cornerSize, cornerSize);
      ctx.fillRect(selX + selW - cornerSize/2, selY + selH - cornerSize/2, cornerSize, cornerSize);
    }
    
    // Виртуальный курсор в зависимости от стиля
if (cursorPos) {
  const cellSize = canvas.width / gridSize;
  const fingerX = cursorPos.x * cellSize + cellSize / 2;
  const fingerY = cursorPos.y * cellSize + cellSize / 2;

  // === Стиль 1: Перекрестие ===
  if (cursorStyle === 'crosshair') {
    ctx.strokeStyle = 'rgba(255, 200, 0, 0.7)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, fingerY);
    ctx.lineTo(canvas.width, fingerY);
    ctx.moveTo(fingerX, 0);
    ctx.lineTo(fingerX, canvas.height);
    ctx.stroke();

    ctx.fillStyle = '#ffb800';
    ctx.beginPath();
    ctx.arc(fingerX, fingerY, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  
  // === Стиль 2: Только точка ===
  else if (cursorStyle === 'dot') {
    ctx.fillStyle = '#ff3b30';
    ctx.beginPath();
    ctx.arc(fingerX, fingerY, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();

    const cellX = Math.floor(fingerX / cellSize) * cellSize;
    const cellY = Math.floor(fingerY / cellSize) * cellSize;
    ctx.strokeStyle = '#ffb800';
    ctx.lineWidth = 2;
    ctx.strokeRect(cellX, cellY, cellSize, cellSize);
  }
  
  // === Стиль 3: Палочка (по умолчанию) ===
  else {
    const offsetPx = pointerOffset;
    const drawX = fingerX;
    const drawY = fingerY - offsetPx;

    // Линия палочки
    const lineStartY = Math.max(0, drawY);
    const lineEndY = Math.min(canvas.height, fingerY);
    if (lineEndY > lineStartY) {
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(drawX, lineStartY);
      ctx.lineTo(drawX, lineEndY);
      ctx.stroke();

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(drawX, lineStartY);
      ctx.lineTo(drawX, lineEndY);
      ctx.stroke();
    }

    // Точка рисования
    const dotX = Math.max(8, Math.min(canvas.width - 8, drawX));
    const dotY = Math.max(8, Math.min(canvas.height - 8, drawY));

    ctx.fillStyle = '#ff3b30';
    ctx.beginPath();
    ctx.arc(dotX, dotY, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Перекрестие внутри
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(dotX - 9, dotY);
    ctx.lineTo(dotX + 9, dotY);
    ctx.moveTo(dotX, dotY - 9);
    ctx.lineTo(dotX, dotY + 9);
    ctx.stroke();

    // Жёлтая рамка вокруг ячейки под точкой
    const cellX = Math.floor(drawX / cellSize) * cellSize;
    const cellY = Math.floor(drawY / cellSize) * cellSize;
    ctx.strokeStyle = '#ffb800';
    ctx.lineWidth = 2;
    ctx.strokeRect(cellX, cellY, cellSize, cellSize);
  }
}
    
    ctx.setLineDash([]);
  }, [pixels, gridSize, showGrid, mirrorMode, selection, floatingSelection, currentTool, cursorPos, cursorStyle, onionSkinEnabled, currentFrame, frames]);

  const saveToHistory = () => {
    setHistory([...history, pixels.map(row => [...row])]);
    setRedoStack([]);
  };

  const undo = () => {
    if (history.length === 0) return;
    const previous = history[history.length - 1];
    setRedoStack([...redoStack, pixels.map(row => [...row])]);
    setPixels(previous);
    setHistory(history.slice(0, -1));
  };

  const redo = () => {
    if (redoStack.length === 0) return;
    const next = redoStack[redoStack.length - 1];
    setHistory([...history, pixels.map(row => [...row])]);
    setPixels(next);
    setRedoStack(redoStack.slice(0, -1));
  };

// Функция 1: координаты для РИСОВАНИЯ (со смещением вверх на тач)
const getPixelCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
  const canvas = canvasRef.current;
  if (!canvas) return null;

  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;

  const fingerCanvasX = (e.clientX - rect.left) * scaleX;
  const fingerCanvasY = (e.clientY - rect.top) * scaleY;

  const offsetPx = cursorStyle === 'pointer' ? pointerOffset : 0;

  const drawCanvasX = fingerCanvasX;
  const drawCanvasY = fingerCanvasY - offsetPx;

  const x = Math.floor(drawCanvasX / (canvas.width / gridSize));
  const y = Math.floor(drawCanvasY / (canvas.height / gridSize));

  if (x < 0 || x >= gridSize || y < 0 || y >= gridSize) return null;
  return { x, y };
};

// Функция 2: координаты ПАЛЬЦА (для отрисовки курсора)
  const getFingerCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
  const canvas = canvasRef.current;
  if (!canvas) return null;

  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;

  const fingerCanvasX = (e.clientX - rect.left) * scaleX;
  const fingerCanvasY = (e.clientY - rect.top) * scaleY;

  const x = Math.floor(fingerCanvasX / (canvas.width / gridSize));
  const y = Math.floor(fingerCanvasY / (canvas.height / gridSize));

  return { x, y };
};

  const setPixel = (x: number, y: number, color: string | null) => {
    const newPixels = pixels.map(row => [...row]);
    
    // Функция для установки пикселя с учётом кисти
    const drawBrush = (px: number, py: number) => {
      for (let dy = 0; dy < brushSize; dy++) {
        for (let dx = 0; dx < brushSize; dx++) {
          const bx = px + dx - Math.floor(brushSize / 2);
          const by = py + dy - Math.floor(brushSize / 2);
          if (bx >= 0 && bx < gridSize && by >= 0 && by < gridSize) {
            newPixels[by][bx] = color;
          }
        }
      }
    };
    
    // Рисуем основной пиксель
    drawBrush(x, y);
    
    // Применяем зеркало
    if (mirrorMode !== 'off') {
      const mirrorX = gridSize - 1 - x;
      const mirrorY = gridSize - 1 - y;
      
      if (mirrorMode === 'x' || mirrorMode === 'xy') {
        // Зеркало по оси X (вертикальная ось)
        drawBrush(mirrorX, y);
      }
      
      if (mirrorMode === 'y' || mirrorMode === 'xy') {
        // Зеркало по оси Y (горизонтальная ось)
        drawBrush(x, mirrorY);
      }
      
      if (mirrorMode === 'xy') {
        // Зеркало по обеим осям
        drawBrush(mirrorX, mirrorY);
      }
    }
    
    setPixels(newPixels);
  };

  const floodFill = (startX: number, startY: number, fillColor: string) => {
    const targetColor = pixels[startY][startX];
    if (targetColor === fillColor) return;

    const newPixels = pixels.map(row => [...row]);
    const stack = [{ x: startX, y: startY }];

    while (stack.length > 0) {
      const { x, y } = stack.pop()!;
      if (x < 0 || x >= gridSize || y < 0 || y >= gridSize) continue;
      if (newPixels[y][x] !== targetColor) continue;

      newPixels[y][x] = fillColor;
      stack.push({ x: x + 1, y });
      stack.push({ x: x - 1, y });
      stack.push({ x, y: y + 1 });
      stack.push({ x, y: y - 1 });
    }

    setPixels(newPixels);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    // Режим панорамирования
    if (interactionMode === 'pan') {
      const container = scrollContainerRef.current;
      if (container) {
        panState.current = {
          startX: e.clientX,
          startY: e.clientY,
          startScrollX: container.scrollLeft,
          startScrollY: container.scrollTop,
        };
      }
      return;
    }

    const finger = getFingerCoords(e);
    if (finger) setCursorPos(finger);

    const coords = getPixelCoords(e);
    if (!coords) return;

    const { x, y } = coords;

    // Если есть floating selection и клик внутри него - начинаем перетаскивание
    if (floatingSelection && currentTool === 'select') {
      if (x >= floatingSelection.x && x < floatingSelection.x + floatingSelection.pixels[0].length &&
          y >= floatingSelection.y && y < floatingSelection.y + floatingSelection.pixels.length) {
        setIsDraggingSelection(true);
        setDragOffset({ x: x - floatingSelection.x, y: y - floatingSelection.y });
        return;
      } else {
        // Клик ВНЕ floating selection - приземляем его перед новым действием
        const newPixels = pixels.map(row => [...row]);
        for (let dy = 0; dy < floatingSelection.pixels.length; dy++) {
          for (let dx = 0; dx < floatingSelection.pixels[dy].length; dx++) {
            const px = floatingSelection.x + dx;
            const py = floatingSelection.y + dy;
            if (px >= 0 && px < gridSize && py >= 0 && py < gridSize) {
              newPixels[py][px] = floatingSelection.pixels[dy][dx];
            }
          }
        }
        setPixels(newPixels);
        setFloatingSelection(null);
      }
    }

    // Если есть активное выделение (без floating) и клик внутри него - начинаем перетаскивание
    if (selection && !floatingSelection && currentTool === 'select') {
      if (x >= selection.x && x < selection.x + selection.width &&
          y >= selection.y && y < selection.y + selection.height) {
        // Вырезаем выделенную область в floating selection
        const selectedPixels: (string | null)[][] = [];
        for (let dy = 0; dy < selection.height; dy++) {
          const row: (string | null)[] = [];
          for (let dx = 0; dx < selection.width; dx++) {
            row.push(pixels[selection.y + dy][selection.x + dx]);
          }
          selectedPixels.push(row);
        }
        
        // Очищаем исходную область
        const newPixels = pixels.map(row => [...row]);
        for (let dy = 0; dy < selection.height; dy++) {
          for (let dx = 0; dx < selection.width; dx++) {
            newPixels[selection.y + dy][selection.x + dx] = null;
          }
        }
        setPixels(newPixels);
        
        setFloatingSelection({ pixels: selectedPixels, x: selection.x, y: selection.y });
        setIsDraggingSelection(true);
        setDragOffset({ x: x - selection.x, y: y - selection.y });
        return;
      }
    }

    // Инструмент выделения - новое выделение
    if (currentTool === 'select') {
      // Сбрасываем старое выделение перед началом нового
      setSelection(null);
      setFloatingSelection(null);
      setIsSelecting(true);
      setSelectionStart({ x, y });
      setSelection({ x, y, width: 1, height: 1 });
      return;
    }

    // Если выбран другой инструмент - снимаем выделение
    if (selection) {
      clearSelection();
    }

    // Если рисование отключено или режим просмотра - не рисуем
    if (!drawingEnabled || interactionMode === 'view') return;

    saveToHistory();
    setIsDrawing(true);

    switch (currentTool) {
      case 'brush':
        setPixel(x, y, currentColor);
        break;
      case 'eraser':
        setPixel(x, y, null);
        break;
      case 'fill':
        floodFill(x, y, currentColor);
        break;
      case 'eyedropper':
        if (pixels[y][x]) {
          setCurrentColor(pixels[y][x]!);
        }
        break;
    }
  };

  const clearSelection = () => {
    setSelection(null);
    setFloatingSelection(null);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    // Панорамирование
    if (interactionMode === 'pan' && panState.current) {
      const container = scrollContainerRef.current;
      if (container) {
        const dx = e.clientX - panState.current.startX;
        const dy = e.clientY - panState.current.startY;
        container.scrollLeft = panState.current.startScrollX - dx;
        container.scrollTop = panState.current.startScrollY - dy;
      }
      return;
    }

    const finger = getFingerCoords(e);
    if (finger) setCursorPos(finger);

    const coords = getPixelCoords(e);

    // Перетаскивание выделения
    if (isDraggingSelection && selection) {
      if (coords) {
        const newX = Math.max(0, Math.min(coords.x - dragOffset.x, gridSize - selection.width));
        const newY = Math.max(0, Math.min(coords.y - dragOffset.y, gridSize - selection.height));
        setSelection({ ...selection, x: newX, y: newY });
        
        // Синхронизируем floatingSelection с selection
        if (floatingSelection) {
          setFloatingSelection({ ...floatingSelection, x: newX, y: newY });
        }
      }
      return;
    }

    // Создание выделения
    if (isSelecting && selectionStart && currentTool === 'select') {
      if (coords) {
        const x = Math.min(selectionStart.x, coords.x);
        const y = Math.min(selectionStart.y, coords.y);
        const width = Math.abs(coords.x - selectionStart.x) + 1;
        const height = Math.abs(coords.y - selectionStart.y) + 1;
        setSelection({ x, y, width, height });
      }
      return;
    }

    if (!isDrawing || !drawingEnabled || interactionMode === 'view') return;
    if (!coords) return;

    const { x, y } = coords;

    if (currentTool === 'brush') {
      setPixel(x, y, currentColor);
    } else if (currentTool === 'eraser') {
      setPixel(x, y, null);
    }
  };

  const handleMouseUp = () => {
    // Завершение панорамирования
    if (interactionMode === 'pan') {
      panState.current = null;
      return;
    }

    if (isDraggingSelection && floatingSelection) {
      // Завершаем перетаскивание - "приземляем" выделение
      saveToHistory();
      const newPixels = pixels.map(row => [...row]);
      for (let dy = 0; dy < floatingSelection.pixels.length; dy++) {
        for (let dx = 0; dx < floatingSelection.pixels[dy].length; dx++) {
          const px = floatingSelection.x + dx;
          const py = floatingSelection.y + dy;
          if (px >= 0 && px < gridSize && py >= 0 && py < gridSize) {
            newPixels[py][px] = floatingSelection.pixels[dy][dx];
          }
        }
      }
      setPixels(newPixels);
      setIsDraggingSelection(false);
      setFloatingSelection(null);
      return;
    }

    if (isSelecting) {
      setIsSelecting(false);
      setSelectionStart(null);
      // Финализируем выделение - сохраняем в state
      console.log('Selection complete:', selection);
      return;
    }

    setIsDrawing(false);
  };

  const handleMouseLeave = () => {
    setCursorPos(null);
    setIsDrawing(false);
  };

  // Обработчики тач-жестов для пинч-зума
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      setTouchStartDist(dist);
      setTouchStartZoom(zoom);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && touchStartDist !== null) {
      e.preventDefault();
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      
      const newZoom = touchStartZoom * (dist / touchStartDist);
      const clamped = Math.max(0.5, Math.min(4, newZoom));
      setZoom(clamped);
    }
  };

  const handleTouchEnd = () => {
    setTouchStartDist(null);
  };

  const changeGridSize = (newSize: number) => {
    if (pixels.some(row => row.some(p => p !== null))) {
      if (!confirm('Очистить холст?')) return;
    }
    setGridSize(newSize);
    const emptyFrame = Array(newSize).fill(null).map(() => Array(newSize).fill(null));
    setPixels(emptyFrame);
    setFrames([emptyFrame]);
    setCurrentFrame(0);
    setHistory([]);
    setRedoStack([]);
    clearSelection();
    
    // Авто-зум для маленьких сеток
    if (newSize === 32) setZoom(1.5);
    else if (newSize === 64) setZoom(2);
    else setZoom(1);
  };

  // Функции выделения
  const copySelection = () => {
    if (!selection) return;
    const selectedPixels: (string | null)[][] = [];
    for (let y = selection.y; y < selection.y + selection.height; y++) {
      const row: (string | null)[] = [];
      for (let x = selection.x; x < selection.x + selection.width; x++) {
        row.push(pixels[y][x]);
      }
      selectedPixels.push(row);
    }
    setClipboard({ width: selection.width, height: selection.height, pixels: selectedPixels });
    setToast(`Скопировано ${selection.width}×${selection.height}`);
    setTimeout(() => setToast(null), 2000);
  };

  const cutSelection = () => {
    if (!selection) return;
    copySelection();
    saveToHistory();
    const newPixels = pixels.map(row => [...row]);
    for (let y = selection.y; y < selection.y + selection.height; y++) {
      for (let x = selection.x; x < selection.x + selection.width; x++) {
        newPixels[y][x] = null;
      }
    }
    setPixels(newPixels);
    setToast(`Вырезано ${selection.width}×${selection.height}`);
    setTimeout(() => setToast(null), 2000);
  };

  const pasteSelection = () => {
    if (!clipboard) return;
    saveToHistory();
    // Вставляем в позицию текущего выделения, или в центр если выделения нет
    const startX = selection ? selection.x : Math.floor((gridSize - clipboard.width) / 2);
    const startY = selection ? selection.y : Math.floor((gridSize - clipboard.height) / 2);
    
    // Создаём floating selection для вставленного блока
    setFloatingSelection({ pixels: clipboard.pixels, x: startX, y: startY });
    setSelection({ x: startX, y: startY, width: clipboard.width, height: clipboard.height });
    
    // НЕ включаем перетаскивание автоматически. Пользователь сам решит тащить.
    setIsDraggingSelection(false);
    setDragOffset({ x: 0, y: 0 });
    
    setToast('Вставлено');
    setTimeout(() => setToast(null), 2000);
  };

  const duplicateSelection = () => {
    if (!selection) return;
    
    // 1. Копируем пиксели выделенной области
    const selectedPixels: (string | null)[][] = [];
    for (let y = selection.y; y < selection.y + selection.height; y++) {
      const row: (string | null)[] = [];
      for (let x = selection.x; x < selection.x + selection.width; x++) {
        row.push(pixels[y][x]);
      }
      selectedPixels.push(row);
    }
    
    // 2. Вычисляем новую позицию
    // Пытаемся разместить справа
    let newX = selection.x + selection.width;
    let newY = selection.y;

    // Если не помещается справа - пробуем снизу
    if (newX + selection.width > gridSize) {
      newX = selection.x;
      newY = selection.y + selection.height;
    }

    // Если не помещается и снизу - в левый верхний угол
    if (newY + selection.height > gridSize) {
      newX = 0;
      newY = 0;
    }

    // Ограничиваем координаты, чтобы блок точно влез в сетку
    newX = Math.max(0, Math.min(newX, gridSize - selection.width));
    newY = Math.max(0, Math.min(newY, gridSize - selection.height));

    // 3. Создаем floating selection на новой позиции
    // Исходную область НЕ очищаем, так как это дублирование
    setFloatingSelection({ pixels: selectedPixels, x: newX, y: newY });
    
    // Обновляем рамку выделения на новую позицию
    setSelection({ x: newX, y: newY, width: selection.width, height: selection.height });

    // 4. НЕ включаем перетаскивание автоматически. Пользователь сам решит тащить.
    setIsDraggingSelection(false);
    setDragOffset({ x: 0, y: 0 });
    
    setToast('Дублировано');
    setTimeout(() => setToast(null), 2000);
  };

  const deleteSelection = () => {
    if (!selection) return;
    saveToHistory();
    const newPixels = pixels.map(row => [...row]);
    for (let y = selection.y; y < selection.y + selection.height; y++) {
      for (let x = selection.x; x < selection.x + selection.width; x++) {
        newPixels[y][x] = null;
      }
    }
    setPixels(newPixels);
    clearSelection();
    setToast('Удалено');
    setTimeout(() => setToast(null), 2000);
  };

  // Управление кадрами
  const addFrame = () => {
    const emptyFrame = Array(gridSize).fill(null).map(() => Array(gridSize).fill(null));
    setFrames([...frames, emptyFrame]);
    setCurrentFrame(frames.length);
    setPixels(emptyFrame);
  };

  const duplicateFrame = () => {
    const duplicated = frames[currentFrame].map(row => [...row]);
    setFrames([...frames, duplicated]);
    setCurrentFrame(frames.length);
    setPixels(duplicated);
  };

  const deleteFrame = () => {
    if (frames.length <= 1) return;
    const newFrames = frames.filter((_, i) => i !== currentFrame);
    setFrames(newFrames);
    const newCurrentFrame = Math.min(currentFrame, newFrames.length - 1);
    setCurrentFrame(newCurrentFrame);
    setPixels(newFrames[newCurrentFrame].map(row => [...row]));
  };

  const switchFrame = (index: number) => {
    setCurrentFrame(index);
    setPixels(frames[index].map(row => [...row]));
    setHistory([]);
    setRedoStack([]);
  };

  // Плеер анимации
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setCurrentFrame(prev => (prev + 1) % frames.length);
    }, playbackSpeed);

    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed, frames.length]);

  useEffect(() => {
    if (isPlaying) {
      setPixels(frames[currentFrame].map(row => [...row]));
    }
  }, [currentFrame, isPlaying]);

  // Горячие клавиши для выделения
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Если фокус в input - игнорируем
      if (document.activeElement?.tagName === 'INPUT') return;

      if (e.key === 'Escape') {
        // Приземлить floating selection перед снятием выделения
        if (floatingSelection) {
          saveToHistory();
          const newPixels = pixels.map(row => [...row]);
          for (let dy = 0; dy < floatingSelection.pixels.length; dy++) {
            for (let dx = 0; dx < floatingSelection.pixels[dy].length; dx++) {
              const px = floatingSelection.x + dx;
              const py = floatingSelection.y + dy;
              if (px >= 0 && px < gridSize && py >= 0 && py < gridSize) {
                newPixels[py][px] = floatingSelection.pixels[dy][dx];
              }
            }
          }
          setPixels(newPixels);
          setFloatingSelection(null);
        }
        clearSelection();
        return;
      }

      if (!selection) return;

      // Стрелки для перемещения
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        e.preventDefault();
        const step = e.shiftKey ? 5 : 1;
        let newX = selection.x;
        let newY = selection.y;

        if (e.key === 'ArrowUp') newY = Math.max(0, selection.y - step);
        if (e.key === 'ArrowDown') newY = Math.min(gridSize - selection.height, selection.y + step);
        if (e.key === 'ArrowLeft') newX = Math.max(0, selection.x - step);
        if (e.key === 'ArrowRight') newX = Math.min(gridSize - selection.width, selection.x + step);

        setSelection({ ...selection, x: newX, y: newY });
        
        // Синхронизием floatingSelection при перемещении стрелками
        if (floatingSelection) {
          setFloatingSelection({ ...floatingSelection, x: newX, y: newY });
        }
        return;
      }

      // Ctrl+C, Ctrl+X, Ctrl+V, Ctrl+D
      if (e.ctrlKey || e.metaKey) {
        if (e.key === 'c' || e.key === 'C') {
          e.preventDefault();
          copySelection();
        } else if (e.key === 'x' || e.key === 'X') {
          e.preventDefault();
          cutSelection();
        } else if (e.key === 'v' || e.key === 'V') {
          e.preventDefault();
          pasteSelection();
        } else if (e.key === 'd' || e.key === 'D') {
          e.preventDefault();
          duplicateSelection();
        }
        return;
      }

      // Delete
      if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault();
        deleteSelection();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selection, clipboard, pixels]);

  const exportPNG = () => {
    const canvas = document.createElement('canvas');
    const scale = 32;
    canvas.width = gridSize * scale;
    canvas.height = gridSize * scale;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.imageSmoothingEnabled = false;

    if (!transparentBg) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        if (pixels[y][x]) {
          ctx.fillStyle = pixels[y][x]!;
          ctx.fillRect(x * scale, y * scale, scale, scale);
        }
      }
    }

    const link = document.createElement('a');
    link.download = `pixel-art-${gridSize}x${gridSize}-frame${currentFrame + 1}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const exportSpriteSheet = () => {
    const canvas = document.createElement('canvas');
    const scale = 32;
    const frameSize = gridSize * scale;
    canvas.width = frameSize * frames.length;
    canvas.height = frameSize;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.imageSmoothingEnabled = false;

    if (!transparentBg) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    frames.forEach((frame, frameIndex) => {
      for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
          if (frame[y][x]) {
            ctx.fillStyle = frame[y][x]!;
            ctx.fillRect(frameIndex * frameSize + x * scale, y * scale, scale, scale);
          }
        }
      }
    });

    const link = document.createElement('a');
    link.download = `sprite-sheet-${gridSize}x${gridSize}-${frames.length}frames.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  // Экспорт анимации в GIF (через gif.js, воркер лежит в public/gif.worker.js)
  const exportGIF = () => {
    if (frames.length < 2) return;

    // Масштабируем кадры, чтобы GIF был нормального размера (не 8×8 пикселей)
    const scale = Math.max(1, Math.floor(256 / gridSize));
    const renderSize = gridSize * scale;

    const gifOptions: any = {
      workers: 2,
      quality: 1, // 1 = максимальное качество (шкала 1-30)
      width: renderSize,
      height: renderSize,
      workerScript: '/gif.worker.js',
    };

    if (transparentBg) {
      // Число, а не строка; явное чёрное полотно под прозрачностью
      gifOptions.transparent = 0x00000000;
      gifOptions.background = '#000000';
    } else {
      // НЕ передаём transparent вообще — фон полностью непрозрачный
      gifOptions.background = '#ffffff';
    }

    const gif = new GIF(gifOptions);

    frames.forEach((frame) => {
      const canvas = document.createElement('canvas');
      canvas.width = renderSize;
      canvas.height = renderSize;
      const ctx = canvas.getContext('2d')!;
      ctx.imageSmoothingEnabled = false;

      // Если НЕ прозрачный фон — залить белым ПЕРЕД рисованием пикселей
      if (!transparentBg) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, renderSize, renderSize);
      }

      for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
          if (frame[y][x]) {
            ctx.fillStyle = frame[y][x]!;
            ctx.fillRect(x * scale, y * scale, scale, scale);
          }
        }
      }

      // Скорость GIF = playbackSpeed (мс между кадрами из плеера)
      gif.addFrame(ctx, { delay: playbackSpeed, copy: true });
    });

    gif.on('finished', (blob: Blob) => {
      const link = document.createElement('a');
      link.download = `pixel-art-${gridSize}x${gridSize}-${frames.length}frames.gif`;
      link.href = URL.createObjectURL(blob);
      link.click();
      setToast('GIF сохранён!');
      setTimeout(() => setToast(null), 3000);
    });

    gif.on('progress', (p: number) => {
      setToast(`Генерация GIF: ${Math.round(p * 100)}%`);
    });

    gif.render();
  };

  const saveAllFramesToPreset = async () => {
    const frameDataURLs: string[] = [];

    console.log('Saving preset with frames:', frames.length, 'frames');

    frames.forEach((frame, index) => {
      const canvas = document.createElement('canvas');
      canvas.width = gridSize;
      canvas.height = gridSize;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.imageSmoothingEnabled = false;

      if (!transparentBg) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
          if (frame[y][x]) {
            ctx.fillStyle = frame[y][x]!;
            ctx.fillRect(x, y, 1, 1);
          }
        }
      }

      const dataURL = canvas.toDataURL('image/png');
      frameDataURLs.push(dataURL);
      console.log(`Frame ${index + 1} saved, dataURL length: ${dataURL.length}`);
    });

    console.log('Total frames to save:', frameDataURLs.length);

    let updatedPresets = [...emojiPresets];

    if (saveMode === 'existing' && selectedPresetId) {
      const presetIndex = updatedPresets.findIndex(p => p.id === selectedPresetId);
      if (presetIndex !== -1) {
        updatedPresets[presetIndex] = {
          ...updatedPresets[presetIndex],
          emojis: [...updatedPresets[presetIndex].emojis, ...frameDataURLs],
        };
        console.log('Added to existing preset:', updatedPresets[presetIndex].name, 'Total emojis:', updatedPresets[presetIndex].emojis.length);
      }
    } else if (saveMode === 'new' && newPresetName.trim()) {
      const newPreset: EmojiPreset = {
        id: `preset_${Date.now()}`,
        name: newPresetName.trim(),
        emojis: frameDataURLs,
        createdAt: Date.now(),
      };
      updatedPresets.push(newPreset);
      console.log('Created new preset:', newPreset.name, 'with', newPreset.emojis.length, 'emojis');
    }

    setEmojiPresets(updatedPresets);
    await saveEmojiPresets(updatedPresets);
    setNewPresetName('');
    setSelectedPresetId('');

    setShowExportModal(false);
    setToast(`${frameDataURLs.length} кадров сохранено!`);
    setTimeout(() => setToast(null), 3000);
  };

  const saveToPreset = async () => {
    const canvas = document.createElement('canvas');
    canvas.width = gridSize;
    canvas.height = gridSize;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // БАГ 4 FIX: Отключаем сглаживание
    ctx.imageSmoothingEnabled = false;

    // БАГ 7 FIX: НЕ рисуем шахматный фон - только пиксели
    if (!transparentBg) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        if (pixels[y][x]) {
          ctx.fillStyle = pixels[y][x]!;
          ctx.fillRect(x, y, 1, 1);
        }
      }
    }

    const dataURL = canvas.toDataURL('image/png');

    // БАГ 6 FIX: Сохранение в существующий или новый пресет
    let updatedPresets = [...emojiPresets];

    if (saveMode === 'existing' && selectedPresetId) {
      // Добавляем в существующий пресет
      const presetIndex = updatedPresets.findIndex(p => p.id === selectedPresetId);
      if (presetIndex !== -1) {
        updatedPresets[presetIndex] = {
          ...updatedPresets[presetIndex],
          emojis: [...updatedPresets[presetIndex].emojis, dataURL],
        };
      }
    } else if (saveMode === 'new' && newPresetName.trim()) {
      // Создаём новый пресет
      const newPreset: EmojiPreset = {
        id: `preset_${Date.now()}`,
        name: newPresetName.trim(),
        emojis: [dataURL],
        createdAt: Date.now(),
      };
      updatedPresets.push(newPreset);
    }

    setEmojiPresets(updatedPresets);
    await saveEmojiPresets(updatedPresets);
    setNewPresetName('');
    setSelectedPresetId('');

    setShowSaveModal(false);
    setToast('Картинка сохранена!');
    setTimeout(() => setToast(null), 3000);
  };

  return (
    <div className="w-full h-full bg-gradient-to-b from-zinc-900 to-zinc-800 flex flex-col p-4 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <button
          onClick={onBack}
          className="bg-zinc-700 hover:bg-zinc-600 text-white px-4 py-2 rounded-xl transition-colors duration-150"
        >
          ← Назад
        </button>
        <h1 className="text-2xl font-bold text-white">🎨 Редактор пиксель-арта</h1>
        <button
          onClick={() => {
            setShowSaveModal(true);
            // БАГ 6 FIX: Устанавливаем режим по умолчанию
            setSaveMode(emojiPresets.length > 0 ? 'existing' : 'new');
            if (emojiPresets.length > 0) {
              setSelectedPresetId(emojiPresets[0].id);
            }
          }}
          className="bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded-xl transition-colors duration-150"
        >
          💾
        </button>
      </div>

      <div className="flex gap-4 flex-1">
        {/* Canvas */}
        <div className="flex-1 flex flex-col items-center">
          {/* Плеер анимации */}
          <div className="w-[512px] mb-2 flex items-center gap-2 bg-zinc-800 rounded-xl p-2">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              disabled={frames.length < 2}
              className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                isPlaying
                  ? 'bg-red-600 hover:bg-red-500 text-white'
                  : 'bg-green-600 hover:bg-green-500 text-white'
              } disabled:bg-zinc-600 disabled:cursor-not-allowed`}
            >
              {isPlaying ? '⏸ Стоп' : '▶ Просмотр'}
            </button>
            <div className="flex-1 flex items-center gap-2">
              <span className="text-zinc-400 text-xs">Скорость:</span>
              <input
                type="range"
                min="50"
                max="500"
                step="50"
                value={playbackSpeed}
                onChange={(e) => setPlaybackSpeed(Number(e.target.value))}
                disabled={isPlaying}
                className="flex-1 h-2 bg-zinc-600 rounded-lg appearance-none cursor-pointer accent-blue-500 disabled:opacity-50"
              />
              <span className="text-zinc-400 text-xs w-12">{playbackSpeed}мс</span>
            </div>
            <label className="flex items-center gap-2 ml-4">
              <input
                type="checkbox"
                checked={onionSkinEnabled}
                onChange={(e) => setOnionSkinEnabled(e.target.checked)}
                className="w-4 h-4 accent-blue-500"
              />
              <span className="text-zinc-400 text-sm">👻 Калька</span>
            </label>
          </div>

          {/* КОНТЕЙНЕР ХОЛСТА с фиксированным размером и скроллом */}
          {/* Для 8×8 и 16×16 — без скролла, холст просто растёт в центре */}
          {/* Для 32×32 и 64×64 — со скроллом */}
          <div 
            className="relative rounded-lg border-2 border-zinc-600"
            style={{
              width: (gridSize <= 16 ? 600 : 520) + 'px',
              height: (gridSize <= 16 ? 600 : 520) + 'px',
              overflow: gridSize <= 16 ? 'visible' : 'auto',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
            ref={scrollContainerRef}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            <div
              style={{
                width: (512 * zoom) + 'px',
                height: (512 * zoom) + 'px',
                backgroundImage: transparentBg
                  ? 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)'
                  : 'none',
                backgroundSize: '20px 20px',
                backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px',
                backgroundColor: '#fff',
                flexShrink: 0,
              }}
            >
              <canvas
                ref={canvasRef}
                width={512}
                height={512}
                className={`pixel-art ${isPlaying ? 'cursor-not-allowed' : (currentTool === 'select' ? 'cursor-crosshair' : (interactionMode === 'pan' ? 'cursor-grab' : 'cursor-default'))}`}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseLeave}
                onWheel={(e) => {
                  if (e.ctrlKey) {
                    e.preventDefault();
                    const delta = e.deltaY > 0 ? -0.25 : 0.25;
                    setZoom(prev => Math.max(0.5, Math.min(4, prev + delta)));
                  }
                }}
                style={{
                  pointerEvents: isPlaying ? 'none' : 'auto',
                  touchAction: 'none',
                  width: '100%',
                  height: '100%',
                  imageRendering: 'pixelated',
                  display: 'block',
                }}
              />
            </div>
          </div>

          {/* Кнопка включения/выключения рисования - в углу экрана */}

          {/* Лента кадров */}
          <div className="w-[512px] mt-2 bg-zinc-800 rounded-xl p-3">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-zinc-400 text-xs font-semibold">КАДРЫ:</span>
              <div className="flex-1" />
              <button
                onClick={addFrame}
                className="px-2 py-1 bg-green-600 hover:bg-green-500 text-white text-xs rounded transition-colors"
              >
                + Добавить
              </button>
              <button
                onClick={duplicateFrame}
                className="px-2 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs rounded transition-colors"
              >
                📄 Дубл.
              </button>
              <button
                onClick={deleteFrame}
                disabled={frames.length <= 1}
                className="px-2 py-1 bg-red-600 hover:bg-red-500 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white text-xs rounded transition-colors"
              >
                🗑 Удалить
              </button>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2">
              {frames.map((frame, index) => (
                <button
                  key={index}
                  onClick={() => !isPlaying && switchFrame(index)}
                  disabled={isPlaying}
                  className={`flex-shrink-0 w-12 h-12 border-2 rounded overflow-hidden transition-all ${
                    index === currentFrame
                      ? 'border-blue-500 scale-110'
                      : 'border-zinc-600 hover:border-zinc-500'
                  } ${isPlaying ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                  style={{
                    backgroundImage: transparentBg
                      ? 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)'
                      : 'none',
                    backgroundSize: '8px 8px',
                    backgroundPosition: '0 0, 0 4px, 4px -4px, -4px 0px',
                    backgroundColor: '#fff',
                  }}
                >
                  <canvas
                    width={48}
                    height={48}
                    className="w-full h-full pixel-art"
                    ref={(canvas) => {
                      if (canvas) {
                        const ctx = canvas.getContext('2d');
                        if (ctx) {
                          ctx.imageSmoothingEnabled = false;
                          ctx.clearRect(0, 0, 48, 48);
                          const cellSize = 48 / gridSize;
                          for (let y = 0; y < gridSize; y++) {
                            for (let x = 0; x < gridSize; x++) {
                              if (frame[y][x]) {
                                ctx.fillStyle = frame[y][x]!;
                                ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
                              }
                            }
                          }
                        }
                      }
                    }}
                  />
                </button>
              ))}
            </div>
            <div className="text-zinc-400 text-xs mt-1">
              Кадр {currentFrame + 1} из {frames.length}
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="w-64 space-y-4">
          {/* Панель действий с выделением - ПЕРВЫМ блоком */}
          {selection && currentTool === 'select' && (
            <div className="bg-zinc-800 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-white text-sm font-semibold">
                  Выделено: {selection.width}×{selection.height}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={copySelection}
                  className="px-4 py-3 bg-blue-600 hover:bg-blue-500 text-white text-sm rounded-lg transition-colors min-h-[60px] min-w-[60px]"
                >
                  📋 Копировать
                </button>
                <button
                  onClick={cutSelection}
                  className="px-4 py-3 bg-orange-600 hover:bg-orange-500 text-white text-sm rounded-lg transition-colors min-h-[60px] min-w-[60px]"
                >
                  ✂ Вырезать
                </button>
                <button
                  onClick={pasteSelection}
                  disabled={!clipboard}
                  className="px-4 py-3 bg-green-600 hover:bg-green-500 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white text-sm rounded-lg transition-colors min-h-[60px] min-w-[60px]"
                >
                  📌 Вставить
                </button>
                <button
                  onClick={duplicateSelection}
                  className="px-4 py-3 bg-purple-600 hover:bg-purple-500 text-white text-sm rounded-lg transition-colors min-h-[60px] min-w-[60px]"
                >
                  ⬛ Дублировать
                </button>
                <button
                  onClick={deleteSelection}
                  className="px-4 py-3 bg-red-600 hover:bg-red-500 text-white text-sm rounded-lg transition-colors min-h-[60px] min-w-[60px]"
                >
                  🗑 Удалить
                </button>
                <button
                  onClick={clearSelection}
                  className="px-4 py-3 bg-zinc-600 hover:bg-zinc-500 text-white text-sm rounded-lg transition-colors min-h-[60px] min-w-[60px]"
                >
                  ✕ Снять
                </button>
              </div>
            </div>
          )}

          {/* Масштаб (Зум) */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Масштаб:</label>
            <div className="flex items-center gap-2 mb-2">
              <button
                onClick={() => setZoom(prev => Math.max(0.5, prev - 0.25))}
                className="w-10 h-10 bg-zinc-700 hover:bg-zinc-600 text-white rounded-lg transition-colors flex items-center justify-center text-xl"
              >
                −
              </button>
              <span className="text-white font-bold text-lg flex-1 text-center">
                {Math.round(zoom * 100)}%
              </span>
              <button
                onClick={() => setZoom(prev => Math.min(4, prev + 0.25))}
                className="w-10 h-10 bg-zinc-700 hover:bg-zinc-600 text-white rounded-lg transition-colors flex items-center justify-center text-xl"
              >
                +
              </button>
              <button
                onClick={() => setZoom(1)}
                className="px-3 h-10 bg-blue-600 hover:bg-blue-500 text-white text-sm rounded-lg transition-colors"
              >
                Сброс
              </button>
            </div>
          </div>

          {/* Palette - сверху */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Палитра:</label>
            <div className="grid grid-cols-8 gap-1">
              {DEFAULT_PALETTE.map((color, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentColor(color)}
                  className={`w-6 h-6 rounded border-2 transition-transform ${
                    currentColor === color ? 'border-white scale-110' : 'border-zinc-600'
                  }`}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
            <input
              type="color"
              value={currentColor}
              onChange={(e) => setCurrentColor(e.target.value)}
              className="w-full mt-2 h-8 rounded cursor-pointer"
            />
          </div>

          {/* Current color - снизу */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Текущий цвет:</label>
            <div
              className="w-full h-12 rounded-lg border-2 border-zinc-600"
              style={{ backgroundColor: currentColor }}
            />
          </div>

          {/* Tools */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Инструменты:</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setCurrentTool('brush')}
                className={`p-2 rounded-lg transition-colors ${
                  currentTool === 'brush' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Кисть"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M9.06 11.9l8.07-8.06a2.85 2.85 0 114.03 4.03l-8.06 8.08"/>
                  <path d="M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 00-3-3.02z"/>
                </svg>
              </button>
              <button
                onClick={() => setCurrentTool('fill')}
                className={`p-2 rounded-lg transition-colors ${
                  currentTool === 'fill' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Заливка"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M2.5 16.5c0-2 1.5-3.5 3.5-3.5s3.5 1.5 3.5 3.5-1.5 3.5-3.5 3.5-3.5-1.5-3.5-3.5z"/>
                  <path d="M12 2l4 4-8 8-4-4 8-8z"/>
                  <path d="M16 6l4 4"/>
                </svg>
              </button>
              <button
                onClick={() => setCurrentTool('eyedropper')}
                className={`p-2 rounded-lg transition-colors ${
                  currentTool === 'eyedropper' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Пипетка"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M2 22l1-1h3l9-9"/>
                  <path d="M3 21v-3l9-9"/>
                  <path d="M14.5 5.5l4 4"/>
                  <path d="M18.5 1.5a2.12 2.12 0 013 3l-1 1-4-4 1-1z"/>
                  <path d="M12 8l4 4"/>
                </svg>
              </button>
              <button
                onClick={() => setCurrentTool('eraser')}
                className={`p-2 rounded-lg transition-colors ${
                  currentTool === 'eraser' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Ластик"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M20 20H7L3 16c-.8-.8-.8-2 0-2.8L14.2 2c.8-.8 2-.8 2.8 0L21.8 6.8c.8.8.8 2 0 2.8L11 20"/>
                  <path d="M6 11l4 4"/>
                </svg>
              </button>
              <button
                onClick={() => setCurrentTool('select')}
                className={`p-2 rounded-lg transition-colors ${
                  currentTool === 'select' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Выделение"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="3" width="7" height="7" strokeDasharray="2 2"/>
                  <rect x="14" y="3" width="7" height="7" strokeDasharray="2 2"/>
                  <rect x="3" y="14" width="7" height="7" strokeDasharray="2 2"/>
                  <rect x="14" y="14" width="7" height="7" strokeDasharray="2 2"/>
                </svg>
              </button>
              <button
                onClick={undo}
                className="p-2 rounded-lg bg-zinc-700 hover:bg-zinc-600 transition-colors"
                title="Отменить"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 7v6h6"/>
                  <path d="M21 17a9 9 0 00-9-9 9 9 0 00-6 2.3L3 13"/>
                </svg>
              </button>
              <button
                onClick={redo}
                className="p-2 rounded-lg bg-zinc-700 hover:bg-zinc-600 transition-colors"
                title="Повторить"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 7v6h-6"/>
                  <path d="M3 17a9 9 0 019-9 9 9 0 016 2.3l3 2.7"/>
                </svg>
              </button>
            </div>
          </div>

          {/* Brush size */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Размер кисти:</label>
            <div className="grid grid-cols-4 gap-2">
              {[1, 2, 3, 4].map(size => (
                <button
                  key={size}
                  onClick={() => setBrushSize(size)}
                  className={`p-2 rounded-lg text-sm font-bold transition-colors ${
                    brushSize === size ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Grid size */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Размер холста:</label>
            <div className="grid grid-cols-2 gap-2">
              {[8, 16, 32, 64].map(size => (
                <button
                  key={size}
                  onClick={() => changeGridSize(size)}
                  className={`p-2 rounded-lg text-sm font-bold transition-colors ${
                    gridSize === size ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                  }`}
                >
                  {size}×{size}
                </button>
              ))}
            </div>
          </div>

          {/* Options */}
          <div className="bg-zinc-800 rounded-xl p-4 space-y-2">
            <label className="flex items-center gap-2 text-white text-sm">
              <input
                type="checkbox"
                checked={showGrid}
                onChange={(e) => setShowGrid(e.target.checked)}
                className="w-4 h-4"
              />
              Показать сетку
            </label>
            <label className="flex items-center gap-2 text-white text-sm">
              <input
                type="checkbox"
                checked={transparentBg}
                onChange={(e) => setTransparentBg(e.target.checked)}
                className="w-4 h-4"
              />
              Прозрачный фон
            </label>
          </div>

          {/* Mirror */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Зеркало:</label>
            <div className="grid grid-cols-4 gap-2">
              <button
                onClick={() => setMirrorMode('off')}
                className={`p-2 rounded-lg text-xs font-bold transition-colors ${
                  mirrorMode === 'off' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
              >
                Выкл
              </button>
              <button
                onClick={() => setMirrorMode('x')}
                className={`p-2 rounded-lg text-xs font-bold transition-colors ${
                  mirrorMode === 'x' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Зеркало по горизонтали (вертикальная ось)"
              >
                X
              </button>
              <button
                onClick={() => setMirrorMode('y')}
                className={`p-2 rounded-lg text-xs font-bold transition-colors ${
                  mirrorMode === 'y' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Зеркало по вертикали (горизонтальная ось)"
              >
                Y
              </button>
              <button
                onClick={() => setMirrorMode('xy')}
                className={`p-2 rounded-lg text-xs font-bold transition-colors ${
                  mirrorMode === 'xy' ? 'bg-blue-600' : 'bg-zinc-700 hover:bg-zinc-600'
                }`}
                title="Зеркало по обеим осям"
              >
                XY
              </button>
            </div>
          </div>

          {/* Переключатель стиля курсора */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">Курсор:</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setCursorStyle('pointer')}
                className={`p-3 rounded-lg text-sm font-bold transition-colors ${
                  cursorStyle === 'pointer' ? 'bg-blue-600 text-white' : 'bg-zinc-700 hover:bg-zinc-600 text-zinc-300'
                }`}
                title="Палочка вниз от точки прицеливания"
              >
                🖊 Палочка
              </button>
              <button
                onClick={() => setCursorStyle('crosshair')}
                className={`p-3 rounded-lg text-sm font-bold transition-colors ${
                  cursorStyle === 'crosshair' ? 'bg-blue-600 text-white' : 'bg-zinc-700 hover:bg-zinc-600 text-zinc-300'
                }`}
                title="Перекрестие на весь холст"
              >
                ✛ Cross
              </button>
              <button
                onClick={() => setCursorStyle('dot')}
                className={`p-3 rounded-lg text-sm font-bold transition-colors ${
                  cursorStyle === 'dot' ? 'bg-blue-600 text-white' : 'bg-zinc-700 hover:bg-zinc-600 text-zinc-300'
                }`}
                title="Только точка"
              >
                ● Точка
              </button>
            </div>
          </div>

          {/* Ползунок смещения для курсора «Палочка» */}
          <div className="bg-zinc-800 rounded-xl p-4">
            <label className="text-zinc-400 text-xs block mb-2">
              Смещение курсора: {pointerOffset} px
            </label>
            <input
              type="range"
              min="0"
              max="120"
              step="10"
              value={pointerOffset}
              onChange={(e) => setPointerOffset(Number(e.target.value))}
              disabled={cursorStyle !== 'pointer'}
              className="w-full h-2 bg-zinc-600 rounded-lg appearance-none cursor-pointer accent-blue-500 disabled:opacity-40"
            />
            <div className="flex justify-between text-xs text-zinc-500 mt-1">
              <span>0</span>
              <span>120</span>
            </div>
            {cursorStyle !== 'pointer' && (
              <p className="text-zinc-500 text-xs mt-2">
                Работает только для курсора «Палочка»
              </p>
            )}
          </div>

          {/* Export */}
          <button
            onClick={() => setShowExportModal(true)}
            className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
          >
            📥 Экспорт
          </button>
        </div>
      </div>

      {/* Save Modal */}
      {showSaveModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="bg-zinc-800 rounded-2xl p-6 max-w-md w-full mx-4">
            <h2 className="text-xl font-bold text-white mb-4">Сохранить в пресет</h2>
            
            <div className="space-y-4">
              {/* БАГ 6 FIX: Радио-кнопки для выбора режима сохранения */}
              {emojiPresets.length > 0 && (
                <div>
                  <label className="flex items-center gap-2 text-white text-sm mb-2">
                    <input
                      type="radio"
                      checked={saveMode === 'existing'}
                      onChange={() => setSaveMode('existing')}
                      className="w-4 h-4"
                    />
                    Добавить в существующий пресет:
                  </label>
                  <select
                    value={selectedPresetId}
                    onChange={(e) => setSelectedPresetId(e.target.value)}
                    disabled={saveMode !== 'existing'}
                    className="w-full bg-zinc-700 text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                  >
                    <option value="">Выберите пресет...</option>
                    {emojiPresets.map(preset => (
                      <option key={preset.id} value={preset.id}>
                        {preset.name} ({preset.emojis.length} картинок)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="flex items-center gap-2 text-white text-sm mb-2">
                  <input
                    type="radio"
                    checked={saveMode === 'new'}
                    onChange={() => setSaveMode('new')}
                    className="w-4 h-4"
                  />
                  Создать новый пресет:
                </label>
                <input
                  type="text"
                  value={newPresetName}
                  onChange={(e) => setNewPresetName(e.target.value)}
                  placeholder="Название пресета"
                  disabled={saveMode !== 'new'}
                  className="w-full bg-zinc-700 text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowSaveModal(false);
                    setNewPresetName('');
                    setSelectedPresetId('');
                  }}
                  className="flex-1 bg-zinc-700 hover:bg-zinc-600 text-white py-2 rounded-lg transition-colors duration-150"
                >
                  Отмена
                </button>
                <button
                  onClick={saveToPreset}
                  disabled={
                    (saveMode === 'existing' && !selectedPresetId) ||
                    (saveMode === 'new' && !newPresetName.trim())
                  }
                  className="flex-1 bg-green-600 hover:bg-green-500 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white font-bold py-2 rounded-lg transition-colors duration-150"
                >
                  Сохранить
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="bg-zinc-800 rounded-2xl p-6 max-w-md w-full mx-4">
            <h2 className="text-xl font-bold text-white mb-4">Экспорт анимации</h2>
            
            <div className="space-y-3">
              <button
                onClick={() => {
                  exportPNG();
                  setShowExportModal(false);
                }}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
              >
                📥 Скачать текущий кадр (PNG)
              </button>

              <button
                onClick={() => {
                  exportSpriteSheet();
                  setShowExportModal(false);
                  setToast('Спрайт-лист экспортирован!');
                  setTimeout(() => setToast(null), 3000);
                }}
                disabled={frames.length < 2}
                className="w-full bg-purple-600 hover:bg-purple-500 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white font-bold py-3 rounded-xl transition-colors duration-150"
              >
                🎞️ Скачать спрайт-лист ({frames.length} кадров)
              </button>

              <button
                onClick={() => {
                  exportGIF();
                  setShowExportModal(false);
                }}
                disabled={frames.length < 2}
                className="w-full bg-pink-600 hover:bg-pink-500 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white font-bold py-3 rounded-xl transition-colors duration-150"
              >
                📀 Скачать GIF ({frames.length} кадров)
              </button>

              <div className="border-t border-zinc-700 pt-3">
                <h3 className="text-white font-semibold mb-3">Сохранить все кадры в пресет</h3>
                
                {emojiPresets.length > 0 && (
                  <div className="mb-3">
                    <label className="flex items-center gap-2 text-white text-sm mb-2">
                      <input
                        type="radio"
                        checked={saveMode === 'existing'}
                        onChange={() => setSaveMode('existing')}
                        className="w-4 h-4"
                      />
                      Добавить в существующий пресет:
                    </label>
                    <select
                      value={selectedPresetId}
                      onChange={(e) => setSelectedPresetId(e.target.value)}
                      disabled={saveMode !== 'existing'}
                      className="w-full bg-zinc-700 text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                    >
                      <option value="">Выберите пресет...</option>
                      {emojiPresets.map(preset => (
                        <option key={preset.id} value={preset.id}>
                          {preset.name} ({preset.emojis.length} картинок)
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="mb-3">
                  <label className="flex items-center gap-2 text-white text-sm mb-2">
                    <input
                      type="radio"
                      checked={saveMode === 'new'}
                      onChange={() => setSaveMode('new')}
                      className="w-4 h-4"
                    />
                    Создать новый пресет:
                  </label>
                  <input
                    type="text"
                    value={newPresetName}
                    onChange={(e) => setNewPresetName(e.target.value)}
                    placeholder="Название пресета"
                    disabled={saveMode !== 'new'}
                    className="w-full bg-zinc-700 text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowExportModal(false);
                      setNewPresetName('');
                      setSelectedPresetId('');
                    }}
                    className="flex-1 bg-zinc-700 hover:bg-zinc-600 text-white py-2 rounded-lg transition-colors duration-150"
                  >
                    Отмена
                  </button>
                  <button
                    onClick={saveAllFramesToPreset}
                    disabled={
                      (saveMode === 'existing' && !selectedPresetId) ||
                      (saveMode === 'new' && !newPresetName.trim())
                    }
                    className="flex-1 bg-green-600 hover:bg-green-500 disabled:bg-zinc-600 disabled:cursor-not-allowed text-white font-bold py-2 rounded-lg transition-colors duration-150"
                  >
                    Сохранить {frames.length} кадров
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-4 right-4 bg-green-600 text-white px-6 py-3 rounded-xl shadow-lg animate-pulse">
          {toast}
        </div>
      )}

      {/* Кнопка переключения режимов: рисование / панорамирование / просмотр - в левом нижнем углу экрана */}
      <button
        onClick={() => {
          const modes: InteractionMode[] = ['draw', 'pan', 'view'];
          const current = modes.indexOf(interactionMode);
          setInteractionMode(modes[(current + 1) % 3]);
        }}
        onTouchStart={(e) => {
          e.stopPropagation();
        }}
        className={`fixed bottom-4 left-4 w-20 h-20 rounded-full 
                    shadow-2xl flex items-center justify-center text-3xl 
                    transition-colors z-50 ${
          interactionMode === 'draw' ? 'bg-green-600 hover:bg-green-500 text-white' :
          interactionMode === 'pan'  ? 'bg-blue-600 hover:bg-blue-500 text-white' :
                                       'bg-zinc-600 hover:bg-zinc-500 text-zinc-300'
        }`}
        title={
          interactionMode === 'draw' ? 'Рисование' :
          interactionMode === 'pan'  ? 'Перемещение холста' :
                                       'Просмотр'
        }
      >
        {interactionMode === 'draw' ? '✏️' :
         interactionMode === 'pan'  ? '🖐' :
                                      '👁'}
      </button>
    </div>
  );
}
