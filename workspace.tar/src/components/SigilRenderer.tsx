/**
 * SVG-компонент рендеринга Световой Матрицы Адама Кадмона и сигилы
 */

import React, { forwardRef, useMemo } from 'react';
import { CENTER, RINGS, RING_BOUNDARIES, Ring } from '../lib/rosaCross';
import type { SigilPoint } from '../lib/sigilBuilder';

export type SigilStyle = 'classic' | 'metallic';
export type SigilColor = 'purple' | 'red' | 'green' | 'custom';

export interface SigilRendererProps {
  style: SigilStyle;
  sigilColor: SigilColor;
  customColor?: string;
  fullPath: string;
  points: SigilPoint[];
  startPoint: { x: number; y: number };
  endPoint: { x: number; y: number };
  lastDirection: { x: number; y: number };
  isEndPointRepeat: boolean;
  animated: boolean;
  animationDuration: number;
  showWord: boolean;
  showNormalized: boolean;
  showCutLine: boolean;
  word: string;
  normalizedString: string;
}

const SIGIL_COLORS: Record<Exclude<SigilColor, 'custom'>, string> = {
  purple: '#6b21a8',
  red: '#dc2626',
  green: '#059669',
};

interface StyleColors {
  bg: string;
  ringStroke: string;
  ringFill: string;
  letterColor: string;
  textColor: string;
  separatorStroke: string;
  matrixLineOpacity: number;
}

function getStyleColors(style: SigilStyle): StyleColors {
  switch (style) {
    case 'classic':
      return {
        bg: '#f5e6c8',
        ringStroke: '#333',
        ringFill: 'none',
        letterColor: '#333',
        textColor: '#333',
        separatorStroke: '#555',
        matrixLineOpacity: 0.3,
      };
    case 'metallic':
      return {
        bg: '#1a1a2e',
        ringStroke: '#888',
        ringFill: 'none',
        letterColor: '#000000',
        textColor: '#ffffff',
        separatorStroke: '#555',
        matrixLineOpacity: 0.5,
      };
  }
}

function getSigilStrokeColor(sigilColor: SigilColor, customColor?: string): string {
  if (sigilColor === 'custom' && customColor) return customColor;
  if (sigilColor === 'custom') return '#6b21a8';
  return SIGIL_COLORS[sigilColor];
}

interface LineData {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

interface LetterPos {
  letter: string;
  x: number;
  y: number;
}

/**
 * Координаты буквы для отрисовки текста
 * Формула: angle = (index * sectorAngle) + (sectorAngle / 2) - 90
 * 
 * ВАЖНО: Это отличается от формулы для линий секторов!
 * Линии секторов: angle = i * sectorAngle - 90 (границы секторов)
 * Буквы: angle = i * sectorAngle + sectorAngle/2 - 90 (центры секторов)
 */
function getLetterPos(letter: string, ring: Ring): LetterPos | null {
  const config = RINGS[ring];
  const idx = config.letters.indexOf(letter);
  if (idx === -1) return null;

  const sectorAngle = 360 / config.total;
  
  // Буква центрирована в секторе: добавляем половину угла сектора
  const letterAngle = (idx * sectorAngle) + (sectorAngle / 2) - 90;
  const rad = (letterAngle * Math.PI) / 180;

  return {
    letter,
    x: CENTER.x + config.radius * Math.cos(rad),
    y: CENTER.y + config.radius * Math.sin(rad),
  };
}

const SigilRenderer = forwardRef<SVGSVGElement, SigilRendererProps>(
  (props, ref) => {
    const {
      style, sigilColor, customColor, fullPath, points, startPoint, endPoint, lastDirection, isEndPointRepeat, animated, animationDuration,
      showWord, showNormalized, showCutLine, word, normalizedString
    } = props;

    const colors = getStyleColors(style);
    const strokeColor = getSigilStrokeColor(sigilColor, customColor);
    const cx = CENTER.x;
    const cy = CENTER.y;

    // Секторы внешнего кольца (11)
    // ВАЖНО: Линии секторов используют формулу angle = i * sectorAngle - 90
    // Это ГРАНИЦЫ секторов, а буквы центрированы в секторах (angle + sectorAngle/2)
    const outerSectors: LineData[] = useMemo(() => {
      const lines: LineData[] = [];
      const total = RINGS.outer.total;
      const sectorAngle = 360 / total;
      for (let i = 0; i < total; i++) {
        // Линия на границе сектора (без смещения на половину)
        const angle = ((i * sectorAngle) - 90) * Math.PI / 180;
        lines.push({
          x1: cx + RING_BOUNDARIES.middle * Math.cos(angle),
          y1: cy + RING_BOUNDARIES.middle * Math.sin(angle),
          x2: cx + RING_BOUNDARIES.outer * Math.cos(angle),
          y2: cy + RING_BOUNDARIES.outer * Math.sin(angle),
        });
      }
      return lines;
    }, []);

    // Секторы среднего кольца (11)
    const middleSectors: LineData[] = useMemo(() => {
      const lines: LineData[] = [];
      const total = RINGS.middle.total;
      const sectorAngle = 360 / total;
      for (let i = 0; i < total; i++) {
        const angle = ((i * sectorAngle) - 90) * Math.PI / 180;
        lines.push({
          x1: cx + RING_BOUNDARIES.inner * Math.cos(angle),
          y1: cy + RING_BOUNDARIES.inner * Math.sin(angle),
          x2: cx + RING_BOUNDARIES.middle * Math.cos(angle),
          y2: cy + RING_BOUNDARIES.middle * Math.sin(angle),
        });
      }
      return lines;
    }, []);

    // Лучи центра (5)
    const centerRays: LineData[] = useMemo(() => {
      const lines: LineData[] = [];
      const total = RINGS.center.total;
      const sectorAngle = 360 / total;
      for (let i = 0; i < total; i++) {
        const angle = ((i * sectorAngle) - 90) * Math.PI / 180;
        lines.push({
          x1: cx,
          y1: cy,
          x2: cx + RING_BOUNDARIES.inner * Math.cos(angle),
          y2: cy + RING_BOUNDARIES.inner * Math.sin(angle),
        });
      }
      return lines;
    }, []);

    // Позиции букв для каждого кольца
    const outerLetterPositions: LetterPos[] = useMemo(() => {
      return RINGS.outer.letters.map((l) => getLetterPos(l, 'outer')!).filter(Boolean);
    }, []);

    const middleLetterPositions: LetterPos[] = useMemo(() => {
      return RINGS.middle.letters.map((l) => getLetterPos(l, 'middle')!).filter(Boolean);
    }, []);

    const innerLetterPositions: LetterPos[] = useMemo(() => {
      return RINGS.inner.letters.map((l) => getLetterPos(l, 'inner')!).filter(Boolean);
    }, []);

    const centerLetterPositions: LetterPos[] = useMemo(() => {
      return RINGS.center.letters.map((l) => getLetterPos(l, 'center')!).filter(Boolean);
    }, []);

    const sigilStrokeWidth = style === 'classic' ? 4 : 3.5;
    const matrixStrokeWidth = 1.2;
    const textY = 560;

    return (
      <svg
        ref={ref}
        viewBox="0 0 600 650"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        {/* Фон */}
        <rect x="0" y="0" width="600" height="650" fill={colors.bg} />

        {/* Крест — вертикальная и горизонтальная линии */}
        <line x1={cx} y1={cy - RING_BOUNDARIES.outer - 20} x2={cx} y2={cy + RING_BOUNDARIES.outer + 20}
          stroke={colors.separatorStroke} strokeWidth={matrixStrokeWidth} opacity={colors.matrixLineOpacity} />
        <line x1={cx - RING_BOUNDARIES.outer - 20} y1={cy} x2={cx + RING_BOUNDARIES.outer + 20} y2={cy}
          stroke={colors.separatorStroke} strokeWidth={matrixStrokeWidth} opacity={colors.matrixLineOpacity} />

        {/* Окружности */}
        <circle cx={cx} cy={cy} r={RING_BOUNDARIES.outer}
          fill="none" stroke={colors.ringStroke} strokeWidth={matrixStrokeWidth} />
        <circle cx={cx} cy={cy} r={RING_BOUNDARIES.middle}
          fill="none" stroke={colors.ringStroke} strokeWidth={matrixStrokeWidth} />
        <circle cx={cx} cy={cy} r={RING_BOUNDARIES.inner}
          fill="none" stroke={colors.ringStroke} strokeWidth={matrixStrokeWidth} />
        <circle cx={cx} cy={cy} r={RING_BOUNDARIES.center}
          fill="none" stroke={colors.ringStroke} strokeWidth={matrixStrokeWidth} />

        {/* Секторы внешнего кольца */}
        {outerSectors.map((line, i) => (
          <line key={`os-${i}`} x1={line.x1} y1={line.y1} x2={line.x2} y2={line.y2}
            stroke={colors.ringStroke} strokeWidth={matrixStrokeWidth * 0.7} opacity={0.15} />
        ))}

        {/* Секторы среднего кольца */}
        {middleSectors.map((line, i) => (
          <line key={`ms-${i}`} x1={line.x1} y1={line.y1} x2={line.x2} y2={line.y2}
            stroke={colors.ringStroke} strokeWidth={matrixStrokeWidth * 0.7} opacity={0.15} />
        ))}

        {/* Лучи центра */}
        {centerRays.map((line, i) => (
          <line key={`cr-${i}`} x1={line.x1} y1={line.y1} x2={line.x2} y2={line.y2}
            stroke={colors.ringStroke} strokeWidth={matrixStrokeWidth * 0.7} opacity={0.15} />
        ))}

        {/* Буквы — внешнее кольцо */}
        {outerLetterPositions.map((pos, i) => (
          <text key={`ol-${i}`} x={pos.x} y={pos.y}
            textAnchor="middle" dominantBaseline="central"
            fontSize="14" fontWeight="bold"
            fill={colors.letterColor}>
            {pos.letter}
          </text>
        ))}

        {/* Буквы — среднее кольцо */}
        {middleLetterPositions.map((pos, i) => (
          <text key={`ml-${i}`} x={pos.x} y={pos.y}
            textAnchor="middle" dominantBaseline="central"
            fontSize="14" fontWeight="bold"
            fill={colors.letterColor}>
            {pos.letter}
          </text>
        ))}

        {/* Буквы — внутреннее кольцо */}
        {innerLetterPositions.map((pos, i) => (
          <text key={`il-${i}`} x={pos.x} y={pos.y}
            textAnchor="middle" dominantBaseline="central"
            fontSize="13" fontWeight="bold"
            fill={colors.letterColor}>
            {pos.letter}
          </text>
        ))}

        {/* Буквы — центр */}
        {centerLetterPositions.map((pos, i) => (
          <text key={`cl-${i}`} x={pos.x} y={pos.y}
            textAnchor="middle" dominantBaseline="central"
            fontSize="11" fontWeight="bold"
            fill={colors.letterColor}>
            {pos.letter}
          </text>
        ))}

        {/* Сигила */}
        {fullPath && (
          <>
            {/* Начало — полый кружок (стартовая точка) */}
            {points.length > 0 && (
              <circle
                cx={startPoint.x}
                cy={startPoint.y}
                r={6}
                fill="none"
                stroke={strokeColor}
                strokeWidth={2.5}
              />
            )}

            {/* Путь сигилы */}
            <path
              d={fullPath}
              fill="none"
              stroke={strokeColor}
              strokeWidth={sigilStrokeWidth}
              strokeLinecap="round"
              strokeLinejoin="round"
              style={animated ? {
                strokeDasharray: '3000',
                strokeDashoffset: '3000',
                animation: `drawSigil ${animationDuration}ms linear forwards`,
              } : undefined}
            />

            {/* Круги с точками на повторных буквах */}
            {points.filter(p => p.isRepeat).map((p, i) => (
              <g key={`repeat-${i}`}>
                <circle
                  cx={p.x}
                  cy={p.y}
                  r={10}
                  fill="none"
                  stroke={strokeColor}
                  strokeWidth={2}
                  style={animated ? {
                    opacity: 0,
                    animation: `fadeIn 0.1s ${animationDuration}ms forwards`,
                  } : undefined}
                />
                <circle
                  cx={p.x}
                  cy={p.y}
                  r={2}
                  fill={strokeColor}
                  style={animated ? {
                    opacity: 0,
                    animation: `fadeIn 0.1s ${animationDuration}ms forwards`,
                  } : undefined}
                />
              </g>
            ))}

            {/* Конец — засечка */}
            {points.length > 1 && (
              <EndMark
                x={endPoint.x}
                y={endPoint.y}
                directionX={lastDirection.x}
                directionY={lastDirection.y}
                isRepeat={isEndPointRepeat}
                color={strokeColor}
                animated={animated}
                delay={animated ? animationDuration * 0.9 : 0}
              />
            )}
          </>
        )}

        {/* Текст под сигилой */}
        {(showWord || showNormalized) && (
          <>
            {showCutLine && (
              <line x1="50" y1={textY - 25} x2="550" y2={textY - 25}
                stroke={colors.separatorStroke} strokeWidth="1" strokeDasharray="6,4" />
            )}
            {showWord && (
              <text x={cx} y={textY - 5}
                textAnchor="middle" fontSize="18" fontWeight="bold"
                fill={colors.textColor}>
                {word}
              </text>
            )}
            {showNormalized && (
              <text x={cx} y={textY + 20}
                textAnchor="middle" fontSize="13"
                fill={colors.textColor} opacity={0.8}>
                {normalizedString}
              </text>
            )}
          </>
        )}

        {/* CSS анимация */}
        <style>{`
          @keyframes drawSigil {
            from { stroke-dashoffset: 3000; }
            to { stroke-dashoffset: 0; }
          }
          @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
          }
        `}</style>
      </svg>
    );
  }
);

SigilRenderer.displayName = 'SigilRenderer';

function EndMark({ x, y, directionX, directionY, isRepeat, color, animated, delay }: {
  x: number; y: number; directionX: number; directionY: number; isRepeat: boolean;
  color: string; animated: boolean; delay: number;
}) {
  // directionX/directionY — нормализованное направление последнего отрезка
  const len = Math.sqrt(directionX * directionX + directionY * directionY);
  if (len === 0) return null;

  // Перпендикуляр к направлению
  const px = -directionY / len;
  const py = directionX / len;
  const markLen = 7; // Половина длины засечки (итого 14px)

  // Если endPoint - повторная точка, сдвигаем засечку на расстояние R_CIRCLE + 6 = 16 от центра
  const R_CIRCLE = 10;
  const offset = isRepeat ? R_CIRCLE + 6 : 0;
  const markX = x + directionX * offset;
  const markY = y + directionY * offset;

  return (
    <line
      x1={markX - px * markLen}
      y1={markY - py * markLen}
      x2={markX + px * markLen}
      y2={markY + py * markLen}
      stroke={color}
      strokeWidth={3}
      strokeLinecap="round"
      style={animated ? {
        opacity: 0,
        animation: `fadeIn 0.1s ${delay}ms forwards`,
      } : undefined}
    />
  );
}

export default SigilRenderer;
