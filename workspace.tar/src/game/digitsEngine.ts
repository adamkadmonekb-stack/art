import { soundManager } from './audio';

export class DigitsEngine {
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private container: HTMLDivElement | null = null;
  
  private images: string[] = [];
  private imageCache: Map<string, HTMLImageElement> = new Map();
  
  // БАГ 1: Хранилище на 24 ячейки для каждой строки
  private rowsData: (number | null)[][] = [[]];
  private rows: { x: number; y: number; width: number; height: number; imageIndex: number | null }[][] = [[]];
  private trayItems: { x: number; y: number; width: number; height: number; imageIndex: number }[] = [];
  
  private dragging: { type: 'slot' | 'tray'; rowIndex: number; slotIndex: number; offsetX: number; offsetY: number; x: number; y: number; imageIndex: number; startCursorX: number; startCursorY: number } | null = null;
  private hoveredSlot: { rowIndex: number; slotIndex: number } | null = null;
  
  // БАГ 4, 6: Вертикальная прокрутка
  private trayScrollY = 0;
  private maxTrayScrollY = 0;
  
  private destroyed = false;
  private paused = false;
  private animFrameId = 0;
  
  private handlePointerDown = (e: PointerEvent) => this.onPointerDown(e);
  private handlePointerMove = (e: PointerEvent) => this.onPointerMove(e);
  private handlePointerUp = (e: PointerEvent) => this.onPointerUp(e);
  private handleWheel = (e: WheelEvent) => this.onWheel(e);
  private handleTouchStart = (e: TouchEvent) => this.onTouchStart(e);
  private handleTouchMove = (e: TouchEvent) => this.onTouchMove(e);
  private handleTouchEnd = () => this.onTouchEnd();
  
  private touchStartY = 0;
  private touchStartScrollY = 0;
  private isTouchScrolling = false;
  
  private squareSizeFactor = 100;
  private slotCount = 12;
  
  // Подсветка картинок
  private highlights: Map<string, 'red' | 'yellow' | 'green' | 'blue' | 'purple'> = new Map();
  private longPressTimer: number | null = null;
  private longPressTarget: { type: 'slot' | 'tray'; rowIndex: number; slotIndex: number; imageIndex: number } | null = null;
  private longPressStart: { x: number; y: number; time: number; targetItem: any } | null = null;
  private longPressActive: boolean = false;
  private showPalette: boolean = false;
  private palettePosition: { x: number; y: number } = { x: 0, y: 0 };
  private paletteTarget: string | null = null; // imageIndex для подсветки
  
  // Поля для отслеживания pointer events
  private pointerDownTime = 0;
  private pointerDownX = 0;
  private pointerDownY = 0;
  private pointerMoved = false;
  private longPressFired = false;
  private pointerDownItem: { type: 'slot' | 'tray'; rowIndex: number; slotIndex: number; imageIndex: number } | null = null;
  
  // Новое состояние для отслеживания указателя
  private handleContextMenu = (e: MouseEvent) => this.onContextMenu(e);
  
  async init(container: HTMLDivElement, images: string[], squareSizeFactor: number = 100, slotCount: number = 12): Promise<void> {
    this.destroyed = false;
    this.container = container;
    this.images = images;
    this.squareSizeFactor = squareSizeFactor;
    this.slotCount = slotCount;
    this.rowsData = [[]];
    this.rows = [[]];
    
    // БАГ 7: Предзагрузка изображений
    this.preloadImages();
    
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;
    
    this.canvas = document.createElement('canvas');
    this.canvas.width = width;
    this.canvas.height = height;
    this.canvas.style.width = '100%';
    this.canvas.style.height = '100%';
    this.canvas.style.display = 'block';
    this.canvas.style.touchAction = 'none';
    
    this.ctx = this.canvas.getContext('2d');
    container.appendChild(this.canvas);
    
    this.canvas.addEventListener('pointerdown', this.handlePointerDown);
    this.canvas.addEventListener('pointermove', this.handlePointerMove);
    this.canvas.addEventListener('pointerup', this.handlePointerUp);
    this.canvas.addEventListener('pointercancel', this.handlePointerUp);
    this.canvas.addEventListener('wheel', this.handleWheel, { passive: false });
    this.canvas.addEventListener('touchstart', this.handleTouchStart, { passive: false });
    this.canvas.addEventListener('touchmove', this.handleTouchMove, { passive: false });
    this.canvas.addEventListener('touchend', this.handleTouchEnd);
    this.canvas.addEventListener('touchcancel', this.handleTouchEnd);
    this.canvas.addEventListener('contextmenu', this.handleContextMenu);
    
    // Загрузить подсветки
    this.loadHighlights();
    
    this.layoutRows();
    this.layoutTray();
    
    this.animFrameId = requestAnimationFrame(this.gameLoop);
  }
  
  // БАГ 7: Кэширование изображений
  private preloadImages(): void {
    this.imageCache.clear();
    for (const src of this.images) {
      const img = new Image();
      img.src = src;
      this.imageCache.set(src, img);
    }
  }
  
  private getCachedImage(src: string): HTMLImageElement | null {
    const img = this.imageCache.get(src);
    if (img && img.complete && img.naturalWidth > 0) {
      return img;
    }
    return null;
  }
  
  private layoutRows(): void {
    if (!this.canvas) return;
    
    const w = this.canvas.width;
    const h = this.canvas.height;
    const slotCount = this.slotCount;
    const rowCount = this.rows.length;
    const gap = 8;
    const rowGap = 20;
    
    const availableHeight = h * 0.5;
    const rowHeight = (availableHeight - rowGap * (rowCount - 1)) / rowCount;
    
    const availableWidth = w - gap * (slotCount - 1);
    const maxSize = Math.min(availableWidth / slotCount, rowHeight);
    
    const maxFactor = rowCount === 1 ? 200 : rowCount === 2 ? 150 : rowCount === 3 ? 130 : 120;
    const limitedFactor = Math.min(this.squareSizeFactor, maxFactor);
    let slotSize = maxSize * (limitedFactor / 100);
    
    let totalWidth = slotCount * slotSize + (slotCount - 1) * gap;
    if (totalWidth > w) {
      slotSize = (w - gap * (slotCount - 1)) / slotCount;
      totalWidth = slotCount * slotSize + (slotCount - 1) * gap;
    }
    
    const startX = (w - totalWidth) / 2;
    const startY = 50;
    
    // БАГ 1: Сохраняем данные из rowsData
    this.rows = this.rowsData.map((rowData, rowIndex) => {
      const rowY = startY + rowIndex * (slotSize + rowGap);
      
      return Array.from({ length: slotCount }, (_, slotIndex) => ({
        x: startX + slotIndex * (slotSize + gap),
        y: rowY,
        width: slotSize,
        height: slotSize,
        imageIndex: rowData[slotIndex] !== undefined ? rowData[slotIndex] : null,
      }));
    });
  }
  
  // БАГ 5, 6: Лоток 80×80 с вертикальной прокруткой
  private layoutTray(): void {
    if (!this.canvas) return;
    
    const w = this.canvas.width;
    const h = this.canvas.height;
    
    const itemSize = 80; // БАГ 5: увеличено с 60 до 80
    const gap = 8;
    const columns = Math.floor((w - 40) / (itemSize + gap));
    const trayHeight = 250; // БАГ 6: фиксированная высота лотка
    const trayY = h - trayHeight;
    
    // Рассчитываем общую высоту контента
    const rows = Math.ceil(this.images.length / columns);
    const totalHeight = rows * (itemSize + gap);
    const visibleHeight = trayHeight - 20;
    
    this.maxTrayScrollY = Math.max(0, totalHeight - visibleHeight);
    this.trayScrollY = Math.min(this.trayScrollY, this.maxTrayScrollY);
    
    // Размещаем элементы в сетке
    this.trayItems = this.images.map((_, i) => {
      const col = i % columns;
      const row = Math.floor(i / columns);
      
      return {
        x: 20 + col * (itemSize + gap),
        y: trayY + 10 + row * (itemSize + gap) - this.trayScrollY,
        width: itemSize,
        height: itemSize,
        imageIndex: i,
      };
    });
  }
  
  addRow(): void {
    if (this.rows.length >= 4) return;
    
    // БАГ 1: Добавляем пустую строку в rowsData
    const newRowData = Array(24).fill(null);
    this.rowsData.push(newRowData);
    
    const newRow = Array.from({ length: this.slotCount }, () => ({
      x: 0, y: 0, width: 0, height: 0, imageIndex: null,
    }));
    
    this.rows.push(newRow);
    this.layoutRows();
  }
  
  removeRow(rowIndex: number): void {
    if (this.rows.length <= 1) return;
    if (rowIndex < 0 || rowIndex >= this.rows.length) return;
    
    // БАГ 1: Удаляем из rowsData
    this.rowsData.splice(rowIndex, 1);
    this.rows.splice(rowIndex, 1);
    this.layoutRows();
  }
  
  // БАГ 4, 6: Вертикальная прокрутка
  private onWheel(e: WheelEvent): void {
    if (this.destroyed || this.paused || !this.canvas) return;
    
    // Блокировать скролл при long-press
    if (this.longPressActive) {
      e.preventDefault();
      return;
    }
    
    const rect = this.canvas.getBoundingClientRect();
    const scaleY = this.canvas.height / rect.height;
    const y = (e.clientY - rect.top) * scaleY;
    
    const trayY = this.canvas.height - 250;
    
    if (y >= trayY) {
      e.preventDefault();
      const scrollAmount = e.deltaY > 0 ? 50 : -50;
      this.trayScrollY = Math.max(0, Math.min(this.maxTrayScrollY, this.trayScrollY + scrollAmount));
      this.layoutTray();
    }
  }
  
  private onTouchStart(e: TouchEvent): void {
    if (this.destroyed || this.paused || !this.canvas) return;
    
    const touch = e.touches[0];
    const rect = this.canvas.getBoundingClientRect();
    const scaleY = this.canvas.height / rect.height;
    const y = (touch.clientY - rect.top) * scaleY;
    
    const trayY = this.canvas.height - 250;
    
    if (y >= trayY) {
      this.touchStartY = touch.clientY;
      this.touchStartScrollY = this.trayScrollY;
      this.isTouchScrolling = true;
    }
  }
  
  private onTouchMove(e: TouchEvent): void {
    if (!this.isTouchScrolling || !this.canvas) return;
    
    // Блокировать скролл при long-press
    if (this.longPressActive) {
      e.preventDefault();
      return;
    }
    
    e.preventDefault();
    
    const touch = e.touches[0];
    const rect = this.canvas.getBoundingClientRect();
    const scaleY = this.canvas.height / rect.height;
    const deltaY = (this.touchStartY - touch.clientY) * scaleY;
    
    this.trayScrollY = Math.max(0, Math.min(this.maxTrayScrollY, this.touchStartScrollY + deltaY));
    this.layoutTray();
  }
  
  private onTouchEnd(): void {
    this.isTouchScrolling = false;
    this.cancelLongPress();
    this.pointerDownItem = null;
  }
  
  private onContextMenu(e: MouseEvent): void {
    e.preventDefault();
    if (this.destroyed || this.paused || !this.canvas) return;
    
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    
    this.showPaletteAt(x, y);
  }
  
  private cancelLongPress(): void {
    if (this.longPressTimer !== null) {
      clearTimeout(this.longPressTimer);
      this.longPressTimer = null;
    }
    this.longPressTarget = null;
    this.longPressStart = null;
    this.longPressActive = false;
    // Не очищаем pointerState здесь, так как он нужен для обработки drag
  }
  
  private openColorPicker(targetItem: { type: 'slot' | 'tray'; rowIndex: number; slotIndex: number; imageIndex: number }): void {
    // Получить позицию картинки
    let x = 0, y = 0;
    
    if (targetItem.type === 'slot') {
      const slot = this.rows[targetItem.rowIndex][targetItem.slotIndex];
      x = slot.x + slot.width / 2;
      y = slot.y + slot.height / 2;
    } else {
      const item = this.trayItems[targetItem.slotIndex];
      x = item.x + item.width / 2;
      y = item.y + item.height / 2;
    }
    
    // Установить цель палитры
    this.paletteTarget = this.images[targetItem.imageIndex];
    this.palettePosition = { x, y };
    this.showPalette = true;
    
    soundManager.playClick();
  }
  
  private showPaletteAt(x: number, y: number): void {
    // Найти картинку под курсором
    let imageIndex: number | null = null;
    
    // Проверить слоты
    for (let rowIndex = 0; rowIndex < this.rows.length; rowIndex++) {
      const row = this.rows[rowIndex];
      for (let slotIndex = 0; slotIndex < row.length; slotIndex++) {
        const slot = row[slotIndex];
        if (slot.imageIndex !== null &&
            x >= slot.x && x <= slot.x + slot.width &&
            y >= slot.y && y <= slot.y + slot.height) {
          imageIndex = slot.imageIndex;
          break;
        }
      }
      if (imageIndex !== null) break;
    }
    
    // Проверить лоток
    if (imageIndex === null) {
      for (let i = 0; i < this.trayItems.length; i++) {
        const item = this.trayItems[i];
        if (x >= item.x && x <= item.x + item.width &&
            y >= item.y && y <= item.y + item.height) {
          imageIndex = item.imageIndex;
          break;
        }
      }
    }
    
    if (imageIndex !== null && this.images[imageIndex]) {
      this.paletteTarget = this.images[imageIndex];
      this.palettePosition = { x, y };
      this.showPalette = true;
      soundManager.playClick();
    }
  }
  
  private handlePaletteClick(x: number, y: number): void {
    // Палитра - круг с 6 кнопками вокруг центра
    const centerX = this.palettePosition.x;
    const centerY = this.palettePosition.y;
    const radius = 60;
    const buttonRadius = 20;
    
    const colors: Array<'red' | 'yellow' | 'green' | 'blue' | 'purple' | null> = [
      'red', 'yellow', 'green', 'blue', 'purple', null
    ];
    
    // Проверить клик по кнопке "Снять подсветку" (центр)
    const distToCenter = Math.sqrt(
      Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2)
    );
    
    if (distToCenter <= buttonRadius) {
      this.applyHighlight(null);
      return;
    }
    
    // Проверить клик по цветным кнопкам
    for (let i = 0; i < colors.length - 1; i++) {
      const angle = (i * 2 * Math.PI) / 5 - Math.PI / 2;
      const buttonX = centerX + Math.cos(angle) * radius;
      const buttonY = centerY + Math.sin(angle) * radius;
      
      const dist = Math.sqrt(
        Math.pow(x - buttonX, 2) + Math.pow(y - buttonY, 2)
      );
      
      if (dist <= buttonRadius) {
        this.applyHighlight(colors[i]);
        return;
      }
    }
    
    // Клик вне палитры - закрыть
    this.showPalette = false;
    this.paletteTarget = null;
  }
  
  private applyHighlight(color: 'red' | 'yellow' | 'green' | 'blue' | 'purple' | null): void {
    if (!this.paletteTarget) return;
    
    if (color === null) {
      this.highlights.delete(this.paletteTarget);
    } else {
      this.highlights.set(this.paletteTarget, color);
    }
    
    this.showPalette = false;
    this.paletteTarget = null;
    this.saveHighlights();
  }
  
  private getHighlightColor(color: 'red' | 'yellow' | 'green' | 'blue' | 'purple', alpha: number): string {
    const colors = {
      red: `rgba(239, 68, 68, ${alpha})`,
      yellow: `rgba(234, 179, 8, ${alpha})`,
      green: `rgba(34, 197, 94, ${alpha})`,
      blue: `rgba(59, 130, 246, ${alpha})`,
      purple: `rgba(168, 85, 247, ${alpha})`
    };
    return colors[color];
  }
  
  private saveHighlights(): void {
    try {
      const data = Array.from(this.highlights.entries());
      localStorage.setItem('digitsHighlights', JSON.stringify(data));
    } catch (e) {
      console.warn('Failed to save highlights:', e);
    }
  }
  
  private loadHighlights(): void {
    try {
      const data = localStorage.getItem('digitsHighlights');
      if (data) {
        const entries = JSON.parse(data);
        this.highlights = new Map(entries);
      }
    } catch (e) {
      console.warn('Failed to load highlights:', e);
    }
  }
  
  private findItemAt(x: number, y: number): 
    { type: 'slot' | 'tray'; rowIndex: number; slotIndex: number; imageIndex: number } | null {
    
    // Проверить все клетки (в обратном порядке — сверху вниз)
    for (let rowIndex = this.rows.length - 1; rowIndex >= 0; rowIndex--) {
      const row = this.rows[rowIndex];
      for (let slotIndex = row.length - 1; slotIndex >= 0; slotIndex--) {
        const slot = row[slotIndex];
        if (slot.imageIndex !== null &&
            x >= slot.x && x <= slot.x + slot.width &&
            y >= slot.y && y <= slot.y + slot.height) {
          return { type: 'slot', rowIndex, slotIndex, imageIndex: slot.imageIndex };
        }
      }
    }
    
    // Проверить лоток
    for (let i = 0; i < this.trayItems.length; i++) {
      const item = this.trayItems[i];
      if (x >= item.x && x <= item.x + item.width &&
          y >= item.y && y <= item.y + item.height) {
        return { type: 'tray', rowIndex: -1, slotIndex: i, imageIndex: item.imageIndex };
      }
    }
    
    return null;
  }
  
  private returnToTray(imageIndex: number, fromRow: number, fromSlot: number): void {
    // Очистить клетку
    if (fromRow >= 0 && fromSlot >= 0) {
      this.rowsData[fromRow][fromSlot] = null;
      if (this.rows[fromRow] && this.rows[fromRow][fromSlot]) {
        this.rows[fromRow][fromSlot].imageIndex = null;
      }
    }
    
    // Картинка уже "в лотке" — ничего дополнительно не нужно.
    // Лоток строится из this.images, а не из отдельного массива.
    // Достаточно очистить клетку — картинка появится в лотке.
    
    console.log('returnToTray: row=' + fromRow + ', slot=' + fromSlot);
    this.layoutTray();
  }
  
  private onPointerDown(e: PointerEvent): void {
    if (this.destroyed || this.paused || !this.canvas) return;
    
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    
    // Если палитра открыта, проверить клик по ней
    if (this.showPalette) {
      this.handlePaletteClick(x, y);
      return;
    }
    
    // Запомнить состояние pointer down
    this.pointerDownTime = Date.now();
    this.pointerDownX = x;
    this.pointerDownY = y;
    this.pointerMoved = false;
    this.longPressFired = false;
    
    // Запомнить, по какому элементу кликнули
    this.pointerDownItem = this.findItemAt(x, y);
    
    // Запустить long-press таймер
    if (this.longPressTimer) clearTimeout(this.longPressTimer);
    this.longPressTimer = window.setTimeout(() => {
      if (!this.pointerMoved && this.pointerDownItem) {
        this.openColorPicker(this.pointerDownItem);
        this.longPressFired = true;
        this.pointerDownItem = null;
      }
    }, 500);
    
    // Check slots in all rows (reverse order for top-most)
    for (let rowIndex = this.rows.length - 1; rowIndex >= 0; rowIndex--) {
      const row = this.rows[rowIndex];
      for (let slotIndex = row.length - 1; slotIndex >= 0; slotIndex--) {
        const slot = row[slotIndex];
        // БАГ 2: Убран padding, только точные границы
        if (slot.imageIndex !== null &&
            x >= slot.x && x <= slot.x + slot.width &&
            y >= slot.y && y <= slot.y + slot.height) {
          
          // Подготовить drag (но не начинать сразу)
          this.dragging = {
            type: 'slot',
            rowIndex,
            slotIndex,
            offsetX: x - slot.x,
            offsetY: y - slot.y,
            x: slot.x,
            y: slot.y,
            imageIndex: slot.imageIndex,
            startCursorX: x,
            startCursorY: y,
          };
          return;
        }
      }
    }
    
    // Check tray items
    for (let i = this.trayItems.length - 1; i >= 0; i--) {
      const item = this.trayItems[i];
      if (x >= item.x && x <= item.x + item.width &&
          y >= item.y && y <= item.y + item.height) {
        
        // Подготовить drag (но не начинать сразу)
        this.dragging = {
          type: 'tray',
          rowIndex: -1,
          slotIndex: i,
          offsetX: x - item.x,
          offsetY: y - item.y,
          x: item.x,
          y: item.y,
          imageIndex: item.imageIndex,
          startCursorX: x,
          startCursorY: y,
        };
        return;
      }
    }
  }
  
  private onPointerMove(e: PointerEvent): void {
    if (this.destroyed || this.paused || !this.canvas) return;
    
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    
    // Проверить движение для отмены long-press и начала drag
    if (this.pointerDownItem && !this.pointerMoved) {
      const dx = x - this.pointerDownX;
      const dy = y - this.pointerDownY;
      if (Math.sqrt(dx*dx + dy*dy) > 10) {
        this.pointerMoved = true;
        if (this.longPressTimer) {
          clearTimeout(this.longPressTimer);
          this.longPressTimer = null;
        }
        
        // Начать drag - удалить картинку из исходной позиции
        if (this.dragging && this.dragging.type === 'slot') {
          const slot = this.rows[this.dragging.rowIndex][this.dragging.slotIndex];
          slot.imageIndex = null;
          this.rowsData[this.dragging.rowIndex][this.dragging.slotIndex] = null;
        }
        soundManager.playPickup();
      }
    }
    
    // Обновить позицию drag
    if (this.dragging && !this.longPressActive) {
      this.dragging.x = x - this.dragging.offsetX;
      this.dragging.y = y - this.dragging.offsetY;
    }
    
    // БАГ 2: Убран padding, только точные границы
    this.hoveredSlot = null;
    
    for (let rowIndex = 0; rowIndex < this.rows.length; rowIndex++) {
      const row = this.rows[rowIndex];
      for (let slotIndex = 0; slotIndex < row.length; slotIndex++) {
        const slot = row[slotIndex];
        if (x >= slot.x && x <= slot.x + slot.width &&
            y >= slot.y && y <= slot.y + slot.height) {
          this.hoveredSlot = { rowIndex, slotIndex };
          return;
        }
      }
    }
  }
  
  private onPointerUp(e: PointerEvent): void {
    if (this.destroyed || this.paused || !this.canvas) return;
    
    // Отменить long-press таймер
    if (this.longPressTimer) {
      clearTimeout(this.longPressTimer);
      this.longPressTimer = null;
    }
    
    // Если long-press сработал — ничего не делать
    if (this.longPressFired) {
      this.longPressFired = false;
      this.pointerDownItem = null;
      this.dragging = null;
      return;
    }
    
    // Вычислить позицию курсора
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const cursorX = (e.clientX - rect.left) * scaleX;
    const cursorY = (e.clientY - rect.top) * scaleY;
    
    const elapsed = Date.now() - this.pointerDownTime;
    
    // СЦЕНАРИЙ A: быстрый клик без движения — удалить картинку
    if (!this.pointerMoved && elapsed < 300 && this.pointerDownItem) {
      if (this.pointerDownItem.type === 'slot') {
        this.returnToTray(
          this.pointerDownItem.imageIndex,
          this.pointerDownItem.rowIndex,
          this.pointerDownItem.slotIndex
        );
        soundManager.playClick();
      }
      this.pointerDownItem = null;
      this.dragging = null;
      return;
    }
    
    // СЦЕНАРИЙ B: drag — использовать существующую логику
    if (this.pointerMoved && this.dragging) {
      this.handleDrop(cursorX, cursorY);
      this.pointerDownItem = null;
      this.dragging = null;
      this.hoveredSlot = null;
      return;
    }
    
    // СЦЕНАРИЙ C: долгое нажатие без движения (>= 300мс, но < 500мс) — вернуть в исходную позицию
    if (!this.pointerMoved && elapsed >= 300 && this.pointerDownItem) {
      if (this.pointerDownItem.type === 'slot' && this.dragging) {
        const slot = this.rows[this.pointerDownItem.rowIndex][this.pointerDownItem.slotIndex];
        slot.imageIndex = this.pointerDownItem.imageIndex;
        this.rowsData[this.pointerDownItem.rowIndex][this.pointerDownItem.slotIndex] = this.pointerDownItem.imageIndex;
      }
      soundManager.playClick();
      this.pointerDownItem = null;
      this.dragging = null;
      return;
    }
    
    // Очистка состояния
    this.pointerDownItem = null;
    this.dragging = null;
    this.hoveredSlot = null;
  }
  
  private handleDrop(cursorX: number, cursorY: number): void {
    if (!this.dragging) {
      console.log('handleDrop: no dragging state');
      return;
    }
    
    console.log('handleDrop called:', {
      cursorX, cursorY,
      draggingImageIndex: this.dragging.imageIndex,
      draggingType: this.dragging.type,
    });
    
    // Определяем целевую клетку ПО КУРСОРУ
    let targetRow = -1;
    let targetSlot = -1;
    
    for (let rowIndex = 0; rowIndex < this.rows.length; rowIndex++) {
      const row = this.rows[rowIndex];
      for (let slotIndex = 0; slotIndex < row.length; slotIndex++) {
        const slot = row[slotIndex];
        if (cursorX >= slot.x && cursorX <= slot.x + slot.width &&
            cursorY >= slot.y && cursorY <= slot.y + slot.height) {
          targetRow = rowIndex;
          targetSlot = slotIndex;
          break;
        }
      }
      if (targetRow !== -1) break;
    }
    
    console.log('Target cell:', targetRow, targetSlot);
    if (targetRow !== -1 && targetSlot !== -1) {
      console.log('Cell occupied?', this.rows[targetRow]?.[targetSlot]?.imageIndex);
    }
    
    console.log('Drop: cursor=(' + cursorX.toFixed(1) + ',' + cursorY.toFixed(1) + '), target=' + targetRow + '/' + targetSlot);
    
    // Если попали в клетку — вставить
    if (targetRow !== -1 && targetSlot !== -1) {
      const slot = this.rows[targetRow][targetSlot];
      
      // Если в клетке уже есть картинка — НЕ заменять
      if (slot.imageIndex !== null) {
        console.log('Drop: slot is occupied, not replacing');
        // Для tray items — картинка просто остаётся в лотке
        // Для slot items — возвращаем в исходную клетку
        if (this.dragging.type === 'slot') {
          this.rows[this.dragging.rowIndex][this.dragging.slotIndex].imageIndex = this.dragging.imageIndex;
          this.rowsData[this.dragging.rowIndex][this.dragging.slotIndex] = this.dragging.imageIndex;
        }
        return;
      }
      
      // Клетка пуста — вставляем
      slot.imageIndex = this.dragging.imageIndex;
      this.rowsData[targetRow][targetSlot] = this.dragging.imageIndex;
      soundManager.playDrop();
      console.log('Drop: placed in cell ' + targetRow + '/' + targetSlot);
    } else {
      // Не попали ни в одну клетку
      console.log('Drop: missed all cells');
      // Для tray items — картинка остаётся в лотке (ничего не делаем)
      // Для slot items — возвращаем в исходную клетку
      if (this.dragging.type === 'slot') {
        this.rows[this.dragging.rowIndex][this.dragging.slotIndex].imageIndex = this.dragging.imageIndex;
        this.rowsData[this.dragging.rowIndex][this.dragging.slotIndex] = this.dragging.imageIndex;
        soundManager.playClick();
        console.log('Drop: returned to original cell ' + this.dragging.rowIndex + '/' + this.dragging.slotIndex);
      }
    }
  }
  
  private gameLoop = (): void => {
    if (this.destroyed || !this.ctx || !this.canvas) return;
    
    if (!this.paused) {
      this.render();
    }
    this.animFrameId = requestAnimationFrame(this.gameLoop);
  };
  
  private render(): void {
    if (!this.ctx || !this.canvas) return;
    
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    
    // БАГ 4 FIX: Отключаем сглаживание для резких пикселей
    ctx.imageSmoothingEnabled = false;
    
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    
    // Draw all rows
    for (let rowIndex = 0; rowIndex < this.rows.length; rowIndex++) {
      const row = this.rows[rowIndex];
      
      for (let slotIndex = 0; slotIndex < row.length; slotIndex++) {
        const slot = row[slotIndex];
        const isHovered = this.hoveredSlot?.rowIndex === rowIndex && 
                         this.hoveredSlot?.slotIndex === slotIndex && 
                         this.dragging !== null;
        
        ctx.fillStyle = isHovered ? '#c8e6c9' : '#e8f5e9';
        ctx.fillRect(slot.x, slot.y, slot.width, slot.height);
        
        ctx.strokeStyle = '#4caf50';
        ctx.lineWidth = isHovered ? 3 : 1;
        ctx.setLineDash([5, 5]);
        ctx.strokeRect(slot.x, slot.y, slot.width, slot.height);
        ctx.setLineDash([]);
        
        if (slot.imageIndex !== null) {
          const imageSrc = this.images[slot.imageIndex];
          const img = this.getCachedImage(imageSrc);
          if (img) {
            const imgRatio = img.naturalWidth / img.naturalHeight;
            const slotRatio = slot.width / slot.height;
            
            let drawWidth, drawHeight, drawX, drawY;
            if (imgRatio > slotRatio) {
              drawWidth = slot.width;
              drawHeight = drawWidth / imgRatio;
              drawX = slot.x;
              drawY = slot.y + (slot.height - drawHeight) / 2;
            } else {
              drawHeight = slot.height;
              drawWidth = drawHeight * imgRatio;
              drawX = slot.x + (slot.width - drawWidth) / 2;
              drawY = slot.y;
            }
            
            // Рисуем подсветку (overlay)
            const highlight = this.highlights.get(imageSrc);
            if (highlight) {
              ctx.fillStyle = this.getHighlightColor(highlight, 0.15);
              ctx.fillRect(drawX, drawY, drawWidth, drawHeight);
            }
            
            ctx.drawImage(img, drawX, drawY, drawWidth, drawHeight);
            
            // Рисуем рамку подсветки
            if (highlight) {
              ctx.strokeStyle = this.getHighlightColor(highlight, 1.0);
              ctx.lineWidth = 3;
              ctx.strokeRect(drawX, drawY, drawWidth, drawHeight);
            }
          }
        }
      }
    }
    
    // Draw tray background
    const trayY = h - 250;
    ctx.fillStyle = '#f5f5f5';
    ctx.fillRect(0, trayY, w, 250);
    
    // Draw tray items
    for (const item of this.trayItems) {
      if (this.dragging && this.dragging.type === 'tray' && 
          this.trayItems.indexOf(item) === this.dragging.slotIndex) {
        continue;
      }
      
      // БАГ 7: Используем кэшированное изображение
      const imageSrc = this.images[item.imageIndex];
      const img = this.getCachedImage(imageSrc);
      if (img) {
        const imgRatio = img.naturalWidth / img.naturalHeight;
        const itemRatio = item.width / item.height;
        
        let drawWidth, drawHeight, drawX, drawY;
        if (imgRatio > itemRatio) {
          drawWidth = item.width;
          drawHeight = drawWidth / imgRatio;
          drawX = item.x;
          drawY = item.y + (item.height - drawHeight) / 2;
        } else {
          drawHeight = item.height;
          drawWidth = drawHeight * imgRatio;
          drawX = item.x + (item.width - drawWidth) / 2;
          drawY = item.y;
        }
        
        // Рисуем подсветку (overlay)
        const highlight = this.highlights.get(imageSrc);
        if (highlight) {
          ctx.fillStyle = this.getHighlightColor(highlight, 0.15);
          ctx.fillRect(drawX, drawY, drawWidth, drawHeight);
        }
        
        ctx.drawImage(img, drawX, drawY, drawWidth, drawHeight);
        
        // Рисуем рамку подсветки
        if (highlight) {
          ctx.strokeStyle = this.getHighlightColor(highlight, 1.0);
          ctx.lineWidth = 3;
          ctx.strokeRect(drawX, drawY, drawWidth, drawHeight);
        }
      }
    }
    
    // Draw long-press visual feedback
    if (this.longPressActive && this.longPressTarget && this.dragging) {
      const img = this.getCachedImage(this.images[this.dragging.imageIndex]);
      if (img) {
        const scale = 1.1;
        const centerX = this.dragging.x + this.dragging.offsetX;
        const centerY = this.dragging.y + this.dragging.offsetY;
        
        const imgRatio = img.naturalWidth / img.naturalHeight;
        let drawWidth, drawHeight;
        
        if (this.longPressTarget.type === 'slot') {
          const slot = this.rows[this.longPressTarget.rowIndex][this.longPressTarget.slotIndex];
          if (imgRatio > 1) {
            drawWidth = slot.width * scale;
            drawHeight = (slot.width / imgRatio) * scale;
          } else {
            drawHeight = slot.height * scale;
            drawWidth = (slot.height * imgRatio) * scale;
          }
        } else {
          const item = this.trayItems[this.longPressTarget.slotIndex];
          if (imgRatio > 1) {
            drawWidth = item.width * scale;
            drawHeight = (item.width / imgRatio) * scale;
          } else {
            drawHeight = item.height * scale;
            drawWidth = (item.height * imgRatio) * scale;
          }
        }
        
        const drawX = centerX - drawWidth / 2;
        const drawY = centerY - drawHeight / 2;
        
        // Свечение
        ctx.shadowColor = 'rgba(255, 215, 0, 0.8)';
        ctx.shadowBlur = 20;
        
        ctx.drawImage(img, drawX, drawY, drawWidth, drawHeight);
        
        // Золотая рамка
        ctx.strokeStyle = 'rgba(255, 215, 0, 0.9)';
        ctx.lineWidth = 3;
        ctx.strokeRect(drawX, drawY, drawWidth, drawHeight);
        
        // Сброс тени
        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
      }
    }
    
    // Draw dragged item
    if (this.dragging) {
      const img = this.getCachedImage(this.images[this.dragging.imageIndex]);
      if (img) {
        const size = this.rows[0]?.[0]?.width || 60;
        const imgRatio = img.naturalWidth / img.naturalHeight;
        
        // ФИКС 2: Увеличение при наведении на клетку
        const scale = this.hoveredSlot ? 1.05 : 1.0;
        
        let drawWidth, drawHeight;
        if (imgRatio > 1) {
          drawWidth = size * scale;
          drawHeight = (size / imgRatio) * scale;
        } else {
          drawHeight = size * scale;
          drawWidth = (size * imgRatio) * scale;
        }
        
        // Центрируем увеличенную картинку относительно курсора
        const drawX = this.dragging.x - (drawWidth - size) / 2;
        const drawY = this.dragging.y - (drawHeight - size) / 2;
        
        // Добавляем тень для визуальной обратной связи
        ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
        ctx.shadowBlur = 10;
        ctx.shadowOffsetX = 2;
        ctx.shadowOffsetY = 2;
        
        // Рисуем подсветку (overlay) для перетаскиваемого элемента
        const imageSrc = this.images[this.dragging.imageIndex];
        const highlight = this.highlights.get(imageSrc);
        if (highlight) {
          ctx.fillStyle = this.getHighlightColor(highlight, 0.15);
          ctx.fillRect(drawX, drawY, drawWidth, drawHeight);
        }
        
        ctx.drawImage(img, drawX, drawY, drawWidth, drawHeight);
        
        // Рисуем рамку подсветки для перетаскиваемого элемента
        if (highlight) {
          ctx.strokeStyle = this.getHighlightColor(highlight, 1.0);
          ctx.lineWidth = 3;
          ctx.strokeRect(drawX, drawY, drawWidth, drawHeight);
        }
        
        // Сбрасываем тень
        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 0;
      }
    }
    
    // БАГ 4: Вертикальный скроллбар
    if (this.maxTrayScrollY > 0) {
      const scrollbarWidth = 16;
      const scrollbarHeight = 230;
      const scrollbarX = w - scrollbarWidth - 10;
      const scrollbarY = trayY + 10;
      
      ctx.fillStyle = '#ddd';
      ctx.beginPath();
      ctx.roundRect(scrollbarX, scrollbarY, scrollbarWidth, scrollbarHeight, 8);
      ctx.fill();
      
      const thumbHeight = Math.max(40, scrollbarHeight * (230 / (scrollbarHeight + this.maxTrayScrollY)));
      const thumbY = scrollbarY + (scrollbarHeight - thumbHeight) * (this.trayScrollY / this.maxTrayScrollY);
      
      ctx.fillStyle = '#888';
      ctx.beginPath();
      ctx.roundRect(scrollbarX, thumbY, scrollbarWidth, thumbHeight, 8);
      ctx.fill();
    }
    
    // Draw palette if shown
    if (this.showPalette && this.paletteTarget) {
      this.drawPalette(ctx);
    }
  }
  
  private drawPalette(ctx: CanvasRenderingContext2D): void {
    const centerX = this.palettePosition.x;
    const centerY = this.palettePosition.y;
    const radius = 60;
    const buttonRadius = 20;
    
    // Рисуем полупрозрачный фон
    ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius + buttonRadius + 10, 0, Math.PI * 2);
    ctx.fill();
    
    // Цвета для кнопок
    const colors: Array<{ color: 'red' | 'yellow' | 'green' | 'blue' | 'purple'; hex: string }> = [
      { color: 'red', hex: '#ef4444' },
      { color: 'yellow', hex: '#eab308' },
      { color: 'green', hex: '#22c55e' },
      { color: 'blue', hex: '#3b82f6' },
      { color: 'purple', hex: '#a855f7' }
    ];
    
    // Рисуем цветные кнопки по кругу
    for (let i = 0; i < colors.length; i++) {
      const angle = (i * 2 * Math.PI) / 5 - Math.PI / 2;
      const buttonX = centerX + Math.cos(angle) * radius;
      const buttonY = centerY + Math.sin(angle) * radius;
      
      // Тень
      ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
      ctx.shadowBlur = 5;
      ctx.shadowOffsetX = 2;
      ctx.shadowOffsetY = 2;
      
      // Кнопка
      ctx.fillStyle = colors[i].hex;
      ctx.beginPath();
      ctx.arc(buttonX, buttonY, buttonRadius, 0, Math.PI * 2);
      ctx.fill();
      
      // Белая рамка
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Сброс тени
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
    }
    
    // Центральная кнопка "Снять подсветку"
    ctx.fillStyle = '#6b7280';
    ctx.beginPath();
    ctx.arc(centerX, centerY, buttonRadius, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();
    
    // Крестик
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(centerX - 8, centerY - 8);
    ctx.lineTo(centerX + 8, centerY + 8);
    ctx.moveTo(centerX + 8, centerY - 8);
    ctx.lineTo(centerX - 8, centerY + 8);
    ctx.stroke();
  }
  
  setPaused(paused: boolean): void {
    this.paused = paused;
  }
  
  setSquareSizeFactor(factor: number): void {
    this.squareSizeFactor = factor;
    this.layoutRows();
    this.layoutTray();
  }
  
  setSlotCount(count: number): void {
    // БАГ 1: Не трогаем rowsData, только пересчитываем layout
    this.slotCount = count;
    this.layoutRows();
  }
  
  getRowCount(): number {
    return this.rows.length;
  }
  
  getSlotCount(): number {
    return this.slotCount;
  }
  
  getRowsData(): (number | null)[][] {
    return this.rowsData;
  }
  
  setImages(images: string[]): void {
    this.images = images;
    this.preloadImages();
    this.layoutTray();
  }
  
  setRowsData(data: (number | null)[][]): void {
    // БАГ 1: Сохраняем в rowsData с фиксированной длиной 24
    this.rowsData = data.map(row => {
      const paddedRow = Array(24).fill(null);
      for (let i = 0; i < Math.min(row.length, 24); i++) {
        paddedRow[i] = row[i];
      }
      return paddedRow;
    });
    this.layoutRows();
  }
  
  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = 0;
    }
    
    if (this.canvas) {
      this.canvas.removeEventListener('pointerdown', this.handlePointerDown);
      this.canvas.removeEventListener('pointermove', this.handlePointerMove);
      this.canvas.removeEventListener('pointerup', this.handlePointerUp);
      this.canvas.removeEventListener('pointercancel', this.handlePointerUp);
      this.canvas.removeEventListener('wheel', this.handleWheel);
      this.canvas.removeEventListener('touchstart', this.handleTouchStart);
      this.canvas.removeEventListener('touchmove', this.handleTouchMove);
      this.canvas.removeEventListener('touchend', this.handleTouchEnd);
      this.canvas.removeEventListener('touchcancel', this.handleTouchEnd);
      this.canvas.removeEventListener('contextmenu', this.handleContextMenu);
      this.canvas = null;
      this.ctx = null;
    }
    
    this.cancelLongPress();
    this.pointerDownItem = null;
    
    this.rows = [];
    this.rowsData = [];
    this.trayItems = [];
    this.imageCache.clear();
  }
}
