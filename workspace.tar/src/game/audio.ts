export type SoundSet = 'nes' | 'soft' | 'retro' | 'silent';
export type SoundType = 'click' | 'pickup' | 'drop' | 'correct' | 'wrong' | 'complete' | 'levelup' | 'gameover';

interface SoundSettings {
  volume: number; // 0-100
  soundSet: SoundSet;
}

class SoundManager {
  private audioCtx: AudioContext | null = null;
  private settings: SoundSettings = {
    volume: 100,
    soundSet: 'nes'
  };
  private lastPlayTime: Map<SoundType, number> = new Map();

  constructor() {
    this.loadSettings();
  }

  private initAudioContext(): void {
    if (!this.audioCtx) {
      try {
        this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      } catch (e) {
        console.warn('Web Audio API not supported');
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  private loadSettings(): void {
    try {
      const saved = localStorage.getItem('soundSettings');
      if (saved) {
        this.settings = JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Failed to load sound settings');
    }
  }

  private saveSettings(): void {
    try {
      localStorage.setItem('soundSettings', JSON.stringify(this.settings));
    } catch (e) {
      console.warn('Failed to save sound settings');
    }
  }

  setVolume(volume: number): void {
    this.settings.volume = Math.max(0, Math.min(100, volume));
    this.saveSettings();
  }

  getVolume(): number {
    return this.settings.volume;
  }

  setSoundSet(soundSet: SoundSet): void {
    this.settings.soundSet = soundSet;
    this.saveSettings();
  }

  getSoundSet(): SoundSet {
    return this.settings.soundSet;
  }

  getSettings(): SoundSettings {
    return { ...this.settings };
  }

  play(sound: SoundType): void {
    if (this.settings.soundSet === 'silent' || this.settings.volume === 0) {
      return;
    }

    // Throttling: не давать играть один и тот же звук чаще чем раз в 100 мс
    const now = Date.now();
    const last = this.lastPlayTime.get(sound) || 0;
    if (now - last < 100) return; // защита от спама
    this.lastPlayTime.set(sound, now);

    this.initAudioContext();
    if (!this.audioCtx) return;

    const volume = this.settings.volume / 100;

    switch (this.settings.soundSet) {
      case 'nes':
        this.playNES(sound, volume);
        break;
      case 'soft':
        this.playSoft(sound, volume);
        break;
      case 'retro':
        this.playRetro(sound, volume);
        break;
    }
  }

  private playNES(sound: SoundType, volume: number): void {
    if (!this.audioCtx) return;
    const ctx = this.audioCtx;

    try {
      switch (sound) {
        case 'click':
          this.playTone(ctx, 'square', 800, 0.04, volume * 0.3);
          break;
        case 'pickup':
          this.playTone(ctx, 'square', 600, 0.06, volume * 0.4);
          break;
        case 'drop':
          this.playTone(ctx, 'square', 400, 0.05, volume * 0.3);
          break;
        case 'correct':
          this.playChord(ctx, 'square', [523, 659, 784], 0.2, volume * 0.3);
          break;
        case 'wrong':
          this.playTone(ctx, 'square', 150, 0.25, volume * 0.3);
          break;
        case 'complete':
          this.playArpeggio(ctx, 'square', [523, 659, 784, 1047], 0.4, volume * 0.3);
          break;
        case 'levelup':
          this.playArpeggio(ctx, 'square', [523, 659, 784, 988, 1175], 0.5, volume * 0.3);
          break;
        case 'gameover':
          this.playArpeggio(ctx, 'square', [400, 350, 300, 250, 200], 0.8, volume * 0.3);
          break;
      }
    } catch (e) {
      console.warn('Failed to play NES sound:', e);
    }
  }

  private playSoft(sound: SoundType, volume: number): void {
    if (!this.audioCtx) return;
    const ctx = this.audioCtx;

    try {
      switch (sound) {
        case 'click':
          this.playTone(ctx, 'sine', 600, 0.04, volume * 0.2);
          break;
        case 'pickup':
          this.playTone(ctx, 'sine', 800, 0.06, volume * 0.3);
          break;
        case 'drop':
          this.playTone(ctx, 'sine', 400, 0.05, volume * 0.2);
          break;
        case 'correct':
          this.playChord(ctx, 'sine', [523, 659, 784], 0.3, volume * 0.25);
          break;
        case 'wrong':
          this.playTone(ctx, 'sine', 200, 0.3, volume * 0.2);
          break;
        case 'complete':
          this.playArpeggio(ctx, 'sine', [523, 659, 784, 1047], 0.5, volume * 0.25);
          break;
        case 'levelup':
          this.playArpeggio(ctx, 'sine', [523, 659, 784, 988, 1175], 0.6, volume * 0.25);
          break;
        case 'gameover':
          this.playArpeggio(ctx, 'sine', [400, 350, 300, 250, 200], 1.0, volume * 0.25);
          break;
      }
    } catch (e) {
      console.warn('Failed to play Soft sound:', e);
    }
  }

  private playRetro(sound: SoundType, volume: number): void {
    if (!this.audioCtx) return;
    const ctx = this.audioCtx;

    try {
      switch (sound) {
        case 'click':
          this.playTone(ctx, 'sawtooth', 800, 0.04, volume * 0.2);
          break;
        case 'pickup':
          this.playTone(ctx, 'sawtooth', 600, 0.06, volume * 0.3);
          break;
        case 'drop':
          this.playTone(ctx, 'sawtooth', 400, 0.05, volume * 0.2);
          break;
        case 'correct':
          this.playArpeggio(ctx, 'sawtooth', [523, 659, 784], 0.15, volume * 0.2);
          break;
        case 'wrong':
          this.playTone(ctx, 'sawtooth', 150, 0.25, volume * 0.2);
          break;
        case 'complete':
          this.playArpeggio(ctx, 'sawtooth', [523, 659, 784, 1047], 0.3, volume * 0.2);
          break;
        case 'levelup':
          this.playArpeggio(ctx, 'sawtooth', [523, 659, 784, 988, 1175], 0.4, volume * 0.2);
          break;
        case 'gameover':
          this.playArpeggio(ctx, 'sawtooth', [400, 350, 300, 250, 200], 0.6, volume * 0.2);
          break;
      }
    } catch (e) {
      console.warn('Failed to play Retro sound:', e);
    }
  }

  private playTone(ctx: AudioContext, type: OscillatorType, freq: number, duration: number, volume: number): void {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);

    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + duration);
  }

  private playChord(ctx: AudioContext, type: OscillatorType, freqs: number[], duration: number, volume: number): void {
    freqs.forEach((freq, i) => {
      setTimeout(() => {
        this.playTone(ctx, type, freq, duration, volume / freqs.length);
      }, i * 50);
    });
  }

  private playArpeggio(ctx: AudioContext, type: OscillatorType, freqs: number[], duration: number, volume: number): void {
    const noteDuration = duration / freqs.length;
    freqs.forEach((freq, i) => {
      setTimeout(() => {
        this.playTone(ctx, type, freq, noteDuration, volume);
      }, i * noteDuration * 1000);
    });
  }

  // Convenience methods for backward compatibility
  playClick(): void { this.play('click'); }
  playPickup(): void { this.play('pickup'); }
  playDrop(): void { this.play('drop'); }
  playCorrect(): void { this.play('correct'); }
  playWrong(): void { this.play('wrong'); }
  playComplete(): void { this.play('complete'); }
  playLevelUp(): void { this.play('levelup'); }
  playGameOver(): void { this.play('gameover'); }
}

// Singleton instance
export const soundManager = new SoundManager();

// Legacy functions for backward compatibility
export function initAudio(): void {
  soundManager.playClick(); // Initialize audio context
}

export function playClick(): void { soundManager.playClick(); }
export function playPickup(): void { soundManager.playPickup(); }
export function playDrop(): void { soundManager.playDrop(); }
export function playCorrect(): void { soundManager.playCorrect(); }
export function playWrong(): void { soundManager.playWrong(); }
export function playComplete(): void { soundManager.playComplete(); }
export function playLevelUp(): void { soundManager.playLevelUp(); }
export function playGameOver(): void { soundManager.playGameOver(); }
