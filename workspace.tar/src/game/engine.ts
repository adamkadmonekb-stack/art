import { BasketConfig, FallingItem, BasketRect, SpawnMode } from './types';
import { soundManager } from './audio';

export class GameEngine {
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private container: HTMLDivElement | null = null;
  
  private baskets: BasketConfig[] = [];
  private basketRects: BasketRect[] = [];
  private items: FallingItem[] = [];
  
  private score = 0;
  private lives = 3;
  private level = 1;
  private paused = false;
  private gameOver = false;
  private destroyed = false;
  
  private spawnMode: SpawnMode = 'fall';
  private itemSize = 100; // процент
  private basketScale = 100; // процент (50-150)
  private baseSpeed = 0.2;
  private spawnInterval = 1000;
  private spawnTimer = 0;
  private itemIdCounter = 0;
  
  private dragging: number | null = null;
  private hoveredBasket: number | null = null; // Индекс корзины под курсором
  
  private animFrameId = 0;
  private lastTime = 0;
  private frameCount = 0;
  private fpsAccum = 0;
  private currentFps = 60;
  
  private imageCache: Map<string, HTMLImageElement> = new Map();
  
  private onScoreChange: ((s: number) => void) | null = null;
  private onLivesChange: ((l: number) => void) | null = null;
  private onLevelChange: ((l: number) => void) | null = null;
  private onGameOverCb: (() => void) | null = null;
  private onFpsUpdate: ((f: number) => void) | null = null;
  
  private soundEnabled = true;
  
  private handlePointerDown = (e: PointerEvent) => this.onPointerDown(e);
  private handlePointerMove = (e: PointerEvent) => this.onPointerMove(e);
  private handlePointerUp = () => this.onPointerUp();
  
  async init(
    container: HTMLDivElement,
    baskets: BasketConfig[],
    spawnMode: SpawnMode,
    itemSize: number
  ): Promise<void> {
    this.destroyed = false;
    this.container = container;
    this.baskets = baskets;
    this.spawnMode = spawnMode;
    this.itemSize = itemSize;
    
    this.score = 0;
    this.lives = 3;
    this.level = 1;
    this.items = [];
    this.gameOver = false;
    this.paused = false;
    this.itemIdCounter = 0;
    this.spawnTimer = 0;
    
    this.spawnInterval = spawnMode === 'random' ? 3500 : 2500;
    this.baseSpeed = 0.2;
    
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;
    
    this.canvas = document.createElement('canvas');
    this.canvas.width = width;
    this.canvas.height = height;
    this.canvas.style.width = '100%';
    this.canvas.style.height = '100%';
    this.canvas.style.display = 'block';
    this.canvas.style.touchAction = 'none';
    
    this.ctx = this.canvas.getContext('2d');
    container.appendChild(this.canvas);
    
    this.canvas.addEventListener('pointerdown', this.handlePointerDown);
    this.canvas.addEventListener('pointermove', this.handlePointerMove);
    this.canvas.addEventListener('pointerup', this.handlePointerUp);
    this.canvas.addEventListener('pointercancel', this.handlePointerUp);
    
    this.computeBasketRects();
    this.preloadImages();
    
    this.lastTime = performance.now();
    this.animFrameId = requestAnimationFrame(this.gameLoop);
  }
  
  private computeBasketRects(): void {
    if (!this.canvas || this.baskets.length === 0) return;
    
    const w = this.canvas.width;
    const h = this.canvas.height;
    const count = this.baskets.length;
    
    // Базовый размер корзины (20% высоты экрана) с учётом масштаба
    const baseSize = h * 0.20;
    const scaleFactor = this.basketScale / 100;
    let basketSize = baseSize * scaleFactor;
    
    // Минимальный размер 60px
    basketSize = Math.max(60, basketSize);
    
    // Равномерное распределение по ширине
    // Формула: totalGap = screenWidth - basketSize * N, gap = totalGap / (N + 1)
    const totalGap = w - basketSize * count;
    let gap = totalGap / (count + 1);
    
    // Минимальный отступ 16px
    if (gap < 16) {
      gap = 16;
      // Пересчитываем размер корзин если не помещаются
      basketSize = (w - gap * (count + 1)) / count;
      basketSize = Math.max(60, basketSize);
    }
    
    // Фиксированный нижний край (95% высоты экрана)
    const basketBottomY = h * 0.98;
    const basketY = basketBottomY - basketSize;
    
    this.basketRects = this.baskets.map((basket, i) => ({
      x: gap * (i + 1) + basketSize * i,
      y: basketY,
      width: basketSize,
      height: basketSize,
      basketId: basket.id,
    }));
  }
  
  private preloadImages(): void {
    for (const basket of this.baskets) {
      if (basket.basketPhoto) this.loadImage(basket.basketPhoto);
      if (basket.categoryIcon) this.loadImage(basket.categoryIcon);
      for (const img of basket.dropImages) {
        this.loadImage(img);
      }
    }
  }
  
  private loadImage(url: string): HTMLImageElement {
    if (this.imageCache.has(url)) return this.imageCache.get(url)!;
    
    const img = new Image();
    img.src = url;
    this.imageCache.set(url, img);
    return img;
  }
  
  private onPointerDown(e: PointerEvent): void {
    if (this.destroyed || this.paused || this.gameOver || !this.canvas) return;
    
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    
    // ДИАГНОСТИКА — временно, убери потом
    console.log('[hit-test]', {
      cursor: { x: Math.round(x), y: Math.round(y) },
      canvasSize: { w: this.canvas.width, h: this.canvas.height },
      cssSize: { w: Math.round(rect.width), h: Math.round(rect.height) },
      itemsCount: this.items.length,
      items: this.items.map(it => ({
        id: it.id,
        x: Math.round(it.x),
        y: Math.round(it.y),
        size: it.size,
      })),
    });
    
    // Ищем С КОНЦА массива — верхние в приоритете
    for (let i = this.items.length - 1; i >= 0; i--) {
      const item = this.items[i];
      
      // ВАЖНО: используем item.size, а не this.itemSize
      const size = item.size;
      // Запас +30px со всех сторон
      const hitHalf = size / 2 + 30;
      
      const dx = Math.abs(x - item.x);
      const dy = Math.abs(y - item.y);
      
      if (dx < hitHalf && dy < hitHalf) {
        this.dragging = item.id;
        if (this.soundEnabled) soundManager.playPickup();
        return;
      }
    }
    
    // Fallback — ближайший в радиусе 80px
    let closest: FallingItem | null = null;
    let closestDist = 80;
    for (const item of this.items) {
      const dx = x - item.x;
      const dy = y - item.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < closestDist) {
        closestDist = dist;
        closest = item;
      }
    }
    
    if (closest) {
      this.dragging = closest.id;
      if (this.soundEnabled) soundManager.playPickup();
      console.log('[hit-test] fallback → item', closest.id, 'dist=' + Math.round(closestDist));
    }
  }
  
  private onPointerMove(e: PointerEvent): void {
    if (this.destroyed || this.dragging === null || !this.canvas) return;
    
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    
    const item = this.items.find(i => i.id === this.dragging);
    if (item) {
      item.x = x;
      item.y = y;
      
      // Check hover over baskets
      this.hoveredBasket = null;
      for (let i = 0; i < this.basketRects.length; i++) {
        const basket = this.basketRects[i];
        if (x >= basket.x && x <= basket.x + basket.width &&
            y >= basket.y && y <= basket.y + basket.height) {
          this.hoveredBasket = i;
          break;
        }
      }
    }
  }
  
  private onPointerUp(): void {
    if (this.destroyed || this.dragging === null) return;
    
    const itemId = this.dragging;
    this.dragging = null;
    this.hoveredBasket = null;
    if (this.soundEnabled) soundManager.playDrop();
    
    const item = this.items.find(i => i.id === itemId);
    if (!item) return;
    
    // Check if dropped on basket
    for (const basketRect of this.basketRects) {
      if (item.x >= basketRect.x && item.x <= basketRect.x + basketRect.width &&
          item.y >= basketRect.y && item.y <= basketRect.y + basketRect.height) {
        
        if (basketRect.basketId === item.basketId) {
          // Correct!
          this.score += 10;
          if (this.soundEnabled) soundManager.playCorrect();
          this.onScoreChange?.(this.score);
          
          if (this.score > 0 && this.score % 100 === 0) {
            this.level++;
            this.spawnInterval = Math.max(1500, this.spawnInterval - 50);
            this.baseSpeed = Math.min(3, this.baseSpeed + 0.1);
            if (this.soundEnabled) soundManager.playLevelUp();
            this.onLevelChange?.(this.level);
          }
        } else {
          // Wrong!
          this.lives--;
          if (this.soundEnabled) soundManager.playWrong();
          this.onLivesChange?.(this.lives);
          
          if (this.lives <= 0) {
            this.gameOver = true;
            if (this.soundEnabled) soundManager.playGameOver();
            this.onGameOverCb?.();
          }
        }
        
        this.removeItem(itemId);
        break;
      }
    }
  }
  
  private removeItem(id: number): void {
    this.items = this.items.filter(i => i.id !== id);
  }
  
  private spawnItem(): void {
    if (!this.canvas) return;
    
    const w = this.canvas.width;
    const h = this.canvas.height;
    
    const maxItems = this.spawnMode === 'random' ? 5 : 15;
    if (this.items.length >= maxItems) return;
    
    // Pick random basket with images
    const basketsWithImages = this.baskets.filter(b => b.dropImages.length > 0);
    if (basketsWithImages.length === 0) return;
    
    const basket = basketsWithImages[Math.floor(Math.random() * basketsWithImages.length)];
    const imageUrl = basket.dropImages[Math.floor(Math.random() * basket.dropImages.length)];
    
    const item: FallingItem = {
      id: this.itemIdCounter++,
      basketId: basket.id,
      imageUrl,
      x: 50 + Math.random() * (w - 100),
      y: this.spawnMode === 'random' ? 80 + Math.random() * (h - 250) : -50,
      speed: this.baseSpeed + Math.random() * 0.5,
      size: 50 * (this.itemSize / 100),
    };
    
    this.items.push(item);
  }
  
  private gameLoop = (): void => {
    if (this.destroyed || !this.ctx || !this.canvas) return;
    
    const now = performance.now();
    const delta = now - this.lastTime;
    this.lastTime = now;
    
    if (!this.paused && !this.gameOver) {
      // FPS
      this.frameCount++;
      this.fpsAccum += delta;
      if (this.fpsAccum >= 1000) {
        this.currentFps = Math.round(this.frameCount * 1000 / this.fpsAccum);
        this.frameCount = 0;
        this.fpsAccum = 0;
        this.onFpsUpdate?.(this.currentFps);
      }
      
      // Spawn
      this.spawnTimer += delta;
      if (this.spawnTimer >= this.spawnInterval) {
        this.spawnTimer = 0;
        this.spawnItem();
      }
      
      // Move items (only in fall mode)
      if (this.spawnMode === 'fall') {
        const h = this.canvas.height;
        const toRemove: number[] = [];
        
        for (const item of this.items) {
          if (item.id === this.dragging) continue;
          item.y += item.speed * (delta / 16);
          if (item.y > h + 60) toRemove.push(item.id);
        }
        
        for (const id of toRemove) this.removeItem(id);
      }
    }
    
    this.render();
    this.animFrameId = requestAnimationFrame(this.gameLoop);
  };
  
  private render(): void {
    if (!this.ctx || !this.canvas) return;
    
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    
    // БАГ 4 FIX: Отключаем сглаживание для резких пикселей
    ctx.imageSmoothingEnabled = false;
    
    // Clear with white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    
    // Draw baskets
    const basketIndex = this.basketRects.findIndex(br => 
      this.baskets.find(b => b.id === br.basketId)
    );
    
    for (let i = 0; i < this.basketRects.length; i++) {
      const basketRect = this.basketRects[i];
      const basket = this.baskets.find(b => b.id === basketRect.basketId);
      if (!basket) continue;
      
      const isHovered = this.hoveredBasket === i;
      
      // Hover highlight — glow effect
      if (isHovered) {
        ctx.shadowColor = 'rgba(59, 130, 246, 0.8)';
        ctx.shadowBlur = 20;
        ctx.strokeStyle = 'rgba(59, 130, 246, 0.6)';
        ctx.lineWidth = 3;
        ctx.strokeRect(basketRect.x - 2, basketRect.y - 2, basketRect.width + 4, basketRect.height + 4);
        ctx.shadowBlur = 0;
      }
      
      // Background — always draw container background
      ctx.fillStyle = '#f3f4f6';
      ctx.fillRect(basketRect.x, basketRect.y, basketRect.width, basketRect.height);
      
      // Background photo — preserve aspect ratio, contain (fit inside)
      if (basket.basketPhoto) {
        const img = this.loadImage(basket.basketPhoto);
        if (img.complete && img.naturalWidth > 0) {
          // Calculate dimensions to fit inside container while preserving aspect ratio
          const imgRatio = img.naturalWidth / img.naturalHeight;
          const containerRatio = basketRect.width / basketRect.height;
          
          let drawWidth, drawHeight, drawX, drawY;
          
          if (imgRatio > containerRatio) {
            // Image is wider — fit by width
            drawWidth = basketRect.width;
            drawHeight = drawWidth / imgRatio;
            drawX = basketRect.x;
            drawY = basketRect.y + (basketRect.height - drawHeight) / 2;
          } else {
            // Image is taller — fit by height
            drawHeight = basketRect.height;
            drawWidth = drawHeight * imgRatio;
            drawX = basketRect.x + (basketRect.width - drawWidth) / 2;
            drawY = basketRect.y;
          }
          
          ctx.drawImage(img, drawX, drawY, drawWidth, drawHeight);
        }
      }
      
      // Border (subtle)
      ctx.strokeStyle = isHovered ? 'rgba(59, 130, 246, 0.8)' : 'rgba(0,0,0,0.1)';
      ctx.lineWidth = isHovered ? 3 : 1;
      ctx.strokeRect(basketRect.x, basketRect.y, basketRect.width, basketRect.height);
      
      // Category icon
      if (basket.categoryIcon) {
        const img = this.loadImage(basket.categoryIcon);
        if (img.complete && img.naturalWidth > 0) {
          // Icon size: 60% if photo exists, 80% if no photo
          const iconPercent = basket.basketPhoto ? 0.6 : 0.8;
          const maxIconHeight = basketRect.height * iconPercent;
          const maxIconWidth = basketRect.width * 0.9;
          const imgRatio = img.naturalWidth / img.naturalHeight;
          
          let iconWidth, iconHeight;
          if (imgRatio > maxIconWidth / maxIconHeight) {
            iconWidth = maxIconWidth;
            iconHeight = iconWidth / imgRatio;
          } else {
            iconHeight = maxIconHeight;
            iconWidth = iconHeight * imgRatio;
          }
          
          // Center icon, offset up a bit if there's a name label
          const iconX = basketRect.x + (basketRect.width - iconWidth) / 2;
          const iconY = basketRect.y + (basketRect.height - iconHeight) / 2 - 10;
          
          ctx.drawImage(img, iconX, iconY, iconWidth, iconHeight);
        }
      }
      
      // Name — at bottom center with background for readability
      const nameY = basketRect.y + basketRect.height - 20;
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(basketRect.x, nameY - 10, basketRect.width, 24);
      
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 14px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(basket.name, basketRect.x + basketRect.width / 2, nameY + 2);
    }
    
    // Draw items — preserve transparency
    for (const item of this.items) {
      const img = this.loadImage(item.imageUrl);
      if (img.complete && img.naturalWidth > 0) {
        const size = item.size;
        // Preserve aspect ratio
        const imgRatio = img.naturalWidth / img.naturalHeight;
        let drawWidth, drawHeight;
        if (imgRatio > 1) {
          drawWidth = size;
          drawHeight = size / imgRatio;
        } else {
          drawHeight = size;
          drawWidth = size * imgRatio;
        }
        ctx.drawImage(img, item.x - drawWidth / 2, item.y - drawHeight / 2, drawWidth, drawHeight);
      } else {
        // Placeholder
        ctx.fillStyle = '#cccccc';
        const size = item.size;
        ctx.fillRect(item.x - size / 2, item.y - size / 2, size, size);
      }
    }
    
    // HUD
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#1f2937';
    ctx.font = 'bold 18px system-ui, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(`Счёт: ${this.score}`, 10, 10);
    
    ctx.fillStyle = '#6b7280';
    ctx.font = 'bold 16px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`Ур: ${this.level}`, w / 2, 10);
    
    ctx.fillStyle = '#ef4444';
    ctx.font = '20px sans-serif';
    ctx.textAlign = 'right';
    const hearts = '❤'.repeat(this.lives) + '♡'.repeat(Math.max(0, 3 - this.lives));
    ctx.fillText(hearts, w - 10, 10);
  }
  
  // Public API
  setCallbacks(cb: {
    onScoreChange?: (s: number) => void;
    onLivesChange?: (l: number) => void;
    onLevelChange?: (l: number) => void;
    onGameOver?: () => void;
    onFpsUpdate?: (f: number) => void;
  }): void {
    this.onScoreChange = cb.onScoreChange || null;
    this.onLivesChange = cb.onLivesChange || null;
    this.onLevelChange = cb.onLevelChange || null;
    this.onGameOverCb = cb.onGameOver || null;
    this.onFpsUpdate = cb.onFpsUpdate || null;
  }
  
  setPaused(p: boolean): void {
    this.paused = p;
  }
  
  setItemSize(size: number): void {
    this.itemSize = size;
    // Update existing items
    for (const item of this.items) {
      item.size = 50 * (size / 100);
    }
  }
  
  setBasketScale(scale: number): void {
    this.basketScale = scale;
    this.computeBasketRects();
  }
  
  setSound(enabled: boolean): void {
    this.soundEnabled = enabled;
  }
  
  resize(w: number, h: number): void {
    if (this.destroyed || !this.canvas) return;
    this.canvas.width = w;
    this.canvas.height = h;
    this.computeBasketRects();
  }
  
  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = 0;
    }
    
    if (this.canvas) {
      this.canvas.removeEventListener('pointerdown', this.handlePointerDown);
      this.canvas.removeEventListener('pointermove', this.handlePointerMove);
      this.canvas.removeEventListener('pointerup', this.handlePointerUp);
      this.canvas.removeEventListener('pointercancel', this.handlePointerUp);
      // НЕ удаляем canvas из DOM — это делает React
      this.canvas = null;
      this.ctx = null;
    }
    
    this.imageCache.clear();
    this.items = [];
    this.basketRects = [];
  }
}
