import { MathTask, getRandomTask } from './mathTasks';
import { soundManager } from './audio';

export class MathEngine {
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private container: HTMLDivElement | null = null;
  
  private currentTask: MathTask | null = null;
  private answerTiles: string[] = [];
  private placedAnswer: string | null = null;
  
  private score = 0;
  private level = 1;
  private lives = 3;
  private correctCount = 0;
  private paused = false;
  
  private operations: string[] = ['+', '-'];
  private difficulty: 'easy' | 'medium' | 'hard' = 'easy';
  
  private dragging: { type: 'tile'; value: string; offsetX: number; offsetY: number; x: number; y: number } | null = null;
  
  private destroyed = false;
  private animFrameId = 0;
  
  private tilePositions: Map<string, { x: number; y: number }> = new Map();
  
  private onScoreChange: ((s: number) => void) | null = null;
  private onLivesChange: ((l: number) => void) | null = null;
  private onLevelChange: ((l: number) => void) | null = null;
  private onGameOver: (() => void) | null = null;
  
  private handlePointerDown = (e: PointerEvent) => this.onPointerDown(e);
  private handlePointerMove = (e: PointerEvent) => this.onPointerMove(e);
  private handlePointerUp = () => this.onPointerUp();
  
  async init(
    container: HTMLDivElement,
    operations: string[] = ['+', '-'],
    difficulty: 'easy' | 'medium' | 'hard' = 'easy'
  ): Promise<void> {
    this.destroyed = false;
    this.container = container;
    this.operations = operations;
    this.difficulty = difficulty;
    
    this.score = 0;
    this.level = 1;
    this.lives = 3;
    this.correctCount = 0;
    
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;
    
    this.canvas = document.createElement('canvas');
    this.canvas.width = width;
    this.canvas.height = height;
    this.canvas.style.width = '100%';
    this.canvas.style.height = '100%';
    this.canvas.style.display = 'block';
    this.canvas.style.touchAction = 'none';
    
    this.ctx = this.canvas.getContext('2d');
    container.appendChild(this.canvas);
    
    this.canvas.addEventListener('pointerdown', this.handlePointerDown);
    this.canvas.addEventListener('pointermove', this.handlePointerMove);
    this.canvas.addEventListener('pointerup', this.handlePointerUp);
    this.canvas.addEventListener('pointercancel', this.handlePointerUp);
    
    this.nextTask();
    
    this.animFrameId = requestAnimationFrame(this.gameLoop);
  }
  
  private nextTask(): void {
    // Generate task based on configured operations and difficulty
    this.currentTask = this.generateTask();
    this.placedAnswer = null;
    
    // Generate answer tiles (correct + distractors)
    const correctAnswer = this.currentTask.answer;
    const distractors = this.generateDistractors(correctAnswer);
    this.answerTiles = [correctAnswer, ...distractors].sort(() => Math.random() - 0.5);
    
    // Position tiles in tray
    this.positionTiles();
  }
  
  private generateTask(): MathTask {
    // For hard difficulty, only allow + and -
    let allowedOps = [...this.operations];
    if (this.difficulty === 'hard') {
      allowedOps = allowedOps.filter(op => op === '+' || op === '-');
      if (allowedOps.length === 0) {
        allowedOps = ['+', '-']; // Fallback
      }
    }
    
    const op = allowedOps[Math.floor(Math.random() * allowedOps.length)];
    
    // Determine range based on difficulty
    let min: number, max: number;
    switch (this.difficulty) {
      case 'easy':
        min = 1;
        max = 10;
        break;
      case 'medium':
        min = 10;
        max = 100;
        break;
      case 'hard':
        min = 100;
        max = 1000;
        break;
    }
    
    let a: number, b: number, result: number;
    
    switch (op) {
      case '+':
        a = Math.floor(Math.random() * (max - min + 1)) + min;
        b = Math.floor(Math.random() * (max - min + 1)) + min;
        result = a + b;
        break;
      case '-':
        // Ensure result is >= 0
        a = Math.floor(Math.random() * (max - min + 1)) + min;
        b = Math.floor(Math.random() * a) + min;
        if (b > a) b = a; // Ensure a >= b
        result = a - b;
        break;
      case '×':
        // For multiplication, keep numbers smaller
        a = Math.floor(Math.random() * 12) + 1;
        b = Math.floor(Math.random() * 12) + 1;
        result = a * b;
        break;
      case '÷':
        // For division, ensure clean division
        b = Math.floor(Math.random() * 12) + 1;
        result = Math.floor(Math.random() * 12) + 1;
        a = b * result;
        break;
      default:
        a = 1;
        b = 1;
        result = 2;
    }
    
    return {
      question: `${a} ${op} ${b}`,
      answer: String(result),
      difficulty: this.difficulty,
    };
  }
  
  private generateDistractors(correct: string): string[] {
    const correctNum = parseInt(correct);
    const distractors: string[] = [];
    
    // Generate 3-4 distractors close to the correct answer
    const offsets = [-2, -1, 1, 2, 3, -3];
    for (const offset of offsets) {
      if (distractors.length >= 4) break;
      const distractor = Math.max(0, correctNum + offset).toString();
      if (distractor !== correct && !distractors.includes(distractor)) {
        distractors.push(distractor);
      }
    }
    
    return distractors.slice(0, 4);
  }
  
  private positionTiles(): void {
    if (!this.canvas) return;
    
    const w = this.canvas.width;
    const h = this.canvas.height;
    
    const trayY = h * 0.75;
    const tileWidth = 80;
    const tileHeight = 80;
    const gap = 20;
    
    const totalWidth = this.answerTiles.length * tileWidth + (this.answerTiles.length - 1) * gap;
    const startX = (w - totalWidth) / 2;
    
    this.tilePositions.clear();
    this.answerTiles.forEach((tile, i) => {
      this.tilePositions.set(tile, {
        x: startX + i * (tileWidth + gap),
        y: trayY,
      });
    });
  }
  
  private onPointerDown(e: PointerEvent): void {
    if (this.destroyed || this.paused || !this.canvas) return;
    
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    
    const tileWidth = 80;
    const tileHeight = 80;
    
    // Check if clicked on a tile
    for (const [value, pos] of this.tilePositions.entries()) {
      if (x >= pos.x && x <= pos.x + tileWidth &&
          y >= pos.y && y <= pos.y + tileHeight) {
        this.dragging = {
          type: 'tile',
          value,
          offsetX: x - pos.x,
          offsetY: y - pos.y,
          x: pos.x,
          y: pos.y,
        };
        break;
      }
    }
  }
  
  private onPointerMove(e: PointerEvent): void {
    if (this.destroyed || this.paused || !this.dragging || !this.canvas) return;
    
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    
    this.dragging.x = x - this.dragging.offsetX;
    this.dragging.y = y - this.dragging.offsetY;
  }
  
  private onPointerUp(): void {
    if (this.destroyed || this.paused || !this.dragging || !this.canvas || !this.currentTask) return;
    
    const w = this.canvas.width;
    const h = this.canvas.height;
    
    // Check if dropped in answer area
    const answerBoxX = w / 2 - 60;
    const answerBoxY = h * 0.35;
    const answerBoxWidth = 120;
    const answerBoxHeight = 80;
    
    const tileWidth = 80;
    const tileHeight = 80;
    const tileCenterX = this.dragging.x + tileWidth / 2;
    const tileCenterY = this.dragging.y + tileHeight / 2;
    
    if (tileCenterX >= answerBoxX && tileCenterX <= answerBoxX + answerBoxWidth &&
        tileCenterY >= answerBoxY && tileCenterY <= answerBoxY + answerBoxHeight) {
      // Dropped in answer area
      this.placedAnswer = this.dragging.value;
      
      // Check if correct
      if (this.dragging.value === this.currentTask.answer) {
        this.score += 10;
        this.correctCount++;
        this.onScoreChange?.(this.score);
        soundManager.playCorrect();
        
        if (this.correctCount % 3 === 0) {
          this.level++;
          this.onLevelChange?.(this.level);
          soundManager.playLevelUp();
        }
        
        // Next task after delay
        setTimeout(() => this.nextTask(), 1000);
      } else {
        // Wrong answer
        this.lives--;
        this.onLivesChange?.(this.lives);
        soundManager.playWrong();
        
        if (this.lives <= 0) {
          soundManager.playGameOver();
          this.gameOver();
        } else {
          // Reset tile position
          setTimeout(() => {
            this.placedAnswer = null;
          }, 500);
        }
      }
    } else {
      // Return tile to tray
      const originalPos = this.tilePositions.get(this.dragging.value);
      if (originalPos) {
        this.dragging.x = originalPos.x;
        this.dragging.y = originalPos.y;
      }
    }
    
    this.dragging = null;
  }
  
  private gameOver(): void {
    this.onGameOver?.();
  }
  
  private gameLoop = (): void => {
    if (this.destroyed || !this.ctx || !this.canvas) return;
    
    if (!this.paused) {
      this.render();
    }
    this.animFrameId = requestAnimationFrame(this.gameLoop);
  };
  
  private render(): void {
    if (!this.ctx || !this.canvas || !this.currentTask) return;
    
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    
    // БАГ 4 FIX: Отключаем сглаживание для резких пикселей
    ctx.imageSmoothingEnabled = false;
    
    // Clear with white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    
    // Draw question
    ctx.fillStyle = '#1f2937';
    ctx.font = 'bold 48px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(this.currentTask.question, w / 2, h * 0.2);
    
    // Draw equals sign
    ctx.fillText('=', w / 2, h * 0.3);
    
    // Draw answer box
    const answerBoxX = w / 2 - 60;
    const answerBoxY = h * 0.35;
    const answerBoxWidth = 120;
    const answerBoxHeight = 80;
    
    ctx.strokeStyle = this.placedAnswer ? (this.placedAnswer === this.currentTask.answer ? '#22c55e' : '#ef4444') : '#3b82f6';
    ctx.lineWidth = 3;
    ctx.strokeRect(answerBoxX, answerBoxY, answerBoxWidth, answerBoxHeight);
    
    if (this.placedAnswer) {
      ctx.fillStyle = '#1f2937';
      ctx.font = 'bold 40px system-ui, sans-serif';
      ctx.fillText(this.placedAnswer, w / 2, answerBoxY + answerBoxHeight / 2);
    }
    
    // Draw tiles in tray
    const tileWidth = 80;
    const tileHeight = 80;
    
    for (const [value, pos] of this.tilePositions.entries()) {
      if (this.dragging && this.dragging.value === value) continue;
      
      ctx.fillStyle = '#f3f4f6';
      ctx.fillRect(pos.x, pos.y, tileWidth, tileHeight);
      ctx.strokeStyle = '#d1d5db';
      ctx.lineWidth = 2;
      ctx.strokeRect(pos.x, pos.y, tileWidth, tileHeight);
      
      ctx.fillStyle = '#1f2937';
      ctx.font = 'bold 32px system-ui, sans-serif';
      ctx.fillText(value, pos.x + tileWidth / 2, pos.y + tileHeight / 2);
    }
    
    // Draw dragged tile
    if (this.dragging) {
      ctx.fillStyle = '#e5e7eb';
      ctx.fillRect(this.dragging.x, this.dragging.y, tileWidth, tileHeight);
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 3;
      ctx.strokeRect(this.dragging.x, this.dragging.y, tileWidth, tileHeight);
      
      ctx.fillStyle = '#1f2937';
      ctx.font = 'bold 32px system-ui, sans-serif';
      ctx.fillText(this.dragging.value, this.dragging.x + tileWidth / 2, this.dragging.y + tileHeight / 2);
    }
    
    // HUD
    ctx.fillStyle = '#1f2937';
    ctx.font = 'bold 18px system-ui, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(`Счёт: ${this.score}`, 10, 10);
    
    ctx.fillStyle = '#6b7280';
    ctx.textAlign = 'center';
    ctx.fillText(`Ур: ${this.level}`, w / 2, 10);
    
    ctx.fillStyle = '#ef4444';
    ctx.font = '20px sans-serif';
    ctx.textAlign = 'right';
    const hearts = '❤'.repeat(this.lives) + '♡'.repeat(Math.max(0, 3 - this.lives));
    ctx.fillText(hearts, w - 10, 10);
  }
  
  // Public API
  setCallbacks(cb: {
    onScoreChange?: (s: number) => void;
    onLivesChange?: (l: number) => void;
    onLevelChange?: (l: number) => void;
    onGameOver?: () => void;
  }): void {
    this.onScoreChange = cb.onScoreChange || null;
    this.onLivesChange = cb.onLivesChange || null;
    this.onLevelChange = cb.onLevelChange || null;
    this.onGameOver = cb.onGameOver || null;
  }
  
  resize(w: number, h: number): void {
    if (this.destroyed || !this.canvas) return;
    this.canvas.width = w;
    this.canvas.height = h;
    this.positionTiles();
  }
  
  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = 0;
    }
    
    if (this.canvas) {
      this.canvas.removeEventListener('pointerdown', this.handlePointerDown);
      this.canvas.removeEventListener('pointermove', this.handlePointerMove);
      this.canvas.removeEventListener('pointerup', this.handlePointerUp);
      this.canvas.removeEventListener('pointercancel', this.handlePointerUp);
      this.canvas = null;
      this.ctx = null;
    }
    
    this.tilePositions.clear();
  }
  
  setPaused(paused: boolean): void {
    this.paused = paused;
  }
}
