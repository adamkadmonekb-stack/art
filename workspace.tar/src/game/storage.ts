import { EmojiPreset } from './types';

const DB_NAME = 'sortgame_db';
const DB_VERSION = 2;
const STORE_BASKETS = 'baskets';
const STORE_PRESETS = 'presets';

let db: IDBDatabase | null = null;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (db) {
      resolve(db);
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };

    request.onupgradeneeded = (event) => {
      const database = (event.target as IDBOpenDBRequest).result;
      if (!database.objectStoreNames.contains(STORE_BASKETS)) {
        database.createObjectStore(STORE_BASKETS);
      }
      if (!database.objectStoreNames.contains(STORE_PRESETS)) {
        database.createObjectStore(STORE_PRESETS);
      }
    };
  });
}

export async function saveBaskets(baskets: any[]): Promise<void> {
  const database = await openDB();
  const transaction = database.transaction([STORE_BASKETS], 'readwrite');
  const store = transaction.objectStore(STORE_BASKETS);
  
  return new Promise((resolve, reject) => {
    const request = store.put(baskets, 'baskets_data');
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function loadBaskets(): Promise<any[] | null> {
  const database = await openDB();
  const transaction = database.transaction([STORE_BASKETS], 'readonly');
  const store = transaction.objectStore(STORE_BASKETS);
  
  return new Promise((resolve, reject) => {
    const request = store.get('baskets_data');
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

export async function saveEmojiPresets(presets: EmojiPreset[]): Promise<void> {
  const database = await openDB();
  const transaction = database.transaction([STORE_PRESETS], 'readwrite');
  const store = transaction.objectStore(STORE_PRESETS);
  
  return new Promise((resolve, reject) => {
    const request = store.put(presets, 'emoji_presets');
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function loadEmojiPresets(): Promise<EmojiPreset[] | null> {
  const database = await openDB();
  const transaction = database.transaction([STORE_PRESETS], 'readonly');
  const store = transaction.objectStore(STORE_PRESETS);
  
  return new Promise((resolve, reject) => {
    const request = store.get('emoji_presets');
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}
