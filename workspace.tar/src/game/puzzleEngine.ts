import { PuzzlePiece, PuzzleConfig } from './types';
import { soundManager } from './audio';

export class PuzzleEngine {
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private container: HTMLDivElement | null = null;
  
  private images: string[] = [];
  private imageElements: HTMLImageElement[] = [];
  private pieces: PuzzlePiece[] = [];
  private config: PuzzleConfig;
  
  private score = 0;
  private level = 1;
  private lives = 3;
  private currentImageIndex = 0;
  private timeLeft = 0;
  private timerInterval: number | null = null;
  private paused = false;
  
  private dragging: string | null = null;
  private dragOffsetX = 0;
  private dragOffsetY = 0;
  
  private destroyed = false;
  private animFrameId = 0;
  
  private onScoreChange: ((s: number) => void) | null = null;
  private onLivesChange: ((l: number) => void) | null = null;
  private onLevelChange: ((l: number) => void) | null = null;
  private onTimeChange: ((t: number) => void) | null = null;
  private onPuzzleComplete: (() => void) | null = null;
  private onGameOver: (() => void) | null = null;
  
  private handlePointerDown = (e: PointerEvent) => this.onPointerDown(e);
  private handlePointerMove = (e: PointerEvent) => this.onPointerMove(e);
  private handlePointerUp = () => this.onPointerUp();
  
  constructor(config: PuzzleConfig) {
    this.config = config;
  }
  
  async init(container: HTMLDivElement, images: string[]): Promise<void> {
    this.destroyed = false;
    this.container = container;
    this.images = images;
    
    this.score = 0;
    this.level = 1;
    this.lives = 3;
    this.currentImageIndex = 0;
    
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;
    
    this.canvas = document.createElement('canvas');
    this.canvas.width = width;
    this.canvas.height = height;
    this.canvas.style.width = '100%';
    this.canvas.style.height = '100%';
    this.canvas.style.display = 'block';
    this.canvas.style.touchAction = 'none';
    
    this.ctx = this.canvas.getContext('2d');
    container.appendChild(this.canvas);
    
    this.canvas.addEventListener('pointerdown', this.handlePointerDown);
    this.canvas.addEventListener('pointermove', this.handlePointerMove);
    this.canvas.addEventListener('pointerup', this.handlePointerUp);
    this.canvas.addEventListener('pointercancel', this.handlePointerUp);
    
    // Load images
    await this.loadImages();
    
    // Start first puzzle
    this.startPuzzle();
    
    this.animFrameId = requestAnimationFrame(this.gameLoop);
  }
  
  private async loadImages(): Promise<void> {
    this.imageElements = [];
    
    for (const url of this.images) {
      const img = new Image();
      img.src = url;
      await new Promise<void>((resolve) => {
        img.onload = () => resolve();
        img.onerror = () => resolve();
      });
      this.imageElements.push(img);
    }
  }
  
  private startPuzzle(): void {
    if (this.currentImageIndex >= this.images.length) {
      this.currentImageIndex = 0;
    }
    
    this.pieces = [];
    
    const img = this.imageElements[this.currentImageIndex];
    if (!img || !this.canvas) return;
    
    const canvasW = this.canvas.width;
    const canvasH = this.canvas.height;
    
    // Determine grid size based on config
    const gridSize = this.config.piecesPerSide === 4 ? 2 : 1; // 2 parts = 1x2, 4 parts = 2x2
    const piecesCount = this.config.piecesPerSide;
    
    // Calculate piece size
    const maxImgWidth = canvasW * 0.6;
    const maxImgHeight = canvasH * 0.5;
    const imgRatio = img.naturalWidth / img.naturalHeight;
    
    let drawWidth, drawHeight;
    if (imgRatio > maxImgWidth / maxImgHeight) {
      drawWidth = maxImgWidth;
      drawHeight = drawWidth / imgRatio;
    } else {
      drawHeight = maxImgHeight;
      drawWidth = drawHeight * imgRatio;
    }
    
    // For 2 parts: 1 row, 2 cols. For 4 parts: 2 rows, 2 cols
    const rows = this.config.piecesPerSide === 4 ? 2 : 1;
    const cols = this.config.piecesPerSide === 4 ? 2 : 2;
    
    const pieceWidth = drawWidth / cols;
    const pieceHeight = drawHeight / rows;
    
    // Position puzzle in center-top area
    const startX = (canvasW - drawWidth) / 2;
    const startY = canvasH * 0.1;
    
    // Create pieces
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const pieceIndex = row * cols + col;
        const targetX = startX + col * pieceWidth;
        const targetY = startY + row * pieceHeight;
        
        const piece: PuzzlePiece = {
          id: `piece_${pieceIndex}`,
          imageIndex: this.currentImageIndex,
          pieceIndex,
          x: pieceIndex === 0 ? targetX : canvasW * 0.1 + Math.random() * (canvasW * 0.8),
          y: pieceIndex === 0 ? targetY : canvasH * 0.65 + Math.random() * (canvasH * 0.1),
          targetX,
          targetY,
          width: pieceWidth,
          height: pieceHeight,
          isFixed: pieceIndex === 0,
          isPlaced: pieceIndex === 0,
        };
        
        this.pieces.push(piece);
      }
    }
    
    // Start timer
    this.timeLeft = this.config.timeLimit;
    this.startTimer();
  }
  
  private startTimer(): void {
    if (this.timerInterval) clearInterval(this.timerInterval);
    
    this.timerInterval = window.setInterval(() => {
      if (this.destroyed || this.paused) return;
      
      this.timeLeft--;
      this.onTimeChange?.(this.timeLeft);
      
      if (this.timeLeft <= 0) {
        this.lives--;
        this.onLivesChange?.(this.lives);
        
        if (this.lives <= 0) {
          this.gameOver();
        } else {
          this.nextPuzzle();
        }
      }
    }, 1000);
  }
  
  private nextPuzzle(): void {
    this.currentImageIndex++;
    this.level++;
    this.onLevelChange?.(this.level);
    this.startPuzzle();
  }
  
  private gameOver(): void {
    if (this.timerInterval) clearInterval(this.timerInterval);
    this.onGameOver?.();
  }
  
  private onPointerDown(e: PointerEvent): void {
    if (this.destroyed || this.paused || !this.canvas) return;
    
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    
    // Find piece under pointer (reverse order for top-most)
    for (let i = this.pieces.length - 1; i >= 0; i--) {
      const piece = this.pieces[i];
      if (piece.isFixed || piece.isPlaced) continue;
      
      if (x >= piece.x && x <= piece.x + piece.width &&
          y >= piece.y && y <= piece.y + piece.height) {
        this.dragging = piece.id;
        this.dragOffsetX = x - piece.x;
        this.dragOffsetY = y - piece.y;
        soundManager.playPickup();
        break;
      }
    }
  }
  
  private onPointerMove(e: PointerEvent): void {
    if (this.destroyed || this.paused || this.dragging === null || !this.canvas) return;
    
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    
    const piece = this.pieces.find(p => p.id === this.dragging);
    if (piece) {
      piece.x = x - this.dragOffsetX;
      piece.y = y - this.dragOffsetY;
    }
  }
  
  private onPointerUp(): void {
    if (this.destroyed || this.paused || this.dragging === null) return;
    
    const piece = this.pieces.find(p => p.id === this.dragging);
    if (piece) {
      // Check if close to target
      const dx = Math.abs(piece.x - piece.targetX);
      const dy = Math.abs(piece.y - piece.targetY);
      const threshold = 20;
      
      if (dx < threshold && dy < threshold) {
        // Snap to target
        piece.x = piece.targetX;
        piece.y = piece.targetY;
        piece.isPlaced = true;
        soundManager.playCorrect();
        
        // Check if all pieces placed
        const allPlaced = this.pieces.every(p => p.isPlaced);
        if (allPlaced) {
          this.score += 10;
          this.onScoreChange?.(this.score);
          this.onPuzzleComplete?.();
          soundManager.playComplete();
          
          setTimeout(() => this.nextPuzzle(), 1000);
        }
      } else {
        soundManager.playWrong();
      }
    }
    
    soundManager.playDrop();
    this.dragging = null;
  }
  
  private gameLoop = (): void => {
    if (this.destroyed || !this.ctx || !this.canvas) return;
    
    if (!this.paused) {
      this.render();
    }
    this.animFrameId = requestAnimationFrame(this.gameLoop);
  };
  
  private render(): void {
    if (!this.ctx || !this.canvas) return;
    
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    
    // БАГ 4 FIX: Отключаем сглаживание для резких пикселей
    ctx.imageSmoothingEnabled = false;
    
    // Clear with white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    
    // Draw pieces
    for (const piece of this.pieces) {
      const img = this.imageElements[piece.imageIndex];
      if (!img) continue;
      
      const rows = this.config.piecesPerSide === 4 ? 2 : 1;
      const cols = this.config.piecesPerSide === 4 ? 2 : 2;
      
      const col = piece.pieceIndex % cols;
      const row = Math.floor(piece.pieceIndex / cols);
      
      const sx = (img.naturalWidth / cols) * col;
      const sy = (img.naturalHeight / rows) * row;
      const sw = img.naturalWidth / cols;
      const sh = img.naturalHeight / rows;
      
      ctx.save();
      
      // Rounded corners
      ctx.beginPath();
      ctx.roundRect(piece.x, piece.y, piece.width, piece.height, 4);
      ctx.clip();
      
      ctx.drawImage(img, sx, sy, sw, sh, piece.x, piece.y, piece.width, piece.height);
      
      ctx.restore();
      
      // Border
      ctx.strokeStyle = piece.isPlaced ? '#22c55e' : '#fbbf24';
      ctx.lineWidth = 2;
      ctx.strokeRect(piece.x, piece.y, piece.width, piece.height);
    }
    
    // HUD
    ctx.fillStyle = '#1f2937';
    ctx.font = 'bold 18px system-ui, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(`Счёт: ${this.score}`, 10, 10);
    
    ctx.fillStyle = '#6b7280';
    ctx.textAlign = 'center';
    ctx.fillText(`Ур: ${this.level}`, w / 2, 10);
    
    ctx.fillStyle = '#ef4444';
    ctx.font = '20px sans-serif';
    ctx.textAlign = 'right';
    const hearts = '❤'.repeat(this.lives) + '♡'.repeat(Math.max(0, 3 - this.lives));
    ctx.fillText(hearts, w - 10, 10);
    
    // Timer
    ctx.fillStyle = this.timeLeft <= 10 ? '#ef4444' : '#1f2937';
    ctx.font = 'bold 24px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`${this.timeLeft}с`, w / 2, 40);
  }
  
  // Public API
  setCallbacks(cb: {
    onScoreChange?: (s: number) => void;
    onLivesChange?: (l: number) => void;
    onLevelChange?: (l: number) => void;
    onTimeChange?: (t: number) => void;
    onPuzzleComplete?: () => void;
    onGameOver?: () => void;
  }): void {
    this.onScoreChange = cb.onScoreChange || null;
    this.onLivesChange = cb.onLivesChange || null;
    this.onLevelChange = cb.onLevelChange || null;
    this.onTimeChange = cb.onTimeChange || null;
    this.onPuzzleComplete = cb.onPuzzleComplete || null;
    this.onGameOver = cb.onGameOver || null;
  }
  
  resize(w: number, h: number): void {
    if (this.destroyed || !this.canvas) return;
    this.canvas.width = w;
    this.canvas.height = h;
  }
  
  setPaused(paused: boolean): void {
    this.paused = paused;
  }
  
  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = 0;
    }
    
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
    
    if (this.canvas) {
      this.canvas.removeEventListener('pointerdown', this.handlePointerDown);
      this.canvas.removeEventListener('pointermove', this.handlePointerMove);
      this.canvas.removeEventListener('pointerup', this.handlePointerUp);
      this.canvas.removeEventListener('pointercancel', this.handlePointerUp);
      this.canvas = null;
      this.ctx = null;
    }
    
    this.pieces = [];
    this.imageElements = [];
  }
}
