import { GameSettings } from './types';

const SETTINGS_KEY = 'sortgame_settings_v1';

const DEFAULT_SETTINGS: GameSettings = {
  basketCount: 3,
  itemSize: 100,
  spawnMode: 'fall',
  sound: true,
  basketScale: 100,
  slotCount: 12,
};

export function loadSettings(): GameSettings {
  try {
    const stored = localStorage.getItem(SETTINGS_KEY);
    if (stored) {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
    }
  } catch (e) {
    console.warn('Failed to load settings:', e);
  }
  return { ...DEFAULT_SETTINGS };
}

export function saveSettings(settings: GameSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.warn('Failed to save settings:', e);
  }
}
