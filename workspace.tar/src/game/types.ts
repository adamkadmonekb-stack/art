export type SpawnMode = 'fall' | 'random';

export interface BasketConfig {
  id: string;
  name: string;
  basketPhoto?: string; // data URL — фон корзины
  categoryIcon?: string; // data URL — иконка категории
  dropImages: string[]; // data URLs — картинки для падения
}

export interface GameSettings {
  basketCount: number;
  itemSize: number; // 50-200, процент
  spawnMode: SpawnMode;
  sound: boolean;
  basketScale: number; // 50-150, процент
  slotCount: number; // 4-24, количество квадратиков в ряду
}

export interface FallingItem {
  id: number;
  basketId: string;
  imageUrl: string;
  x: number;
  y: number;
  speed: number;
  size: number;
}

export interface BasketRect {
  x: number;
  y: number;
  width: number;
  height: number;
  basketId: string;
}

export interface EmojiPreset {
  id: string;
  name: string;
  emojis: string[]; // Список выбранных эмодзи
  createdAt: number;
}

export interface PuzzlePiece {
  id: string;
  imageIndex: number; // Индекс картинки
  pieceIndex: number; // Индекс части (0 = фиксированная)
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  width: number;
  height: number;
  isFixed: boolean;
  isPlaced: boolean;
}

export interface PuzzleConfig {
  piecesPerSide: 2 | 4; // 2 части или 4 части (2x2)
  timeLimit: number; // секунды
}
