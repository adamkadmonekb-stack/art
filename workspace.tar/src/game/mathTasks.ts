export interface MathTask {
  question: string;
  answer: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export const MATH_TASKS: MathTask[] = [
  // Easy - Addition
  { question: '1 + 1', answer: '2', difficulty: 'easy' },
  { question: '2 + 3', answer: '5', difficulty: 'easy' },
  { question: '4 + 4', answer: '8', difficulty: 'easy' },
  { question: '5 + 3', answer: '8', difficulty: 'easy' },
  { question: '6 + 2', answer: '8', difficulty: 'easy' },
  { question: '7 + 1', answer: '8', difficulty: 'easy' },
  { question: '3 + 3', answer: '6', difficulty: 'easy' },
  { question: '9 + 1', answer: '10', difficulty: 'easy' },
  
  // Medium - Addition with larger numbers
  { question: '10 + 5', answer: '15', difficulty: 'medium' },
  { question: '20 + 30', answer: '50', difficulty: 'medium' },
  { question: '15 + 15', answer: '30', difficulty: 'medium' },
  { question: '25 + 25', answer: '50', difficulty: 'medium' },
  { question: '12 + 8', answer: '20', difficulty: 'medium' },
  { question: '35 + 15', answer: '50', difficulty: 'medium' },
  
  // Hard - Multiplication
  { question: '2 × 3', answer: '6', difficulty: 'hard' },
  { question: '3 × 4', answer: '12', difficulty: 'hard' },
  { question: '5 × 5', answer: '25', difficulty: 'hard' },
  { question: '4 × 6', answer: '24', difficulty: 'hard' },
  { question: '7 × 2', answer: '14', difficulty: 'hard' },
  { question: '8 × 3', answer: '24', difficulty: 'hard' },
  { question: '9 × 2', answer: '18', difficulty: 'hard' },
  { question: '6 × 6', answer: '36', difficulty: 'hard' },
  
  // Very hard - Large multiplication
  { question: '10 × 10', answer: '100', difficulty: 'hard' },
  { question: '12 × 5', answer: '60', difficulty: 'hard' },
  { question: '15 × 4', answer: '60', difficulty: 'hard' },
  { question: '20 × 5', answer: '100', difficulty: 'hard' },
  { question: '25 × 4', answer: '100', difficulty: 'hard' },
];

export function getTasksByDifficulty(difficulty: 'easy' | 'medium' | 'hard'): MathTask[] {
  return MATH_TASKS.filter(t => t.difficulty === difficulty);
}

export function getRandomTask(difficulty?: 'easy' | 'medium' | 'hard'): MathTask {
  const tasks = difficulty ? getTasksByDifficulty(difficulty) : MATH_TASKS;
  return tasks[Math.floor(Math.random() * tasks.length)];
}
