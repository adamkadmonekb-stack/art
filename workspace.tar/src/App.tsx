import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import SigilRenderer, { SigilStyle, SigilColor } from './components/SigilRenderer';
import { normalizeWord, buildSigil, formatWord, buildNormalizedString } from './lib/sigilBuilder';
import { saveFile, saveBinaryFile, copyToClipboard } from './lib/fileIO';

// Пресеты
const PRESETS: Record<string, string[]> = {
  'Ангелы': ['Метатрон', 'Гавриил', 'Рафаил', 'Уриил'],
  'Защита': ['Защита', 'Щит', 'Оберег'],
  'Любовь': ['Любовь', 'Афродита', 'Венера'],
};

// Скорости анимации
const SPEEDS: Record<string, number> = {
  'Медленно': 3000,
  'Средне': 1500,
  'Быстро': 700,
};

function App() {
  const [word, setWord] = useState('Метатрон');
  const [sigilStyle, setSigilStyle] = useState<SigilStyle>('classic');
  const [sigilColor, setSigilColor] = useState<SigilColor>('purple');
  const [customColor, setCustomColor] = useState<string>('#6b21a8');
  const [speed, setSpeed] = useState<string>('Средне');
  const [showWord, setShowWord] = useState(true);
  const [showNormalized, setShowNormalized] = useState(true);
  const [showCutLine, setShowCutLine] = useState(true);
  const [animated, setAnimated] = useState(false);
  const [built, setBuilt] = useState(false);
  const [history, setHistory] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('sigil-history');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  const [copied, setCopied] = useState(false);
  const [notification, setNotification] = useState('');

  const svgRef = useRef<SVGSVGElement>(null);

  // Нормализация и построение сигилы
  const { letters: rawLetters, skipped } = useMemo(
    () => normalizeWord(word),
    [word]
  );

  const { points, fullPath, startPoint, endPoint, lastDirection } = useMemo(
    () => buildSigil(rawLetters),
    [rawLetters]
  );

  // Отладочный вывод углов
  useEffect(() => {
    if (points.length > 0) {
      console.log('=== Отладка углов ===');
      console.log('Слово:', word);
      console.log('Буквы:', rawLetters);
      points.forEach((p, i) => {
        console.log(`${i}. ${p.letter}: x=${p.x.toFixed(2)}, y=${p.y.toFixed(2)}, repeat=${p.isRepeat}`);
      });
    }
  }, [points, rawLetters, word]);

  const formattedWord = useMemo(() => formatWord(word), [word]);
  const normalizedString = useMemo(() => buildNormalizedString(rawLetters), [rawLetters]);

  // Построить
  const handleBuild = useCallback(() => {
    setBuilt(true);
    setAnimated(false);
  }, []);

  // Анимировать
  const handleAnimate = useCallback(() => {
    if (!fullPath) return;
    setAnimated(false);
    setTimeout(() => setAnimated(true), 50);
    setBuilt(true);
  }, [fullPath]);

  // Сохранить в историю
  useEffect(() => {
    if (built && word.trim()) {
      setHistory(prev => {
        const next = [word.trim(), ...prev.filter(w => w !== word.trim())].slice(0, 20);
        localStorage.setItem('sigil-history', JSON.stringify(next));
        return next;
      });
    }
  }, [built, word]);

  // Уведомление
  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(''), 2000);
  };

  // Получить чистый SVG для экспорта (без анимации)
  const getExportSVG = (): string => {
    if (!svgRef.current) return '';
    const clone = svgRef.current.cloneNode(true) as SVGSVGElement;
    const paths = clone.querySelectorAll('path');
    paths.forEach(p => {
      p.removeAttribute('style');
      p.removeAttribute('class');
    });
    const lines = clone.querySelectorAll('line[style]');
    lines.forEach(l => {
      l.removeAttribute('style');
    });
    return new XMLSerializer().serializeToString(clone);
  };

  // Получить цвет сигилы
  const getStrokeColor = (): string => {
    if (sigilColor === 'custom') return customColor;
    if (sigilColor === 'purple') return '#6b21a8';
    if (sigilColor === 'red') return '#dc2626';
    return '#059669';
  };

  // Экспорт PNG с матрицей
  const exportPNGWithMatrix = async () => {
    const svgData = getExportSVG();
    if (!svgData) return;
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 1200;
      canvas.height = 1300;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0, 1200, 1300);
      canvas.toBlob(async (blob) => {
        if (blob) {
          const buffer = await blob.arrayBuffer();
          await saveBinaryFile(`sigil-${formattedWord || 'sigil'}.png`, new Uint8Array(buffer), 'image/png');
          showNotification('PNG сохранён!');
        }
      });
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  // Экспорт PNG без матрицы (только сигила)
  const exportPNGWithoutMatrix = async () => {
    if (!fullPath || points.length < 2) return;
    const strokeColor = getStrokeColor();

    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const p of points) {
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x);
      maxY = Math.max(maxY, p.y);
    }
    const padding = 40;
    const w = maxX - minX + padding * 2;
    const h = maxY - minY + padding * 2 + 60;

    const svgStr = `<svg viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg">
      <rect width="${w}" height="${h}" fill="white"/>
      <g transform="translate(${-minX + padding}, ${-minY + padding})">
        <circle cx="${points[0].x}" cy="${points[0].y}" r="7" fill="none" stroke="${strokeColor}" stroke-width="2.5"/>
        <path d="${fullPath}" fill="none" stroke="${strokeColor}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
      </g>
      <text x="${w / 2}" y="${h - 20}" text-anchor="middle" font-size="16" font-weight="bold" fill="#333">${formattedWord}</text>
    </svg>`;

    const svgBlob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = w * 2;
      canvas.height = h * 2;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0, w * 2, h * 2);
      canvas.toBlob(async (blob) => {
        if (blob) {
          const buffer = await blob.arrayBuffer();
          await saveBinaryFile(`sigil-clean-${formattedWord || 'sigil'}.png`, new Uint8Array(buffer), 'image/png');
          showNotification('PNG (без матрицы) сохранён!');
        }
      });
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  // Экспорт SVG
  const exportSVG = async () => {
    const svgData = getExportSVG();
    if (!svgData) return;
    await saveFile(`sigil-${formattedWord || 'sigil'}.svg`, svgData, 'image/svg+xml');
    showNotification('SVG сохранён!');
  };

  // Копировать SVG сигилы
  const copySigilSVG = async () => {
    if (!fullPath || points.length < 2) return;
    const strokeColor = getStrokeColor();

    const svgStr = `<svg viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
      <circle cx="${points[0].x}" cy="${points[0].y}" r="7" fill="none" stroke="${strokeColor}" stroke-width="2.5"/>
      <path d="${fullPath}" fill="none" stroke="${strokeColor}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;

    const ok = await copyToClipboard(svgStr);
    if (ok) {
      setCopied(true);
      showNotification('SVG скопирован!');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Горячие клавиши
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Enter' && !e.ctrlKey) {
        e.preventDefault();
        handleBuild();
      } else if (e.key === ' ' && !e.ctrlKey) {
        e.preventDefault();
        handleAnimate();
      } else if (e.key === 's' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        exportPNGWithMatrix();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [handleBuild, handleAnimate, word]);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col">
      {/* Шапка */}
      <header className="bg-zinc-900 border-b border-white/10 px-4 py-3 flex items-center gap-3">
        <span className="text-2xl">🌹</span>
        <h1 className="text-lg md:text-xl font-bold">Световая Матрица Адама Кадмона</h1>
      </header>

      {/* Уведомление */}
      {notification && (
        <div className="fixed top-4 right-4 bg-green-700 text-white px-4 py-2 rounded-xl z-50 transition-colors duration-150">
          {notification}
        </div>
      )}

      <div className="flex-1 flex flex-col lg:flex-row gap-4 p-4 max-w-7xl mx-auto w-full">
        {/* Левая панель — управление */}
        <div className="lg:w-80 flex-shrink-0 space-y-4">
          {/* Ввод */}
          <div className="bg-zinc-900 border border-white/10 rounded-xl p-4 space-y-3">
            <label className="block text-sm text-zinc-400">Введите слово или фразу:</label>
            <input
              type="text"
              value={word}
              onChange={(e) => setWord(e.target.value)}
              placeholder="Метатрон"
              className="w-full bg-zinc-800 border border-white/10 rounded-lg px-3 py-3 text-lg font-bold tracking-wide focus:outline-none focus:border-purple-500 transition-colors duration-150"
            />

            {/* Стиль */}
            <div className="space-y-2">
              <label className="block text-sm text-zinc-400">Стиль:</label>
              <select
                value={sigilStyle}
                onChange={(e) => setSigilStyle(e.target.value as SigilStyle)}
                className="w-full bg-zinc-800 border border-white/10 rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500 transition-colors duration-150"
              >
                <option value="classic">◉ Классика (чёрно-белый)</option>
                <option value="metallic">◉ Металлический</option>
              </select>
            </div>

            {/* Цвет сигила */}
            <div className="space-y-2">
              <label className="block text-sm text-zinc-400">Цвет сигила:</label>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setSigilColor('purple')}
                  className={`py-2 px-3 rounded-lg border transition-colors duration-150 flex items-center justify-center gap-2 ${
                    sigilColor === 'purple' ? 'border-purple-500 bg-purple-900/30' : 'border-white/10 bg-zinc-800'
                  }`}
                >
                  <span className="w-4 h-4 rounded" style={{ backgroundColor: '#6b21a8' }}></span>
                  <span className="text-sm">Пурпурный</span>
                </button>
                <button
                  onClick={() => setSigilColor('red')}
                  className={`py-2 px-3 rounded-lg border transition-colors duration-150 flex items-center justify-center gap-2 ${
                    sigilColor === 'red' ? 'border-red-500 bg-red-900/30' : 'border-white/10 bg-zinc-800'
                  }`}
                >
                  <span className="w-4 h-4 rounded" style={{ backgroundColor: '#dc2626' }}></span>
                  <span className="text-sm">Красный</span>
                </button>
                <button
                  onClick={() => setSigilColor('green')}
                  className={`py-2 px-3 rounded-lg border transition-colors duration-150 flex items-center justify-center gap-2 ${
                    sigilColor === 'green' ? 'border-green-500 bg-green-900/30' : 'border-white/10 bg-zinc-800'
                  }`}
                >
                  <span className="w-4 h-4 rounded" style={{ backgroundColor: '#059669' }}></span>
                  <span className="text-sm">Изумрудный</span>
                </button>
                <label
                  className={`py-2 px-3 rounded-lg border transition-colors duration-150 flex items-center justify-center gap-2 cursor-pointer ${
                    sigilColor === 'custom' ? 'border-blue-500 bg-blue-900/30' : 'border-white/10 bg-zinc-800'
                  }`}
                >
                  <input
                    type="color"
                    value={customColor}
                    onChange={(e) => {
                      setCustomColor(e.target.value);
                      setSigilColor('custom');
                    }}
                    className="w-4 h-4 rounded cursor-pointer border-0 bg-transparent"
                  />
                  <span className="text-sm">Свой</span>
                </label>
              </div>
            </div>

            {/* Скорость */}
            <div className="space-y-2">
              <label className="block text-sm text-zinc-400">Скорость анимации:</label>
              <select
                value={speed}
                onChange={(e) => setSpeed(e.target.value)}
                className="w-full bg-zinc-800 border border-white/10 rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500 transition-colors duration-150"
              >
                {Object.keys(SPEEDS).map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Опции */}
          <div className="bg-zinc-900 border border-white/10 rounded-xl p-4 space-y-3">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={showWord} onChange={(e) => setShowWord(e.target.checked)}
                className="w-4 h-4 rounded accent-purple-500" />
              <span className="text-sm text-white">Показывать исходное слово</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={showNormalized} onChange={(e) => setShowNormalized(e.target.checked)}
                className="w-4 h-4 rounded accent-purple-500" />
              <span className="text-sm text-white">Показывать нормализованные буквы</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={showCutLine} onChange={(e) => setShowCutLine(e.target.checked)}
                className="w-4 h-4 rounded accent-purple-500" />
              <span className="text-sm text-white">Линия разреза</span>
            </label>
          </div>

          {/* Кнопки */}
          <div className="flex gap-2">
            <button
              onClick={handleBuild}
              className="flex-1 bg-purple-700 hover:bg-purple-600 text-white font-bold py-3 px-4 rounded-xl transition-colors duration-150 min-h-[44px]"
            >
              🎨 Построить
            </button>
            <button
              onClick={handleAnimate}
              disabled={!fullPath}
              className="flex-1 bg-zinc-700 hover:bg-zinc-600 disabled:opacity-40 text-white font-bold py-3 px-4 rounded-xl transition-colors duration-150 min-h-[44px]"
            >
              ▶️ Анимировать
            </button>
          </div>

          {/* Пресеты */}
          <div className="bg-zinc-900 border border-white/10 rounded-xl p-4 space-y-2">
            <h3 className="text-sm text-zinc-400 font-bold">Пресеты:</h3>
            {Object.entries(PRESETS).map(([name, words]) => (
              <div key={name} className="space-y-1">
                <span className="text-xs text-zinc-500">{name}:</span>
                <div className="flex flex-wrap gap-1">
                  {words.map(w => (
                    <button
                      key={w}
                      onClick={() => { setWord(w); setBuilt(false); }}
                      className="text-xs bg-zinc-800 hover:bg-zinc-700 border border-white/10 rounded px-2 py-1 transition-colors duration-150"
                    >
                      {w}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* История */}
          {history.length > 0 && (
            <div className="bg-zinc-900 border border-white/10 rounded-xl p-4 space-y-2">
              <h3 className="text-sm text-zinc-400 font-bold">История:</h3>
              <div className="flex flex-wrap gap-1 max-h-32 overflow-y-auto scrollbar-hide">
                {history.map(w => (
                  <button
                    key={w}
                    onClick={() => { setWord(w); setBuilt(false); }}
                    className="text-xs bg-zinc-800 hover:bg-zinc-700 border border-white/10 rounded px-2 py-1 transition-colors duration-150"
                  >
                    {w}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Правая панель — SVG + инфо */}
        <div className="flex-1 space-y-4">
          {/* SVG */}
          <div className="bg-zinc-900 border border-white/10 rounded-xl p-4">
            <div className="w-full max-w-[600px] mx-auto aspect-[600/650]">
              {built && fullPath ? (
                <SigilRenderer
                  ref={svgRef}
                  style={sigilStyle}
                  sigilColor={sigilColor}
                  customColor={customColor}
                  fullPath={fullPath.trimStart()}
                  points={points}
                  startPoint={startPoint}
                  endPoint={endPoint}
                  lastDirection={lastDirection}
                  isEndPointRepeat={points.length > 0 && points[points.length - 1].isRepeat}
                  animated={animated}
                  animationDuration={SPEEDS[speed]}
                  showWord={showWord}
                  showNormalized={showNormalized}
                  showCutLine={showCutLine}
                  word={formattedWord}
                  normalizedString={normalizedString}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-zinc-500 text-center">
                  <div>
                    <div className="text-4xl mb-2">🌹</div>
                    <p>Введите слово и нажмите «Построить»</p>
                    <p className="text-xs mt-2 text-zinc-600">Enter — построить · Space — анимировать · Ctrl+S — сохранить</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Инфо */}
          {built && (
            <div className="bg-zinc-900 border border-white/10 rounded-xl p-4 space-y-2">
              <h3 className="text-sm font-bold text-zinc-400">📊 ИНФО</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                <div><span className="text-zinc-500">Исходное слово:</span> <span className="font-bold">{formattedWord || '—'}</span></div>
                <div><span className="text-zinc-500">Нормализовано:</span> <span className="font-mono text-xs">{normalizedString || '—'}</span></div>
                <div><span className="text-zinc-500">Точек на сигиле:</span> <span className="font-bold">{points.length}</span></div>
                <div><span className="text-zinc-500">Повторов:</span> <span className="font-bold">{points.filter(p => p.isRepeat).length}</span></div>
              </div>
              {skipped.length > 0 && (
                <div className="text-xs text-yellow-500">
                  ⚠️ Пропущены: {skipped.join(', ')}
                </div>
              )}
            </div>
          )}

          {/* Экспорт */}
          {built && fullPath && (
            <div className="bg-zinc-900 border border-white/10 rounded-xl p-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  onClick={exportPNGWithMatrix}
                  className="bg-zinc-800 hover:bg-zinc-700 border border-white/10 text-sm py-3 px-2 rounded-xl transition-colors duration-150 min-h-[44px]"
                >
                  💾 С матрицей
                </button>
                <button
                  onClick={exportPNGWithoutMatrix}
                  className="bg-zinc-800 hover:bg-zinc-700 border border-white/10 text-sm py-3 px-2 rounded-xl transition-colors duration-150 min-h-[44px]"
                >
                  💾 Без матрицы
                </button>
                <button
                  onClick={exportSVG}
                  className="bg-zinc-800 hover:bg-zinc-700 border border-white/10 text-sm py-3 px-2 rounded-xl transition-colors duration-150 min-h-[44px]"
                >
                  💾 SVG
                </button>
                <button
                  onClick={copySigilSVG}
                  className={`border text-sm py-3 px-2 rounded-xl transition-colors duration-150 min-h-[44px] ${
                    copied ? 'bg-green-700 border-green-500' : 'bg-zinc-800 hover:bg-zinc-700 border-white/10'
                  }`}
                >
                  📋 {copied ? 'Скопировано!' : 'Копировать'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Подвал */}
      <footer className="bg-zinc-900 border-t border-white/10 px-4 py-2 text-center text-xs text-zinc-600">
        Световая Матрица Адама Кадмона • Генератор Сигил
      </footer>
    </div>
  );
}

export default App;
