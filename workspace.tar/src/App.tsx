import { useState, useEffect, useRef, useCallback } from 'react';
import { GameEngine } from './game/engine';
import { BasketConfig, GameSettings, EmojiPreset } from './game/types';
import { saveBaskets, loadBaskets, saveEmojiPresets, loadEmojiPresets } from './game/storage';
import { loadSettings, saveSettings } from './game/settingsStorage';
import { initAudio, soundManager, SoundSet } from './game/audio';

import { PuzzleEngine } from './game/puzzleEngine';
import { MathEngine } from './game/mathEngine';
import { PuzzleConfig } from './game/types';
import MathSetupScreen from './components/MathSetupScreen';

import { DigitsEngine } from './game/digitsEngine';
import PixelEditor from './components/PixelEditor';

type Screen = 'menu' | 'setup' | 'game' | 'gameover' | 'settings' | 'emojiPicker' | 'puzzle' | 'puzzleSetup' | 'math' | 'mathSetup' | 'mathManual' | 'digits' | 'pixelEditor';

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [settings, setSettings] = useState<GameSettings>(loadSettings());
  const [baskets, setBaskets] = useState<BasketConfig[]>([]);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [level, setLevel] = useState(1);
  const [paused, setPaused] = useState(false);
  const [pauseItemSize, setPauseItemSize] = useState(settings.itemSize);
  const [pauseBasketScale, setPauseBasketScale] = useState(settings.basketScale);
  
  // Emoji picker state
  const [loadedEmojis, setLoadedEmojis] = useState<string[]>([]);
  const [selectedEmojis, setSelectedEmojis] = useState<Set<string>>(new Set());
  const [emojiPresets, setEmojiPresets] = useState<EmojiPreset[]>([]);
  
  // Puzzle state
  const [puzzleTime, setPuzzleTime] = useState(30);
  
  const gameContainerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const puzzleEngineRef = useRef<PuzzleEngine | null>(null);
  const mathEngineRef = useRef<MathEngine | null>(null);
  const digitsEngineRef = useRef<DigitsEngine | null>(null);
  
  // Load baskets from IndexedDB on mount
  useEffect(() => {
    loadBaskets().then(saved => {
      if (saved && saved.length > 0) {
        setBaskets(saved);
      } else {
        const defaultBaskets: BasketConfig[] = Array.from({ length: settings.basketCount }, (_, i) => ({
          id: `basket_${i}`,
          name: `Корзина ${i + 1}`,
          dropImages: [],
        }));
        setBaskets(defaultBaskets);
      }
    });
    
    // Load emoji presets
    loadEmojiPresets().then(saved => {
      if (saved && saved.length > 0) {
        setEmojiPresets(saved);
      }
    });
  }, []);
  
  // Save settings when changed
  useEffect(() => {
    saveSettings(settings);
    if (engineRef.current) {
      engineRef.current.setSound(settings.sound);
    }
  }, [settings]);
  
  const startGame = useCallback(async () => {
    initAudio();
    
    if (engineRef.current) {
      engineRef.current.destroy();
      engineRef.current = null;
    }
    
    setScreen('game');
    setScore(0);
    setLives(3);
    setLevel(1);
    setPaused(false);
    setPauseItemSize(settings.itemSize);
    setPauseBasketScale(settings.basketScale);
    
    await new Promise(r => setTimeout(r, 150));
    
    if (!gameContainerRef.current) return;
    
    // Передаём все корзины, а не только с картинками
    const validBaskets = baskets;
    if (validBaskets.length < 2) {
      alert('Добавьте хотя бы 2 корзины!');
      setScreen('setup');
      return;
    }
    
    // Проверяем что хотя бы у 2 корзин есть картинки
    const basketsWithImages = validBaskets.filter(b => b.dropImages.length > 0);
    if (basketsWithImages.length < 2) {
      alert('Добавьте картинки хотя бы в 2 корзины!');
      setScreen('setup');
      return;
    }
    
    const engine = new GameEngine();
    engineRef.current = engine;
    
    await engine.init(gameContainerRef.current, validBaskets, settings.spawnMode, settings.itemSize);
    engine.setSound(settings.sound);
    engine.setBasketScale(settings.basketScale);
    
    engine.setCallbacks({
      onScoreChange: (s) => setScore(s),
      onLivesChange: (l) => {
        setLives(l);
        if (l <= 0) {
          setTimeout(() => {
            if (engineRef.current) {
              engineRef.current.destroy();
              engineRef.current = null;
            }
            setScreen('gameover');
          }, 600);
        }
      },
      onLevelChange: (l) => setLevel(l),
      onGameOver: () => {
        if (engineRef.current) {
          engineRef.current.destroy();
          engineRef.current = null;
        }
        setScreen('gameover');
      },
    });
  }, [baskets, settings]);
  
  useEffect(() => {
    return () => {
      if (engineRef.current) {
        engineRef.current.destroy();
        engineRef.current = null;
      }
    };
  }, []);
  
  useEffect(() => {
    const handleResize = () => {
      if (engineRef.current && gameContainerRef.current) {
        engineRef.current.resize(
          gameContainerRef.current.clientWidth,
          gameContainerRef.current.clientHeight
        );
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [screen]);
  
  // Auto-save rows data every 5 seconds
  useEffect(() => {
    if (screen !== 'mathManual') return;
    
    const interval = setInterval(() => {
      if (digitsEngineRef.current) {
        const rowsData = digitsEngineRef.current.getRowsData();
        localStorage.setItem('mathManualRowsData', JSON.stringify(rowsData));
      }
    }, 5000);
    
    return () => clearInterval(interval);
  }, [screen]);
  
  const goToMenu = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.destroy();
      engineRef.current = null;
    }
    if (puzzleEngineRef.current) {
      puzzleEngineRef.current.destroy();
      puzzleEngineRef.current = null;
    }
    if (mathEngineRef.current) {
      mathEngineRef.current.destroy();
      mathEngineRef.current = null;
    }
    if (digitsEngineRef.current) {
      digitsEngineRef.current.destroy();
      digitsEngineRef.current = null;
    }
    setScreen('menu');
  }, []);
  
  const startDigits = useCallback(async () => {
    if (digitsEngineRef.current) {
      digitsEngineRef.current.destroy();
      digitsEngineRef.current = null;
    }
    
    setScreen('digits');
    
    await new Promise(r => setTimeout(r, 150));
    
    if (!gameContainerRef.current) return;
    
    // Use selected emojis/images or default
    const images = selectedEmojis.size > 0
      ? Array.from(selectedEmojis)
      : ['🍎', '🍌', '🍊', '🍇', '🍓'];
    
    const engine = new DigitsEngine();
    digitsEngineRef.current = engine;
    
    await engine.init(gameContainerRef.current, images);
  }, [selectedEmojis]);
  
  const [puzzleImages, setPuzzleImages] = useState<string[]>([]);
  const [puzzlePiecesMode, setPuzzlePiecesMode] = useState<2 | 4>(2);
  const [mathManualPreset, setMathManualPreset] = useState<string | null>(null);
  const [mathManualSquareSize, setMathManualSquareSize] = useState(100);
  const [mathManualSlotCount, setMathManualSlotCount] = useState(12);
  const [mathManualRowCount, setMathManualRowCount] = useState(1);
  
  // Preset management modals
  const [showNewPresetModal, setShowNewPresetModal] = useState(false);
  const [showChangePresetModal, setShowChangePresetModal] = useState(false);
  const [newPresetName, setNewPresetName] = useState('');
  const [newPresetImages, setNewPresetImages] = useState<string[]>([]);
  
  const startPuzzle = useCallback(() => {
    setScreen('puzzleSetup');
    setPuzzleImages([]);
  }, []);
  
  const startPuzzleGame = useCallback(async () => {
    if (puzzleEngineRef.current) {
      puzzleEngineRef.current.destroy();
      puzzleEngineRef.current = null;
    }
    
    setScreen('puzzle');
    setScore(0);
    setLives(3);
    setLevel(1);
    
    await new Promise(r => setTimeout(r, 150));
    
    if (!gameContainerRef.current) return;
    
    const config: PuzzleConfig = {
      piecesPerSide: puzzlePiecesMode,
      timeLimit: puzzleTime,
    };
    
    const engine = new PuzzleEngine(config);
    puzzleEngineRef.current = engine;
    
    await engine.init(gameContainerRef.current, puzzleImages);
    
    engine.setCallbacks({
      onScoreChange: (s) => setScore(s),
      onLivesChange: (l) => {
        setLives(l);
        if (l <= 0) {
          setTimeout(() => {
            if (puzzleEngineRef.current) {
              puzzleEngineRef.current.destroy();
              puzzleEngineRef.current = null;
            }
            setScreen('gameover');
          }, 600);
        }
      },
      onLevelChange: (l) => setLevel(l),
      onGameOver: () => {
        if (puzzleEngineRef.current) {
          puzzleEngineRef.current.destroy();
          puzzleEngineRef.current = null;
        }
        setScreen('gameover');
      },
    });
  }, [puzzleImages, puzzlePiecesMode, puzzleTime]);
  
  const startMath = useCallback(async (operations: string[] = ['+', '-'], difficulty: 'easy' | 'medium' | 'hard' = 'easy') => {
    if (mathEngineRef.current) {
      mathEngineRef.current.destroy();
      mathEngineRef.current = null;
    }
    
    setScreen('math');
    setScore(0);
    setLives(3);
    setLevel(1);
    
    await new Promise(r => setTimeout(r, 150));
    
    if (!gameContainerRef.current) return;
    
    const engine = new MathEngine();
    mathEngineRef.current = engine;
    
    await engine.init(gameContainerRef.current, operations, difficulty);
    
    engine.setCallbacks({
      onScoreChange: (s) => setScore(s),
      onLivesChange: (l) => {
        setLives(l);
        if (l <= 0) {
          setTimeout(() => {
            if (mathEngineRef.current) {
              mathEngineRef.current.destroy();
              mathEngineRef.current = null;
            }
            setScreen('gameover');
          }, 600);
        }
      },
      onLevelChange: (l) => setLevel(l),
      onGameOver: () => {
        if (mathEngineRef.current) {
          mathEngineRef.current.destroy();
          mathEngineRef.current = null;
        }
        setScreen('gameover');
      },
    });
  }, []);
  
  const startMathManual = useCallback(async (presetId?: string, squareSize?: number, slotCount?: number) => {
    if (digitsEngineRef.current) {
      digitsEngineRef.current.destroy();
      digitsEngineRef.current = null;
    }
    
    setScreen('mathManual');
    setScore(0);
    setLives(3);
    setLevel(1);
    
    await new Promise(r => setTimeout(r, 150));
    
    if (!gameContainerRef.current) return;
    
    // Get images from selected preset
    let images: string[] = [];
    if (presetId) {
      const preset = emojiPresets.find(p => p.id === presetId);
      if (preset) {
        images = preset.emojis;
      }
    }
    
    const engine = new DigitsEngine();
    digitsEngineRef.current = engine;
    
    await engine.init(gameContainerRef.current, images, squareSize || 100, slotCount || 12);
    
    // Restore row count from localStorage
    const savedRowCount = localStorage.getItem('mathManualRowCount');
    if (savedRowCount) {
      const rowCount = parseInt(savedRowCount, 10);
      for (let i = 1; i < rowCount; i++) {
        engine.addRow();
      }
      setMathManualRowCount(engine.getRowCount());
    }
    
    // Restore rows data from localStorage
    const savedRowsData = localStorage.getItem('mathManualRowsData');
    if (savedRowsData) {
      try {
        const rowsData = JSON.parse(savedRowsData);
        engine.setRowsData(rowsData);
      } catch (e) {
        console.warn('Failed to restore rows data:', e);
      }
    }
  }, [emojiPresets]);
  
  // Preset management functions
  const addImagesToCurrentPreset = useCallback(async (files: FileList) => {
    if (!mathManualPreset) return;
    
    const currentPreset = emojiPresets.find(p => p.id === mathManualPreset);
    if (!currentPreset) return;
    
    const newImages: string[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type.startsWith('image/')) {
        try {
          const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });
          
          if (file.type === 'image/webp' || file.type === 'image/gif') {
            const img = new Image();
            img.onload = () => {
              const canvas = document.createElement('canvas');
              canvas.width = img.width;
              canvas.height = img.height;
              const ctx = canvas.getContext('2d');
              if (ctx) {
                ctx.drawImage(img, 0, 0);
                const pngDataUrl = canvas.toDataURL('image/png');
                newImages.push(pngDataUrl);
              }
            };
            img.src = dataUrl;
          } else {
            newImages.push(dataUrl);
          }
        } catch (err) {
          console.error('Failed to load image:', file.name, err);
        }
      }
    }
    
    // Update preset in state
    const updatedPresets = emojiPresets.map(p => {
      if (p.id === mathManualPreset) {
        return { ...p, emojis: [...p.emojis, ...newImages] };
      }
      return p;
    });
    
    setEmojiPresets(updatedPresets);
    await saveEmojiPresets(updatedPresets);
    
    // Update engine tray
    if (digitsEngineRef.current) {
      const updatedPreset = updatedPresets.find(p => p.id === mathManualPreset);
      if (updatedPreset) {
        digitsEngineRef.current.setImages(updatedPreset.emojis);
      }
    }
    
    alert(`Добавлено ${newImages.length} картинок в пресет`);
  }, [mathManualPreset, emojiPresets]);
  
  const createNewPreset = useCallback(async () => {
    if (!newPresetName.trim() || newPresetImages.length === 0) return;
    
    const newPreset: EmojiPreset = {
      id: `preset_${Date.now()}`,
      name: newPresetName.trim(),
      emojis: newPresetImages,
      createdAt: Date.now(),
    };
    
    const updatedPresets = [...emojiPresets, newPreset];
    setEmojiPresets(updatedPresets);
    await saveEmojiPresets(updatedPresets);
    
    // Switch to new preset
    setMathManualPreset(newPreset.id);
    
    // Update engine
    if (digitsEngineRef.current) {
      digitsEngineRef.current.setImages(newPresetImages);
    }
    
    // Reset modal
    setShowNewPresetModal(false);
    setNewPresetName('');
    setNewPresetImages([]);
    
    alert(`Создан пресет "${newPreset.name}"`);
  }, [newPresetName, newPresetImages, emojiPresets]);
  
  const changePreset = useCallback(async (presetId: string) => {
    if (!confirm('Смена пресета очистит поле. Продолжить?')) return;
    
    const newPreset = emojiPresets.find(p => p.id === presetId);
    if (!newPreset) return;
    
    setMathManualPreset(presetId);
    
    // Update engine
    const engine = digitsEngineRef.current;
    if (engine) {
      engine.setImages(newPreset.emojis);
      // Clear all slots
      const emptyRows = Array(engine.getRowCount()).fill(null).map(() => 
        Array(engine.getSlotCount()).fill(null)
      );
      engine.setRowsData(emptyRows);
    }
    
    // Clear localStorage
    localStorage.removeItem('mathManualRowsData');
    
    setShowChangePresetModal(false);
    
    alert(`Пресет изменён на "${newPreset.name}"`);
  }, [emojiPresets]);
  
  const handlePause = () => {
    if (engineRef.current) {
      engineRef.current.setPaused(true);
    }
    setPauseItemSize(settings.itemSize);
    setPauseBasketScale(settings.basketScale);
    setPaused(true);
  };
  
  const handlePauseBasketScaleChange = (newScale: number) => {
    setPauseBasketScale(newScale);
    setSettings({ ...settings, basketScale: newScale });
    if (engineRef.current) {
      engineRef.current.setBasketScale(newScale);
    }
  };
  
  const handleResume = () => {
    if (engineRef.current) {
      engineRef.current.setPaused(false);
    }
    setPaused(false);
  };
  
  const handlePauseItemSizeChange = (newSize: number) => {
    setPauseItemSize(newSize);
    setSettings({ ...settings, itemSize: newSize });
    if (engineRef.current) {
      engineRef.current.setItemSize(newSize);
    }
  };
  
  const handleRestart = () => {
    if (engineRef.current) {
      engineRef.current.destroy();
      engineRef.current = null;
    }
    setPaused(false);
    startGame();
  };
  
  const handlePauseToMenu = () => {
    if (engineRef.current) {
      engineRef.current.destroy();
      engineRef.current = null;
    }
    setPaused(false);
    setScreen('menu');
  };
  
  if (screen === 'menu') {
    return <MenuScreen onPlay={() => setScreen('setup')} onMath={() => setScreen('mathSetup')} onPuzzle={startPuzzle} onSettings={() => setScreen('settings')} onPixelEditor={() => setScreen('pixelEditor')} />;
  }
  
  if (screen === 'setup') {
    return (
      <SetupScreen
        baskets={baskets}
        setBaskets={setBaskets}
        settings={settings}
        setSettings={setSettings}
        onBack={() => setScreen('menu')}
        onStart={startGame}
        onEmojiPicker={() => setScreen('emojiPicker')}
        emojiPresets={emojiPresets}
      />
    );
  }
  
  if (screen === 'gameover') {
    return <GameOverScreen score={score} level={level} onRestart={startGame} onMenu={goToMenu} />;
  }
  
  if (screen === 'settings') {
    return <SettingsScreen onBack={() => setScreen('menu')} />;
  }
  
  if (screen === 'emojiPicker') {
    return (
      <EmojiPickerScreen
        loadedEmojis={loadedEmojis}
        setLoadedEmojis={setLoadedEmojis}
        selectedEmojis={selectedEmojis}
        setSelectedEmojis={setSelectedEmojis}
        emojiPresets={emojiPresets}
        setEmojiPresets={setEmojiPresets}
        onBack={() => setScreen('setup')}
      />
    );
  }

  if (screen === 'pixelEditor') {
    return (
      <PixelEditor
        onBack={() => setScreen('menu')}
        emojiPresets={emojiPresets}
        setEmojiPresets={setEmojiPresets}
      />
    );
  }
  
  if (screen === 'mathSetup') {
    return (
      <MathSetupScreen
        onStart={(operations, difficulty, mode, presetId, squareSize, slotCount) => {
          if (mode === 'manual') {
            if (presetId) setMathManualPreset(presetId);
            if (squareSize) setMathManualSquareSize(squareSize);
            if (slotCount) setMathManualSlotCount(slotCount);
            startMathManual(presetId, squareSize, slotCount);
          } else {
            startMath(operations, difficulty);
          }
        }}
        onBack={() => setScreen('menu')}
        emojiPresets={emojiPresets}
        initialPresetId={mathManualPreset}
        initialSquareSize={mathManualSquareSize}
        initialSlotCount={mathManualSlotCount}
      />
    );
  }
  
  if (screen === 'mathManual') {
    return (
      <div className="w-full h-full relative select-none">
        <div ref={gameContainerRef} className="w-full h-full" />
        
        {/* Pause Button */}
        <div className="absolute top-0 left-0 right-0 pointer-events-none p-2 flex justify-center z-10">
          <button
            onClick={() => {
              if (digitsEngineRef.current) {
                digitsEngineRef.current.setPaused(true);
              }
              setPaused(true);
            }}
            className="pointer-events-auto bg-white/90 hover:bg-white rounded-2xl w-16 h-16 flex flex-col items-center justify-center shadow-lg transition-colors duration-150"
          >
            <span className="text-2xl">⏸</span>
            <span className="text-xs text-gray-700 mt-0.5">Пауза</span>
          </button>
        </div>
        
        {/* Row Management Buttons */}
        <div className="absolute left-3 top-[50px] pointer-events-none z-10 flex flex-col gap-[20px]">
          {Array.from({ length: mathManualRowCount }, (_, i) => (
            <button
              key={i}
              onClick={() => {
                if (digitsEngineRef.current && mathManualRowCount > 1) {
                  digitsEngineRef.current.removeRow(i);
                  const newCount = digitsEngineRef.current.getRowCount();
                  setMathManualRowCount(newCount);
                  localStorage.setItem('mathManualRowCount', newCount.toString());
                  
                  // Save rows data
                  const rowsData = digitsEngineRef.current.getRowsData();
                  localStorage.setItem('mathManualRowsData', JSON.stringify(rowsData));
                }
              }}
              className={`pointer-events-auto bg-red-500/80 hover:bg-red-600 text-white rounded-full w-11 h-11 flex items-center justify-center shadow-lg transition-colors duration-150 text-lg font-bold ${
                mathManualRowCount === 1 ? 'opacity-0 pointer-events-none' : ''
              }`}
              title={`Удалить ряд ${i + 1}`}
            >
              ✕
            </button>
          ))}
          {mathManualRowCount < 4 && (
            <button
              onClick={() => {
                if (digitsEngineRef.current) {
                  digitsEngineRef.current.addRow();
                  const newCount = digitsEngineRef.current.getRowCount();
                  setMathManualRowCount(newCount);
                  localStorage.setItem('mathManualRowCount', newCount.toString());
                }
              }}
              className="pointer-events-auto bg-green-500/80 hover:bg-green-600 text-white rounded-full w-11 h-11 flex items-center justify-center shadow-lg transition-colors duration-150 text-xl font-bold"
              title="Добавить ряд"
            >
              +
            </button>
          )}
        </div>
        
        {/* Pause Menu for Math Manual */}
        {paused && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-20 p-4">
            <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 shadow-2xl max-h-[90vh] overflow-y-auto">
              <h2 className="text-2xl font-bold text-gray-800 text-center mb-6">⏸ Пауза</h2>
              
              {/* Square size slider */}
              <div className="mb-4">
                <label className="text-gray-700 text-sm block mb-1">Размер квадратиков: {mathManualSquareSize}%</label>
                <input
                  type="range"
                  min={50}
                  max={200}
                  step={10}
                  value={mathManualSquareSize}
                  onChange={(e) => {
                    const newSize = Number(e.target.value);
                    setMathManualSquareSize(newSize);
                    if (digitsEngineRef.current) {
                      digitsEngineRef.current.setSquareSizeFactor(newSize);
                    }
                  }}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-orange-500"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>50%</span>
                  <span>200%</span>
                </div>
              </div>
              
              {/* Slot count selection */}
              <div className="mb-4">
                <label className="text-gray-700 text-sm block mb-2">Количество квадратиков:</label>
                <div className="grid grid-cols-5 gap-2">
                  {[8, 12, 16, 20, 24].map(count => (
                    <button
                      key={count}
                      onClick={() => {
                        setMathManualSlotCount(count);
                        if (digitsEngineRef.current) {
                          digitsEngineRef.current.setSlotCount(count);
                        }
                      }}
                      className={`p-2 rounded-lg text-sm font-bold transition-colors duration-150 ${
                        mathManualSlotCount === count
                          ? 'bg-orange-600 text-white'
                          : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                      }`}
                    >
                      {count}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Preset Management */}
              <div className="mb-4">
                <label className="text-gray-700 text-sm block mb-2">Управление пресетами:</label>
                <div className="space-y-2">
                  <button
                    onClick={() => {
                      const input = document.createElement('input');
                      input.type = 'file';
                      input.multiple = true;
                      input.accept = 'image/*';
                      input.onchange = (e) => {
                        const files = (e.target as HTMLInputElement).files;
                        if (files) {
                          addImagesToCurrentPreset(files);
                        }
                      };
                      input.click();
                    }}
                    className="w-full bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
                  >
                    + Добавить картинки в текущий
                  </button>
                  <button
                    onClick={() => setShowNewPresetModal(true)}
                    className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
                  >
                    + Создать новый пресет
                  </button>
                  <button
                    onClick={() => setShowChangePresetModal(true)}
                    className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
                  >
                    🔄 Сменить пресет
                  </button>
                </div>
              </div>
              
              <div className="space-y-3">
                <button
                  onClick={() => {
                    if (digitsEngineRef.current) {
                      digitsEngineRef.current.setPaused(false);
                    }
                    setPaused(false);
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  ▶ Продолжить
                </button>
                <button
                  onClick={() => {
                    // Save rows data before leaving
                    if (digitsEngineRef.current) {
                      const rowsData = digitsEngineRef.current.getRowsData();
                      localStorage.setItem('mathManualRowsData', JSON.stringify(rowsData));
                      digitsEngineRef.current.destroy();
                      digitsEngineRef.current = null;
                    }
                    setPaused(false);
                    setScreen('mathSetup');
                  }}
                  className="w-full bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  ⚙ Настройки режима
                </button>
                <button
                  onClick={() => {
                    // Save rows data before restart
                    if (digitsEngineRef.current) {
                      const rowsData = digitsEngineRef.current.getRowsData();
                      localStorage.setItem('mathManualRowsData', JSON.stringify(rowsData));
                      digitsEngineRef.current.destroy();
                      digitsEngineRef.current = null;
                    }
                    setPaused(false);
                    startMathManual();
                  }}
                  className="w-full bg-zinc-200 hover:bg-zinc-300 text-gray-800 font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  🔄 Заново
                </button>
                <button
                  onClick={() => {
                    // Save rows data before leaving
                    if (digitsEngineRef.current) {
                      const rowsData = digitsEngineRef.current.getRowsData();
                      localStorage.setItem('mathManualRowsData', JSON.stringify(rowsData));
                      digitsEngineRef.current.destroy();
                      digitsEngineRef.current = null;
                    }
                    setPaused(false);
                    setScreen('menu');
                  }}
                  className="w-full bg-zinc-200 hover:bg-zinc-300 text-gray-800 font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  🏠 В главное меню
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* New Preset Modal */}
        {showNewPresetModal && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-30">
            <div className="bg-white rounded-2xl p-6 max-w-md w-full mx-4 shadow-2xl max-h-[80vh] overflow-y-auto">
              <h2 className="text-2xl font-bold text-gray-800 text-center mb-6">Новый пресет</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="text-gray-700 text-sm block mb-2">Название:</label>
                  <input
                    type="text"
                    value={newPresetName}
                    onChange={(e) => setNewPresetName(e.target.value)}
                    placeholder="Введите название пресета"
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-orange-500 focus:outline-none"
                  />
                </div>
                
                <div>
                  <label className="text-gray-700 text-sm block mb-2">Картинки:</label>
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={async (e) => {
                      const files = e.target.files;
                      if (!files) return;
                      
                      const newImages: string[] = [];
                      for (let i = 0; i < files.length; i++) {
                        const file = files[i];
                        if (file.type.startsWith('image/')) {
                          try {
                            const dataUrl = await new Promise<string>((resolve, reject) => {
                              const reader = new FileReader();
                              reader.onload = () => resolve(reader.result as string);
                              reader.onerror = reject;
                              reader.readAsDataURL(file);
                            });
                            
                            if (file.type === 'image/webp' || file.type === 'image/gif') {
                              const img = new Image();
                              img.onload = () => {
                                const canvas = document.createElement('canvas');
                                canvas.width = img.width;
                                canvas.height = img.height;
                                const ctx = canvas.getContext('2d');
                                if (ctx) {
                                  ctx.drawImage(img, 0, 0);
                                  const pngDataUrl = canvas.toDataURL('image/png');
                                  newImages.push(pngDataUrl);
                                }
                              };
                              img.src = dataUrl;
                            } else {
                              newImages.push(dataUrl);
                            }
                          } catch (err) {
                            console.error('Failed to load image:', file.name, err);
                          }
                        }
                      }
                      
                      setNewPresetImages([...newPresetImages, ...newImages]);
                    }}
                    className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100"
                  />
                  <p className="text-gray-500 text-sm mt-2">Загружено: {newPresetImages.length}</p>
                </div>
                
                {newPresetImages.length > 0 && (
                  <div>
                    <label className="text-gray-700 text-sm block mb-2">Превью:</label>
                    <div className="grid grid-cols-6 gap-2 max-h-48 overflow-y-auto">
                      {newPresetImages.map((img, i) => (
                        <div key={i} className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                          <img src={img} alt="" className="w-full h-full object-contain" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="flex gap-3 pt-4">
                  <button
                    onClick={() => {
                      setShowNewPresetModal(false);
                      setNewPresetName('');
                      setNewPresetImages([]);
                    }}
                    className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 rounded-xl transition-colors duration-150"
                  >
                    Отмена
                  </button>
                  <button
                    onClick={createNewPreset}
                    disabled={!newPresetName.trim() || newPresetImages.length === 0}
                    className="flex-1 bg-orange-600 hover:bg-orange-500 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-bold py-3 rounded-xl transition-colors duration-150"
                  >
                    ✓ Создать
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Change Preset Modal */}
        {showChangePresetModal && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-30">
            <div className="bg-white rounded-2xl p-6 max-w-md w-full mx-4 shadow-2xl max-h-[80vh] overflow-y-auto">
              <h2 className="text-2xl font-bold text-gray-800 text-center mb-6">Сменить пресет</h2>
              
              <div className="space-y-3">
                {emojiPresets.map(preset => (
                  <button
                    key={preset.id}
                    onClick={() => changePreset(preset.id)}
                    className={`w-full p-4 rounded-xl text-left transition-colors duration-150 ${
                      mathManualPreset === preset.id
                        ? 'bg-orange-600 text-white'
                        : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                    }`}
                  >
                    <div className="font-bold">{preset.name}</div>
                    <div className="text-sm opacity-80 mt-1">{preset.emojis.length} картинок</div>
                    {preset.emojis.length > 0 && (
                      <div className="flex gap-1 mt-2">
                        {preset.emojis.slice(0, 3).map((img, i) => (
                          <div key={i} className="w-8 h-8 bg-white rounded overflow-hidden">
                            <img src={img} alt="" className="w-full h-full object-contain" />
                          </div>
                        ))}
                      </div>
                    )}
                  </button>
                ))}
              </div>
              
              <button
                onClick={() => setShowChangePresetModal(false)}
                className="w-full mt-4 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 rounded-xl transition-colors duration-150"
              >
                Отмена
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }
  
  if (screen === 'digits') {
    return (
      <div className="w-full h-full relative select-none">
        <div ref={gameContainerRef} className="w-full h-full" />
        
        <div className="absolute top-0 left-0 right-0 pointer-events-none p-2 flex justify-center z-10">
          <button
            onClick={goToMenu}
            className="pointer-events-auto bg-white/90 hover:bg-white rounded-2xl w-16 h-16 flex flex-col items-center justify-center shadow-lg transition-colors duration-150"
          >
            <span className="text-2xl">⏸</span>
            <span className="text-xs text-gray-700 mt-0.5">Меню</span>
          </button>
        </div>
      </div>
    );
  }
  
  if (screen === 'puzzleSetup') {
    return (
      <PuzzleSetupScreen
        puzzleImages={puzzleImages}
        setPuzzleImages={setPuzzleImages}
        puzzlePiecesMode={puzzlePiecesMode}
        setPuzzlePiecesMode={setPuzzlePiecesMode}
        emojiPresets={emojiPresets}
        onBack={() => setScreen('menu')}
        onStart={startPuzzleGame}
      />
    );
  }
  
  if (screen === 'puzzle') {
    return (
      <div className="w-full h-full relative select-none">
        <div ref={gameContainerRef} className="w-full h-full" />
        
        {/* Pause Button */}
        <div className="absolute top-0 left-0 right-0 pointer-events-none p-2 flex justify-center z-10">
          <button
            onClick={() => {
              if (puzzleEngineRef.current) {
                puzzleEngineRef.current.setPaused(true);
              }
              setPaused(true);
            }}
            className="pointer-events-auto bg-white/90 hover:bg-white rounded-2xl w-16 h-16 flex flex-col items-center justify-center shadow-lg transition-colors duration-150"
          >
            <span className="text-2xl">⏸</span>
            <span className="text-xs text-gray-700 mt-0.5">Пауза</span>
          </button>
        </div>
        
        {/* Pause Menu for Puzzle */}
        {paused && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-20">
            <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 shadow-2xl">
              <h2 className="text-2xl font-bold text-gray-800 text-center mb-6">⏸ Пауза</h2>
              
              <div className="text-center mb-4 text-gray-600">
                <p>Счёт: <span className="font-bold text-gray-800">{score}</span> | Уровень: <span className="font-bold text-gray-800">{level}</span></p>
              </div>
              
              <div className="space-y-3">
                <button
                  onClick={() => {
                    if (puzzleEngineRef.current) {
                      puzzleEngineRef.current.setPaused(false);
                    }
                    setPaused(false);
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  ▶ Продолжить
                </button>
                <button
                  onClick={() => {
                    if (puzzleEngineRef.current) {
                      puzzleEngineRef.current.destroy();
                      puzzleEngineRef.current = null;
                    }
                    setPaused(false);
                    setScreen('puzzleSetup');
                  }}
                  className="w-full bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  ⚙ Настройки режима
                </button>
                <button
                  onClick={() => {
                    if (puzzleEngineRef.current) {
                      puzzleEngineRef.current.destroy();
                      puzzleEngineRef.current = null;
                    }
                    setPaused(false);
                    startPuzzleGame();
                  }}
                  className="w-full bg-zinc-200 hover:bg-zinc-300 text-gray-800 font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  🔄 Заново
                </button>
                <button
                  onClick={() => {
                    if (puzzleEngineRef.current) {
                      puzzleEngineRef.current.destroy();
                      puzzleEngineRef.current = null;
                    }
                    setPaused(false);
                    setScreen('menu');
                  }}
                  className="w-full bg-zinc-200 hover:bg-zinc-300 text-gray-800 font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  🏠 В главное меню
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
  
  if (screen === 'math') {
    return (
      <div className="w-full h-full relative select-none">
        <div ref={gameContainerRef} className="w-full h-full" />
        
        {/* Pause Button */}
        <div className="absolute top-0 left-0 right-0 pointer-events-none p-2 flex justify-center z-10">
          <button
            onClick={() => {
              if (mathEngineRef.current) {
                mathEngineRef.current.setPaused(true);
              }
              setPaused(true);
            }}
            className="pointer-events-auto bg-white/90 hover:bg-white rounded-2xl w-16 h-16 flex flex-col items-center justify-center shadow-lg transition-colors duration-150"
          >
            <span className="text-2xl">⏸</span>
            <span className="text-xs text-gray-700 mt-0.5">Пауза</span>
          </button>
        </div>
        
        {/* Pause Menu for Math */}
        {paused && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-20">
            <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 shadow-2xl">
              <h2 className="text-2xl font-bold text-gray-800 text-center mb-6">⏸ Пауза</h2>
              
              <div className="text-center mb-4 text-gray-600">
                <p>Счёт: <span className="font-bold text-gray-800">{score}</span> | Уровень: <span className="font-bold text-gray-800">{level}</span></p>
              </div>
              
              <div className="space-y-3">
                <button
                  onClick={() => {
                    if (mathEngineRef.current) {
                      mathEngineRef.current.setPaused(false);
                    }
                    setPaused(false);
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  ▶ Продолжить
                </button>
                <button
                  onClick={() => {
                    if (mathEngineRef.current) {
                      mathEngineRef.current.destroy();
                      mathEngineRef.current = null;
                    }
                    setPaused(false);
                    setScreen('mathSetup');
                  }}
                  className="w-full bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  ⚙ Настройки режима
                </button>
                <button
                  onClick={() => {
                    if (mathEngineRef.current) {
                      mathEngineRef.current.destroy();
                      mathEngineRef.current = null;
                    }
                    setPaused(false);
                    setScreen('mathSetup');
                  }}
                  className="w-full bg-zinc-200 hover:bg-zinc-300 text-gray-800 font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  🔄 Заново
                </button>
                <button
                  onClick={() => {
                    if (mathEngineRef.current) {
                      mathEngineRef.current.destroy();
                      mathEngineRef.current = null;
                    }
                    setPaused(false);
                    setScreen('menu');
                  }}
                  className="w-full bg-zinc-200 hover:bg-zinc-300 text-gray-800 font-bold py-3 rounded-xl transition-colors duration-150"
                >
                  🏠 В главное меню
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
  
  // Game screen
  return (
    <div className="w-full h-full relative select-none">
      <div ref={gameContainerRef} className="w-full h-full" />
      
      {/* Pause Button — Center Top */}
      <div className="absolute top-4 left-0 right-0 flex justify-center z-10">
        <button
          onClick={handlePause}
          className="pointer-events-auto bg-white/90 hover:bg-white rounded-2xl w-16 h-16 flex flex-col items-center justify-center shadow-lg transition-colors duration-150"
        >
          <span className="text-2xl">⏸</span>
          <span className="text-xs text-gray-700 mt-0.5">Пауза</span>
        </button>
      </div>
      
      {/* Pause Menu */}
      {paused && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-20">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 shadow-2xl">
            <h2 className="text-2xl font-bold text-gray-800 text-center mb-6">⏸ Пауза</h2>
            
            {/* Score info */}
            <div className="text-center mb-4 text-gray-600">
              <p>Счёт: <span className="font-bold text-gray-800">{score}</span> | Уровень: <span className="font-bold text-gray-800">{level}</span></p>
            </div>
            
            {/* Item size slider */}
            <div className="mb-4">
              <label className="text-gray-700 text-sm block mb-1">Размер картинок: {pauseItemSize}%</label>
              <input
                type="range"
                min={50}
                max={300}
                step={10}
                value={pauseItemSize}
                onChange={(e) => handlePauseItemSizeChange(Number(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
              <div className="flex justify-between text-xs text-gray-400 mt-1">
                <span>50%</span>
                <span>300%</span>
              </div>
            </div>
            
            {/* Basket scale slider */}
            <div className="mb-6">
              <label className="text-gray-700 text-sm block mb-1">Размер корзин: {pauseBasketScale}%</label>
              <input
                type="range"
                min={50}
                max={150}
                step={10}
                value={pauseBasketScale}
                onChange={(e) => handlePauseBasketScaleChange(Number(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-green-500"
              />
              <div className="flex justify-between text-xs text-gray-400 mt-1">
                <span>50%</span>
                <span>150%</span>
              </div>
            </div>
            
            {/* Sound toggle */}
            <div className="mb-6 flex items-center justify-between">
              <span className="text-gray-700">Звук:</span>
              <button
                onClick={() => setSettings({ ...settings, sound: !settings.sound })}
                className={`px-4 py-2 rounded-lg transition-colors duration-150 ${
                  settings.sound ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-600'
                }`}
              >
                {settings.sound ? '🔊 Вкл' : '🔇 Выкл'}
              </button>
            </div>
            
            {/* Buttons */}
            <div className="space-y-3">
              <button
                onClick={handleResume}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
              >
                ▶ Продолжить
              </button>
              <button
                onClick={handleRestart}
                className="w-full bg-zinc-200 hover:bg-zinc-300 text-gray-800 font-bold py-3 rounded-xl transition-colors duration-150"
              >
                🔄 Заново
              </button>
              <button
                onClick={handlePauseToMenu}
                className="w-full bg-zinc-200 hover:bg-zinc-300 text-gray-800 font-bold py-3 rounded-xl transition-colors duration-150"
              >
                🏠 В главное меню
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Menu Screen
function MenuScreen({ onPlay, onMath, onPuzzle, onSettings, onPixelEditor }: { onPlay: () => void; onMath: () => void; onPuzzle: () => void; onSettings: () => void; onPixelEditor: () => void }) {
  return (
    <div className="w-full h-full bg-gradient-to-b from-zinc-900 to-zinc-800 flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl font-bold text-white mb-2">🎯 Сортировка</h1>
      <p className="text-zinc-400 mb-8 text-center">Раскладывай предметы по корзинам!</p>
      
      <button
        onClick={onPlay}
        className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xl px-8 py-4 rounded-xl transition-colors duration-150 mb-4"
      >
        📷 Свои картинки
      </button>
      
      <div className="flex gap-3 mb-3">
        <button onClick={onPuzzle} className="bg-purple-600 hover:bg-purple-500 text-white font-bold text-lg px-6 py-3 rounded-xl transition-colors duration-150 flex-1">
          🧩 Пазл
        </button>
        <button onClick={onMath} className="bg-orange-600 hover:bg-orange-500 text-white font-bold text-lg px-6 py-3 rounded-xl transition-colors duration-150 flex-1">
          🔢 Математика
        </button>
      </div>

      <button onClick={onPixelEditor} className="bg-pink-600 hover:bg-pink-500 text-white font-bold text-lg px-6 py-3 rounded-xl transition-colors duration-150 mb-3">
        🎨 Редактор
      </button>
      
      <button className="bg-zinc-700 hover:bg-zinc-600 text-white px-6 py-3 rounded-xl transition-colors duration-150 mb-3">
        🏆 Рекорды
      </button>
      
      <button onClick={onSettings} className="bg-zinc-700 hover:bg-zinc-600 text-white px-6 py-3 rounded-xl transition-colors duration-150">
        ⚙ Настройки
      </button>
    </div>
  );
}

// Setup Screen
function SetupScreen({
  baskets,
  setBaskets,
  settings,
  setSettings,
  onBack,
  onStart,
  onEmojiPicker,
  emojiPresets,
}: {
  baskets: BasketConfig[];
  setBaskets: (b: BasketConfig[]) => void;
  settings: GameSettings;
  setSettings: (s: GameSettings) => void;
  onBack: () => void;
  onStart: () => void;
  onEmojiPicker: () => void;
  emojiPresets: EmojiPreset[];
}) {
  const [presetPickerBasketIndex, setPresetPickerBasketIndex] = useState<number | null>(null);
  const [selectedPresetImages, setSelectedPresetImages] = useState<Set<string>>(new Set());
  
  const updateBasket = (index: number, updates: Partial<BasketConfig>) => {
    const newBaskets = [...baskets];
    newBaskets[index] = { ...newBaskets[index], ...updates };
    setBaskets(newBaskets);
    saveBaskets(newBaskets);
  };
  
  const addBasket = () => {
    const newBasket: BasketConfig = {
      id: `basket_${Date.now()}`,
      name: `Корзина ${baskets.length + 1}`,
      dropImages: [],
    };
    const newBaskets = [...baskets, newBasket];
    setBaskets(newBaskets);
    saveBaskets(newBaskets);
  };
  
  const removeBasket = (index: number) => {
    const newBaskets = baskets.filter((_, i) => i !== index);
    setBaskets(newBaskets);
    saveBaskets(newBaskets);
  };
  
  const handleFileUpload = (index: number, field: 'basketPhoto' | 'categoryIcon' | 'dropImages', files: FileList | null) => {
    if (!files) return;
    
    const readers: Promise<string>[] = [];
    for (let i = 0; i < files.length; i++) {
      readers.push(new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(files[i]);
      }));
    }
    
    Promise.all(readers).then((results) => {
      if (field === 'dropImages') {
        const current = baskets[index].dropImages || [];
        updateBasket(index, { dropImages: [...current, ...results] });
      } else {
        updateBasket(index, { [field]: results[0] });
      }
    });
  };
  
  const removeImage = (basketIndex: number, field: 'basketPhoto' | 'categoryIcon') => {
    updateBasket(basketIndex, { [field]: undefined });
  };
  
  const removeDropImage = (basketIndex: number, imageIndex: number) => {
    const current = baskets[basketIndex].dropImages;
    const newImages = current.filter((_, i) => i !== imageIndex);
    updateBasket(basketIndex, { dropImages: newImages });
  };
  
  return (
    <div className="w-full h-full bg-gradient-to-b from-zinc-900 to-zinc-800 flex flex-col p-4 overflow-y-auto">
      <h1 className="text-2xl font-bold text-white mb-4 text-center">📷 Свои картинки</h1>
      
      <div className="max-w-2xl mx-auto w-full space-y-4">
        {/* Settings */}
        <div className="bg-zinc-800 rounded-xl p-4 space-y-3">
          <div>
            <label className="text-white text-sm block mb-1">Количество корзин: {baskets.length}</label>
            <input
              type="range"
              min={2}
              max={6}
              value={baskets.length}
              onChange={(e) => {
                const count = Number(e.target.value);
                if (count > baskets.length) {
                  addBasket();
                } else {
                  removeBasket(baskets.length - 1);
                }
              }}
              className="w-full h-2 bg-zinc-600 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
          </div>
          
          <div>
            <label className="text-white text-sm block mb-2">Режим:</label>
            <div className="flex gap-2">
              <button
                onClick={() => setSettings({ ...settings, spawnMode: 'fall' })}
                className={`flex-1 p-2 rounded-lg transition-colors duration-150 ${
                  settings.spawnMode === 'fall' ? 'bg-blue-600 text-white' : 'bg-zinc-700 text-zinc-300'
                }`}
              >
                ⚡ Падают сверху
              </button>
              <button
                onClick={() => setSettings({ ...settings, spawnMode: 'random' })}
                className={`flex-1 p-2 rounded-lg transition-colors duration-150 ${
                  settings.spawnMode === 'random' ? 'bg-blue-600 text-white' : 'bg-zinc-700 text-zinc-300'
                }`}
              >
                🎲 Появляются
              </button>
            </div>
          </div>
          
          <div>
            <label className="text-white text-sm block mb-1">Размер картинок: {settings.itemSize}%</label>
            <input
              type="range"
              min={50}
              max={300}
              step={10}
              value={settings.itemSize}
              onChange={(e) => setSettings({ ...settings, itemSize: Number(e.target.value) })}
              className="w-full h-2 bg-zinc-600 rounded-lg appearance-none cursor-pointer accent-green-500"
            />

          </div>
        </div>
        
        {/* Baskets */}
        {baskets.map((basket, index) => (
          <div key={basket.id} className="bg-zinc-800 rounded-xl p-4 space-y-3">
            <div className="flex justify-between items-center">
              <h3 className="text-white font-semibold">Корзина {index + 1}</h3>
              {baskets.length > 2 && (
                <button
                  onClick={() => removeBasket(index)}
                  className="text-red-400 hover:text-red-300 text-sm"
                >
                  ✕ Удалить
                </button>
              )}
            </div>
            
            <div>
              <label className="text-zinc-400 text-xs block mb-1">Название:</label>
              <input
                type="text"
                value={basket.name}
                onChange={(e) => updateBasket(index, { name: e.target.value })}
                className="w-full bg-zinc-700 text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <div>
              <label className="text-zinc-400 text-xs block mb-1">📷 Фото корзины (фон):</label>
              {basket.basketPhoto ? (
                <div className="flex items-center gap-2">
                  <div className="w-16 h-16 rounded-lg overflow-hidden bg-white" style={{
                    backgroundImage: 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)',
                    backgroundSize: '12px 12px',
                    backgroundPosition: '0 0, 0 6px, 6px -6px, -6px 0',
                  }}>
                    <img src={basket.basketPhoto} alt="" className="w-full h-full object-contain" />
                  </div>
                  <button
                    onClick={() => removeImage(index, 'basketPhoto')}
                    className="text-red-400 hover:text-red-300 text-sm"
                  >
                    ✕ Удалить
                  </button>
                </div>
              ) : (
                <label className="block">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleFileUpload(index, 'basketPhoto', e.target.files)}
                    className="block w-full text-xs text-zinc-400 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:bg-zinc-600 file:text-white file:text-xs file:cursor-pointer"
                  />
                </label>
              )}
            </div>
            
            <div>
              <label className="text-zinc-400 text-xs block mb-1">📷 Иконка категории:</label>
              {basket.categoryIcon ? (
                <div className="flex items-center gap-2">
                  <div className="w-12 h-12 rounded-lg overflow-hidden bg-white" style={{
                    backgroundImage: 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)',
                    backgroundSize: '12px 12px',
                    backgroundPosition: '0 0, 0 6px, 6px -6px, -6px 0',
                  }}>
                    <img src={basket.categoryIcon} alt="" className="w-full h-full object-contain" />
                  </div>
                  <button
                    onClick={() => removeImage(index, 'categoryIcon')}
                    className="text-red-400 hover:text-red-300 text-sm"
                  >
                    ✕ Удалить
                  </button>
                </div>
              ) : (
                <label className="block">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleFileUpload(index, 'categoryIcon', e.target.files)}
                    className="block w-full text-xs text-zinc-400 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:bg-zinc-600 file:text-white file:text-xs file:cursor-pointer"
                  />
                </label>
              )}
            </div>
            
            <div>
              <label className="text-zinc-400 text-xs block mb-1">📷 Картинки для падения:</label>
              <div className="flex gap-2 mb-2">
                <label className="flex-1">
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={(e) => handleFileUpload(index, 'dropImages', e.target.files)}
                    className="block w-full text-xs text-zinc-400 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:bg-zinc-600 file:text-white file:text-xs file:cursor-pointer"
                  />
                </label>
                {emojiPresets.length > 0 && (
                  <button
                    onClick={() => {
                      setPresetPickerBasketIndex(index);
                      setSelectedPresetImages(new Set());
                    }}
                    className="text-xs bg-purple-600 hover:bg-purple-500 text-white px-3 py-1 rounded-lg transition-colors duration-150 whitespace-nowrap"
                  >
                    📦 Из пресета
                  </button>
                )}
              </div>
              {basket.dropImages.length > 0 && (
                <div>
                  <p className="text-zinc-500 text-xs mb-2">{basket.dropImages.length} файлов:</p>
                  <div className="flex flex-wrap gap-2">
                    {basket.dropImages.map((img, i) => (
                      <div key={i} className="relative group">
                        <div className="w-16 h-16 rounded-lg overflow-hidden bg-white" style={{
                          backgroundImage: 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)',
                          backgroundSize: '12px 12px',
                          backgroundPosition: '0 0, 0 6px, 6px -6px, -6px 0',
                        }}>
                          <img src={img} alt="" className="w-full h-full object-contain" />
                        </div>
                        <button
                          onClick={() => removeDropImage(index, i)}
                          className="absolute top-0 right-0 bg-red-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
        
        <button
          onClick={addBasket}
          className="w-full bg-zinc-700 hover:bg-zinc-600 text-white py-3 rounded-xl transition-colors duration-150"
        >
          + Добавить корзину
        </button>
        
        <button
          onClick={onEmojiPicker}
          className="w-full bg-purple-600 hover:bg-purple-500 text-white py-3 rounded-xl transition-colors duration-150"
        >
          📦 Пресеты эмодзи
        </button>
        
        <div className="flex gap-3 pt-4">
          <button
            onClick={onBack}
            className="bg-zinc-700 hover:bg-zinc-600 text-white px-5 py-3 rounded-xl transition-colors duration-150"
          >
            ← Назад
          </button>
          <button
            onClick={onStart}
            className="flex-1 bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
          >
            ▶ Играть
          </button>
        </div>
      </div>
      
      {/* Preset Picker Modal */}
      {presetPickerBasketIndex !== null && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-800 rounded-2xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-white mb-4">Выберите картинки из пресета</h2>
            
            {/* Preset selection */}
            <div className="mb-4">
              <label className="text-zinc-400 text-sm block mb-2">Пресет:</label>
              <div className="grid grid-cols-2 gap-2">
                {emojiPresets.map(preset => (
                  <button
                    key={preset.id}
                    onClick={() => {
                      setSelectedPresetImages(new Set(preset.emojis));
                    }}
                    className="bg-zinc-700 hover:bg-zinc-600 text-white p-3 rounded-lg text-left transition-colors duration-150"
                  >
                    <div className="font-medium">{preset.name}</div>
                    <div className="text-xs text-zinc-400 mt-1">{preset.emojis.length} картинок</div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* Selected images preview */}
            {selectedPresetImages.size > 0 && (
              <div className="mb-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-zinc-400 text-sm">Выбрано: {selectedPresetImages.size}</span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        const allImages = emojiPresets.flatMap(p => p.emojis);
                        setSelectedPresetImages(new Set(allImages));
                      }}
                      className="text-xs bg-zinc-700 hover:bg-zinc-600 text-white px-3 py-1 rounded-lg"
                    >
                      Выбрать все
                    </button>
                    <button
                      onClick={() => setSelectedPresetImages(new Set())}
                      className="text-xs bg-zinc-700 hover:bg-zinc-600 text-white px-3 py-1 rounded-lg"
                    >
                      Снять все
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-8 gap-2 max-h-96 overflow-y-auto">
                  {Array.from(selectedPresetImages).map((img, i) => (
                    <button
                      key={`${img}-${i}`}
                      onClick={() => {
                        const newSet = new Set(selectedPresetImages);
                        newSet.delete(img);
                        setSelectedPresetImages(newSet);
                      }}
                      className="aspect-square rounded-lg overflow-hidden ring-2 ring-green-400"
                    >
                      <img src={img} alt="" className="w-full h-full object-contain bg-white pixel-art" />
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setPresetPickerBasketIndex(null);
                  setSelectedPresetImages(new Set());
                }}
                className="bg-zinc-700 hover:bg-zinc-600 text-white px-5 py-3 rounded-xl transition-colors duration-150"
              >
                Отмена
              </button>
              <button
                onClick={() => {
                  if (presetPickerBasketIndex !== null && selectedPresetImages.size > 0) {
                    const currentImages = baskets[presetPickerBasketIndex].dropImages;
                    const newImages = [...currentImages, ...Array.from(selectedPresetImages)];
                    updateBasket(presetPickerBasketIndex, { dropImages: newImages });
                  }
                  setPresetPickerBasketIndex(null);
                  setSelectedPresetImages(new Set());
                }}
                className="flex-1 bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
                disabled={selectedPresetImages.size === 0}
              >
                ✓ Применить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Game Over Screen
function GameOverScreen({ score, level, onRestart, onMenu }: {
  score: number;
  level: number;
  onRestart: () => void;
  onMenu: () => void;
}) {
  return (
    <div className="w-full h-full bg-gradient-to-b from-zinc-900 to-red-950 flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl font-bold text-white mb-4">Игра окончена</h1>
      <div className="text-center mb-8">
        <p className="text-3xl text-zinc-200">Счёт: <span className="text-yellow-400 font-bold">{score}</span></p>
        <p className="text-xl text-zinc-400 mt-2">Уровень: {level}</p>
      </div>
      
      <div className="flex gap-4">
        <button
          onClick={onRestart}
          className="bg-green-600 hover:bg-green-500 text-white font-bold text-lg px-6 py-3 rounded-xl transition-colors duration-150"
        >
          🔄 Ещё раз
        </button>
        <button
          onClick={onMenu}
          className="bg-zinc-700 hover:bg-zinc-600 text-white font-bold text-lg px-6 py-3 rounded-xl transition-colors duration-150"
        >
          🏠 Меню
        </button>
      </div>
    </div>
  );
}

// Settings Screen
function SettingsScreen({ onBack }: { onBack: () => void }) {
  const [volume, setVolume] = useState(soundManager.getVolume());
  const [soundSet, setSoundSet] = useState<SoundSet>(soundManager.getSoundSet());
  
  const handleVolumeChange = (newVolume: number) => {
    setVolume(newVolume);
    soundManager.setVolume(newVolume);
  };
  
  const handleSoundSetChange = (newSoundSet: SoundSet) => {
    setSoundSet(newSoundSet);
    soundManager.setSoundSet(newSoundSet);
  };
  
  const handlePreview = () => {
    soundManager.playCorrect();
    setTimeout(() => soundManager.playWrong(), 300);
  };
  
  return (
    <div className="w-full h-full bg-gradient-to-b from-zinc-900 to-zinc-800 flex flex-col items-center p-6 overflow-y-auto">
      <h1 className="text-2xl font-bold text-white mb-6">Настройки</h1>
      
      <div className="max-w-lg text-zinc-300 space-y-3 w-full">
        {/* Sound Settings */}
        <div className="bg-zinc-800 rounded-xl p-4">
          <h3 className="text-white font-semibold mb-3">🔊 Звук</h3>
          
          <div className="space-y-4">
            <div>
              <label className="text-zinc-400 text-sm block mb-2">
                Громкость: {volume}%
              </label>
              <input
                type="range"
                min="0"
                max="100"
                value={volume}
                onChange={(e) => handleVolumeChange(Number(e.target.value))}
                className="w-full h-2 bg-zinc-600 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
            </div>
            
            <div>
              <label className="text-zinc-400 text-sm block mb-2">Набор звуков:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleSoundSetChange('nes')}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    soundSet === 'nes'
                      ? 'bg-blue-600 text-white'
                      : 'bg-zinc-700 text-zinc-300 hover:bg-zinc-600'
                  }`}
                >
                  NES
                </button>
                <button
                  onClick={() => handleSoundSetChange('soft')}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    soundSet === 'soft'
                      ? 'bg-blue-600 text-white'
                      : 'bg-zinc-700 text-zinc-300 hover:bg-zinc-600'
                  }`}
                >
                  Soft
                </button>
                <button
                  onClick={() => handleSoundSetChange('retro')}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    soundSet === 'retro'
                      ? 'bg-blue-600 text-white'
                      : 'bg-zinc-700 text-zinc-300 hover:bg-zinc-600'
                  }`}
                >
                  Retro
                </button>
                <button
                  onClick={() => handleSoundSetChange('silent')}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    soundSet === 'silent'
                      ? 'bg-blue-600 text-white'
                      : 'bg-zinc-700 text-zinc-300 hover:bg-zinc-600'
                  }`}
                >
                  Silent
                </button>
              </div>
            </div>
            
            <button
              onClick={handlePreview}
              className="w-full bg-green-600 hover:bg-green-500 text-white font-medium py-2 rounded-lg transition-colors"
            >
              ▶ Прослушать
            </button>
          </div>
        </div>
        
        <div className="bg-zinc-800 rounded-xl p-4">
          <h3 className="text-white font-semibold mb-1">🎯 Цель</h3>
          <p className="text-sm">Раскладывай предметы по правильным корзинам. Тащи предмет мышью или пальцем в нужную корзину.</p>
        </div>
        
        <div className="bg-zinc-800 rounded-xl p-4">
          <h3 className="text-white font-semibold mb-1">✅ Правильно = +10 очков</h3>
          <p className="text-sm">Каждые 50 очков — новый уровень. Предметы падают быстрее!</p>
        </div>
        
        <div className="bg-zinc-800 rounded-xl p-4">
          <h3 className="text-white font-semibold mb-1">❌ Неправильно = −1 ❤️</h3>
          <p className="text-sm">Всего 3 жизни. Когда жизни кончатся — конец игры.</p>
        </div>
      </div>
      
      <button
        onClick={onBack}
        className="mt-6 bg-zinc-700 hover:bg-zinc-600 text-white px-6 py-3 rounded-xl transition-colors duration-150"
      >
        ← Назад
      </button>
    </div>
  );
}

// Emoji Picker Screen
function EmojiPickerScreen({
  loadedEmojis,
  setLoadedEmojis,
  selectedEmojis,
  setSelectedEmojis,
  emojiPresets,
  setEmojiPresets,
  onBack,
}: {
  loadedEmojis: string[];
  setLoadedEmojis: (e: string[]) => void;
  selectedEmojis: Set<string>;
  setSelectedEmojis: (s: Set<string>) => void;
  emojiPresets: EmojiPreset[];
  setEmojiPresets: (p: EmojiPreset[]) => void;
  onBack: () => void;
}) {
  const [presetName, setPresetName] = useState('');
  const [showPresetInput, setShowPresetInput] = useState(false);
  
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    const newImages: string[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      // Accept all image formats
      if (file.type.startsWith('image/')) {
        try {
          // Convert to data URL
          const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });
          
          // For webp or other formats that might not be supported, convert to PNG via canvas
          if (file.type === 'image/webp' || file.type === 'image/gif') {
            const img = new Image();
            img.onload = () => {
              const canvas = document.createElement('canvas');
              canvas.width = img.width;
              canvas.height = img.height;
              const ctx = canvas.getContext('2d');
              if (ctx) {
                ctx.drawImage(img, 0, 0);
                const pngDataUrl = canvas.toDataURL('image/png');
                newImages.push(pngDataUrl);
              }
            };
            img.src = dataUrl;
          } else {
            newImages.push(dataUrl);
          }
        } catch (err) {
          console.error('Failed to load image:', file.name, err);
        }
      }
    }
    
    if (newImages.length > 0) {
      setLoadedEmojis([...new Set([...loadedEmojis, ...newImages])]);
    }
  };
  
  const toggleEmoji = (emoji: string) => {
    const newSelected = new Set(selectedEmojis);
    if (newSelected.has(emoji)) {
      newSelected.delete(emoji);
    } else {
      newSelected.add(emoji);
    }
    setSelectedEmojis(newSelected);
  };
  
  const selectAll = () => {
    setSelectedEmojis(new Set(loadedEmojis));
  };
  
  const deselectAll = () => {
    setSelectedEmojis(new Set());
  };
  
  const removeAllLoaded = () => {
    if (loadedEmojis.length === 0) return;
    if (confirm('Удалить все загруженные изображения? Это не затронет сохранённые пресеты.')) {
      setLoadedEmojis([]);
      setSelectedEmojis(new Set());
    }
  };
  
  const savePreset = async () => {
    if (!presetName.trim() || selectedEmojis.size === 0) return;
    
    const newPreset: EmojiPreset = {
      id: `preset_${Date.now()}`,
      name: presetName.trim(),
      emojis: Array.from(selectedEmojis),
      createdAt: Date.now(),
    };
    
    const newPresets = [...emojiPresets, newPreset];
    setEmojiPresets(newPresets);
    await saveEmojiPresets(newPresets);
    
    setPresetName('');
    setShowPresetInput(false);
  };
  
  const loadPreset = (preset: EmojiPreset) => {
    setSelectedEmojis(new Set(preset.emojis));
    // Also add emojis to loaded list if not present
    const newLoaded = [...new Set([...loadedEmojis, ...preset.emojis])];
    setLoadedEmojis(newLoaded);
  };
  
  const deletePreset = async (presetId: string) => {
    const newPresets = emojiPresets.filter(p => p.id !== presetId);
    setEmojiPresets(newPresets);
    await saveEmojiPresets(newPresets);
  };
  
  return (
    <div className="w-full h-full bg-gradient-to-b from-zinc-900 to-zinc-800 flex flex-col p-4 overflow-y-auto">
      <h1 className="text-2xl font-bold text-white mb-4 text-center">📦 Пресеты изображений</h1>
      
      <div className="max-w-2xl mx-auto w-full space-y-4">
        {/* Upload section */}
        <div className="bg-zinc-800 rounded-xl p-4">
          <h3 className="text-white font-semibold mb-3">Загрузить изображения</h3>
          <label className="block">
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileUpload}
              className="block w-full text-xs text-zinc-400 file:mr-2 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-blue-600 file:text-white file:text-sm file:cursor-pointer hover:file:bg-blue-500"
            />
          </label>
          {loadedEmojis.length > 0 && (
            <p className="text-zinc-400 text-sm mt-2">Загружено: {loadedEmojis.length} изображений</p>
          )}
        </div>
        
        {/* Emoji grid */}
        {loadedEmojis.length > 0 && (
          <div className="bg-zinc-800 rounded-xl p-4">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-white font-semibold">Выберите изображения</h3>
              <div className="flex gap-2">
                <button
                  onClick={selectAll}
                  className="text-xs bg-zinc-700 hover:bg-zinc-600 text-white px-3 py-1 rounded-lg transition-colors duration-150"
                >
                  Выбрать все
                </button>
                <button
                  onClick={deselectAll}
                  className="text-xs bg-zinc-700 hover:bg-zinc-600 text-white px-3 py-1 rounded-lg transition-colors duration-150"
                >
                  Снять все
                </button>
                <button
                  onClick={removeAllLoaded}
                  className="text-xs bg-red-700 hover:bg-red-600 text-white px-3 py-1 rounded-lg transition-colors duration-150"
                >
                  🗑 Удалить все
                </button>
              </div>
            </div>
            
            <div className="grid grid-cols-8 gap-2 max-h-64 overflow-y-auto">
              {loadedEmojis.map((imageUrl, i) => (
                <button
                  key={i}
                  onClick={() => toggleEmoji(imageUrl)}
                  className={`aspect-square rounded-lg overflow-hidden transition-colors duration-150 ${
                    selectedEmojis.has(imageUrl)
                      ? 'ring-2 ring-green-400'
                      : 'hover:ring-2 hover:ring-zinc-500'
                  }`}
                >
                  <img src={imageUrl} alt="" className="w-full h-full object-contain bg-white" />
                </button>
              ))}
            </div>
            
            <p className="text-zinc-400 text-sm mt-3">Выбрано: {selectedEmojis.size}</p>
          </div>
        )}
        
        {/* Save preset */}
        {selectedEmojis.size > 0 && (
          <div className="bg-zinc-800 rounded-xl p-4">
            {showPresetInput ? (
              <div className="space-y-3">
                <input
                  type="text"
                  value={presetName}
                  onChange={(e) => setPresetName(e.target.value)}
                  placeholder="Название пресета"
                  className="w-full bg-zinc-700 text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div className="flex gap-2">
                  <button
                    onClick={savePreset}
                    className="flex-1 bg-green-600 hover:bg-green-500 text-white font-bold py-2 rounded-lg transition-colors duration-150"
                  >
                    💾 Сохранить
                  </button>
                  <button
                    onClick={() => {
                      setShowPresetInput(false);
                      setPresetName('');
                    }}
                    className="bg-zinc-700 hover:bg-zinc-600 text-white px-4 py-2 rounded-lg transition-colors duration-150"
                  >
                    Отмена
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setShowPresetInput(true)}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 rounded-lg transition-colors duration-150"
              >
                💾 Сохранить как пресет
              </button>
            )}
          </div>
        )}
        
        {/* Presets list */}
        {emojiPresets.length > 0 && (
          <div className="bg-zinc-800 rounded-xl p-4">
            <h3 className="text-white font-semibold mb-3">Сохранённые пресеты</h3>
            <div className="space-y-2">
              {emojiPresets.map(preset => (
                <div key={preset.id} className="flex items-center justify-between bg-zinc-700 rounded-lg p-3">
                  <div className="flex-1">
                    <button
                      onClick={() => loadPreset(preset)}
                      className="text-left w-full"
                    >
                      <p className="text-white font-medium">{preset.name}</p>
                      <div className="flex gap-1 mt-1">
                        {preset.emojis.slice(0, 3).map((emoji, idx) => (
                          <img key={idx} src={emoji} alt="" className="w-6 h-6 object-contain bg-white rounded" />
                        ))}
                        {preset.emojis.length > 3 && <span className="text-zinc-400 text-xs self-center">+{preset.emojis.length - 3}</span>}
                        <span className="text-zinc-400 text-xs self-center ml-1">({preset.emojis.length})</span>
                      </div>
                    </button>
                  </div>
                  <button
                    onClick={() => deletePreset(preset.id)}
                    className="text-red-400 hover:text-red-300 ml-3"
                  >
                    🗑
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
        
        <button
          onClick={onBack}
          className="w-full bg-zinc-700 hover:bg-zinc-600 text-white py-3 rounded-xl transition-colors duration-150"
        >
          ← Назад
        </button>
      </div>
    </div>
  );
}

// Puzzle Setup Screen
function PuzzleSetupScreen({
  puzzleImages,
  setPuzzleImages,
  puzzlePiecesMode,
  setPuzzlePiecesMode,
  emojiPresets,
  onBack,
  onStart,
}: {
  puzzleImages: string[];
  setPuzzleImages: (images: string[]) => void;
  puzzlePiecesMode: 2 | 4;
  setPuzzlePiecesMode: (mode: 2 | 4) => void;
  emojiPresets: EmojiPreset[];
  onBack: () => void;
  onStart: () => void;
}) {
  const [showPresetPicker, setShowPresetPicker] = useState(false);
  const [selectedPresetImages, setSelectedPresetImages] = useState<Set<string>>(new Set());
  
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    const newImages: string[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      if (file.type.startsWith('image/')) {
        try {
          const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });
          
          if (file.type === 'image/webp' || file.type === 'image/gif') {
            const img = new Image();
            img.onload = () => {
              const canvas = document.createElement('canvas');
              canvas.width = img.width;
              canvas.height = img.height;
              const ctx = canvas.getContext('2d');
              if (ctx) {
                ctx.drawImage(img, 0, 0);
                const pngDataUrl = canvas.toDataURL('image/png');
                newImages.push(pngDataUrl);
              }
            };
            img.src = dataUrl;
          } else {
            newImages.push(dataUrl);
          }
        } catch (err) {
          console.error('Failed to load image:', file.name, err);
        }
      }
    }
    
    if (newImages.length > 0) {
      setPuzzleImages([...puzzleImages, ...newImages]);
    }
  };
  
  const removeImage = (index: number) => {
    const newImages = puzzleImages.filter((_, i) => i !== index);
    setPuzzleImages(newImages);
  };
  
  const applyPresetSelection = () => {
    const newImages = [...puzzleImages, ...Array.from(selectedPresetImages)];
    setPuzzleImages(newImages);
    setShowPresetPicker(false);
    setSelectedPresetImages(new Set());
  };
  
  return (
    <div className="w-full h-full bg-gradient-to-b from-zinc-900 to-zinc-800 flex flex-col items-center p-6 overflow-y-auto">
      <h1 className="text-3xl font-bold text-white mb-6">🧩 Пазл</h1>
      
      <div className="max-w-2xl w-full space-y-6">
        {/* Pieces mode */}
        <div className="bg-zinc-800 rounded-xl p-4">
          <h2 className="text-white font-semibold mb-3">Режим разрезания:</h2>
          <div className="flex gap-3">
            <button
              onClick={() => setPuzzlePiecesMode(2)}
              className={`flex-1 p-3 rounded-xl transition-colors duration-150 ${
                puzzlePiecesMode === 2
                  ? 'bg-purple-600 text-white'
                  : 'bg-zinc-700 text-zinc-300'
              }`}
            >
              <div className="text-2xl mb-1">🔲</div>
              <div className="font-medium">2 части</div>
              <div className="text-xs opacity-80">Вертикальный разрез</div>
            </button>
            <button
              onClick={() => setPuzzlePiecesMode(4)}
              className={`flex-1 p-3 rounded-xl transition-colors duration-150 ${
                puzzlePiecesMode === 4
                  ? 'bg-purple-600 text-white'
                  : 'bg-zinc-700 text-zinc-300'
              }`}
            >
              <div className="text-2xl mb-1">⬛</div>
              <div className="font-medium">4 части</div>
              <div className="text-xs opacity-80">2×2 сетка</div>
            </button>
          </div>
        </div>
        
        {/* Image selection */}
        <div className="bg-zinc-800 rounded-xl p-4">
          <h2 className="text-white font-semibold mb-3">Выберите картинки для игры (3-5):</h2>
          
          <div className="flex gap-2 mb-4">
            <label className="flex-1">
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileUpload}
                className="block w-full text-xs text-zinc-400 file:mr-2 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-blue-600 file:text-white file:text-sm file:cursor-pointer hover:file:bg-blue-500"
              />
            </label>
            {emojiPresets.length > 0 && (
              <button
                onClick={() => setShowPresetPicker(true)}
                className="bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-lg transition-colors duration-150 text-sm whitespace-nowrap"
              >
                📦 Из пресета
              </button>
            )}
          </div>
          
          {puzzleImages.length > 0 && (
            <div>
              <p className="text-zinc-400 text-sm mb-2">Загруженные картинки ({puzzleImages.length}):</p>
              <div className="flex flex-wrap gap-3">
                {puzzleImages.map((img, i) => (
                  <div key={i} className="relative group">
                    <div className="w-20 h-20 rounded-lg overflow-hidden bg-white" style={{
                      backgroundImage: 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)',
                      backgroundSize: '12px 12px',
                      backgroundPosition: '0 0, 0 6px, 6px -6px, -6px 0',
                    }}>
                      <img src={img} alt="" className="w-full h-full object-contain" />
                    </div>
                    <button
                      onClick={() => removeImage(i)}
                      className="absolute top-0 right-0 bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {puzzleImages.length < 3 && (
            <p className="text-yellow-400 text-sm mt-3">
              ⚠️ Загрузите минимум 3 картинки для начала игры
            </p>
          )}
        </div>
        
        {/* Buttons */}
        <div className="flex gap-3">
          <button
            onClick={onBack}
            className="bg-zinc-700 hover:bg-zinc-600 text-white px-5 py-3 rounded-xl transition-colors duration-150"
          >
            ← Назад
          </button>
          <button
            onClick={onStart}
            disabled={puzzleImages.length < 3}
            className={`flex-1 font-bold py-3 rounded-xl transition-colors duration-150 ${
              puzzleImages.length >= 3
                ? 'bg-green-600 hover:bg-green-500 text-white'
                : 'bg-zinc-600 text-zinc-400 cursor-not-allowed'
            }`}
          >
            ▶ Играть
          </button>
        </div>
      </div>
      
      {/* Preset Picker Modal */}
      {showPresetPicker && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-800 rounded-2xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-white mb-4">Выберите картинки из пресета</h2>
            
            {/* Preset selection */}
            <div className="mb-4">
              <label className="text-zinc-400 text-sm block mb-2">Пресет:</label>
              <div className="grid grid-cols-2 gap-2">
                {emojiPresets.map(preset => (
                  <button
                    key={preset.id}
                    onClick={() => {
                      setSelectedPresetImages(new Set(preset.emojis));
                    }}
                    className="bg-zinc-700 hover:bg-zinc-600 text-white p-3 rounded-lg text-left transition-colors duration-150"
                  >
                    <div className="font-medium">{preset.name}</div>
                    <div className="text-xs text-zinc-400 mt-1">{preset.emojis.length} картинок</div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* Selected images preview */}
            {selectedPresetImages.size > 0 && (
              <div className="mb-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-zinc-400 text-sm">Выбрано: {selectedPresetImages.size}</span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        const allImages = emojiPresets.flatMap(p => p.emojis);
                        setSelectedPresetImages(new Set(allImages));
                      }}
                      className="text-xs bg-zinc-700 hover:bg-zinc-600 text-white px-3 py-1 rounded-lg"
                    >
                      Выбрать все
                    </button>
                    <button
                      onClick={() => setSelectedPresetImages(new Set())}
                      className="text-xs bg-zinc-700 hover:bg-zinc-600 text-white px-3 py-1 rounded-lg"
                    >
                      Снять все
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-8 gap-2 max-h-48 overflow-y-auto">
                  {Array.from(selectedPresetImages).map((img, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        const newSet = new Set(selectedPresetImages);
                        newSet.delete(img);
                        setSelectedPresetImages(newSet);
                      }}
                      className="aspect-square rounded-lg overflow-hidden ring-2 ring-green-400"
                    >
                      <img src={img} alt="" className="w-full h-full object-contain bg-white" />
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowPresetPicker(false);
                  setSelectedPresetImages(new Set());
                }}
                className="bg-zinc-700 hover:bg-zinc-600 text-white px-5 py-3 rounded-xl transition-colors duration-150"
              >
                Отмена
              </button>
              <button
                onClick={applyPresetSelection}
                className="flex-1 bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-xl transition-colors duration-150"
                disabled={selectedPresetImages.size === 0}
              >
                ✓ Применить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
