# Исправление багов редактора пиксель-арта

## БАГ 4 — Пиксель-арт размыт

### Проблема
Пиксели отображались размытыми из-за включённого сглаживания в canvas.

### Решение
Добавлено отключение сглаживания во всех местах:

**1. В редакторе (PixelEditor.tsx):**
```typescript
useEffect(() => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  
  // Отключаем сглаживание для резких пикселей
  ctx.imageSmoothingEnabled = false;
  // ...
}, [pixels, gridSize, showGrid]);
```

**2. В CSS (index.css):**
```css
canvas {
  image-rendering: pixelated;
  image-rendering: crisp-edges;
}

img.pixel-art {
  image-rendering: pixelated;
  image-rendering: crisp-edges;
}
```

**3. Во всех игровых движках:**
- `digitsEngine.ts` - метод `render()`
- `engine.ts` - метод `render()`
- `puzzleEngine.ts` - метод `render()`
- `mathEngine.ts` - метод `render()`

```typescript
private render(): void {
  const ctx = this.ctx;
  
  // Отключаем сглаживание для резких пикселей
  ctx.imageSmoothingEnabled = false;
  // ...
}
```

### Результат
Пиксели теперь отображаются чётко, без размытия, во всех режимах игры и в редакторе.

---

## БАГ 6 — Сохраняет в разные пресеты

### Проблема
Каждое сохранение создавало новый пресет вместо добавления в существующий.

### Решение
Переделана модалка сохранения с двумя режимами:

**1. Добавлены состояния:**
```typescript
const [saveMode, setSaveMode] = useState<'existing' | 'new'>('existing');
const [selectedPresetId, setSelectedPresetId] = useState<string>('');
```

**2. Новая модалка с радио-кнопками:**
```tsx
{/* Режим 1: Добавить в существующий пресет */}
{emojiPresets.length > 0 && (
  <div>
    <label className="flex items-center gap-2 text-white text-sm mb-2">
      <input
        type="radio"
        checked={saveMode === 'existing'}
        onChange={() => setSaveMode('existing')}
      />
      Добавить в существующий пресет:
    </label>
    <select
      value={selectedPresetId}
      onChange={(e) => setSelectedPresetId(e.target.value)}
      disabled={saveMode !== 'existing'}
    >
      <option value="">Выберите пресет...</option>
      {emojiPresets.map(preset => (
        <option key={preset.id} value={preset.id}>
          {preset.name} ({preset.emojis.length} картинок)
        </option>
      ))}
    </select>
  </div>
)}

{/* Режим 2: Создать новый пресет */}
<div>
  <label className="flex items-center gap-2 text-white text-sm mb-2">
    <input
      type="radio"
      checked={saveMode === 'new'}
      onChange={() => setSaveMode('new')}
    />
    Создать новый пресет:
  </label>
  <input
    type="text"
    value={newPresetName}
    onChange={(e) => setNewPresetName(e.target.value)}
    disabled={saveMode !== 'new'}
  />
</div>
```

**3. Обновлена функция saveToPreset:**
```typescript
const saveToPreset = async () => {
  let updatedPresets = [...emojiPresets];

  if (saveMode === 'existing' && selectedPresetId) {
    // Добавляем в существующий пресет
    const presetIndex = updatedPresets.findIndex(p => p.id === selectedPresetId);
    if (presetIndex !== -1) {
      updatedPresets[presetIndex] = {
        ...updatedPresets[presetIndex],
        emojis: [...updatedPresets[presetIndex].emojis, dataURL],
      };
    }
  } else if (saveMode === 'new' && newPresetName.trim()) {
    // Создаём новый пресет
    const newPreset: EmojiPreset = {
      id: `preset_${Date.now()}`,
      name: newPresetName.trim(),
      emojis: [dataURL],
      createdAt: Date.now(),
    };
    updatedPresets.push(newPreset);
  }

  setEmojiPresets(updatedPresets);
  await saveEmojiPresets(updatedPresets);
};
```

**4. Инициализация режима по умолчанию:**
```typescript
<button
  onClick={() => {
    setShowSaveModal(true);
    // Если есть пресеты - выбираем режим "existing"
    setSaveMode(emojiPresets.length > 0 ? 'existing' : 'new');
    if (emojiPresets.length > 0) {
      setSelectedPresetId(emojiPresets[0].id);
    }
  }}
>
  💾
</button>
```

### Результат
Теперь можно:
- Добавлять картинки в существующий пресет (выбор из списка)
- Создавать новый пресет (ввод имени)
- По умолчанию выбирается режим "existing", если есть пресеты

---

## БАГ 7 — Шахматный фон в сохранённой картинке

### Проблема
Шахматный фон (индикатор прозрачности) рисовался прямо на canvas, поэтому попадал в экспортируемые PNG и сохраняемые в пресеты картинки.

### Решение
Шахматный фон теперь отображается только через CSS, а canvas остаётся прозрачным.

**1. Убрано рисование шахматного фона на canvas:**
```typescript
// БЫЛО (неправильно):
if (transparentBg) {
  for (let y = 0; y < gridSize; y++) {
    for (let x = 0; x < gridSize; x++) {
      ctx.fillStyle = (x + y) % 2 === 0 ? '#ffffff' : '#e0e0e0';
      ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
    }
  }
}

// СТАЛО (правильно):
// Canvas остаётся прозрачным, шахматный фон только в CSS
```

**2. Шахматный фон в CSS контейнера:**
```tsx
<div
  className="border-2 border-zinc-600 rounded-lg overflow-hidden"
  style={{
    width: '512px',
    height: '512px',
    backgroundImage: transparentBg
      ? 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)'
      : 'none',
    backgroundSize: '20px 20px',
    backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px',
    backgroundColor: transparentBg ? '#fff' : '#fff',
  }}
>
  <canvas ref={canvasRef} width={512} height={512} />
</div>
```

**3. Обновлена функция saveToPreset:**
```typescript
const saveToPreset = async () => {
  const canvas = document.createElement('canvas');
  canvas.width = gridSize;
  canvas.height = gridSize;
  const ctx = canvas.getContext('2d');
  
  ctx.imageSmoothingEnabled = false;
  
  // Рисуем только пиксели, без шахматного фона
  if (!transparentBg) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  for (let y = 0; y < gridSize; y++) {
    for (let x = 0; x < gridSize; x++) {
      if (pixels[y][x]) {
        ctx.fillStyle = pixels[y][x]!;
        ctx.fillRect(x, y, 1, 1);
      }
    }
  }

  const dataURL = canvas.toDataURL('image/png');
  // ...
};
```

### Результат
- Шахматный фон виден только в редакторе как индикатор прозрачности
- Экспортируемые PNG имеют прозрачный фон (если выбран transparentBg)
- Сохраняемые в пресеты картинки не содержат шахматный фон

---

## Дополнительные улучшения

### Добавлен класс pixel-art для img элементов
```css
img.pixel-art {
  image-rendering: pixelated;
  image-rendering: crisp-edges;
}
```

Этот класс можно добавлять к img элементам, которые отображают пиксельные изображения из пресетов.

---

## Проверка

### БАГ 4:
1. Откройте редактор
2. Нарисуйте несколько пикселей
3. Пиксели должны быть чёткими, без размытия
4. Экспортируйте PNG - пиксели должны оставаться чёткими

### БАГ 6:
1. Создайте пресет "Тест1" с одной картинкой
2. Нарисуйте вторую картинку
3. Нажмите 💾
4. Выберите "Добавить в существующий пресет"
5. Выберите "Тест1" из списка
6. Нажмите "Сохранить"
7. В списке пресетов "Тест1" должен содержать 2 картинки

### БАГ 7:
1. Нарисуйте картинку с прозрачным фоном
2. Экспортируйте PNG
3. Откройте PNG в графическом редакторе
4. Фон должен быть прозрачным, без шахматного паттерна
5. Сохраните в пресет
6. Используйте картинку в игре - фон должен быть прозрачным

---

## Размер бандла

- До: 262.82 kB (gzip: 70.53 kB)
- После: 264.05 kB (gzip: 70.82 kB)
- Увеличение: +1.23 kB (+0.29 kB gzip)

Минимальное увеличение из-за добавления новой логики в модалку сохранения.

---

## Файлы изменены

1. `src/components/PixelEditor.tsx` - исправлены все три бага
2. `src/index.css` - добавлены CSS правила для pixelated rendering
3. `src/game/digitsEngine.ts` - добавлено imageSmoothingEnabled = false
4. `src/game/engine.ts` - добавлено imageSmoothingEnabled = false
5. `src/game/puzzleEngine.ts` - добавлено imageSmoothingEnabled = false
6. `src/game/mathEngine.ts` - добавлено imageSmoothingEnabled = false

---

## Заключение

Все три бага успешно исправлены:
- ✅ Пиксель-арт теперь резкий без размытия
- ✅ Можно сохранять в существующий пресет или создавать новый
- ✅ Шахматный фон не попадает в экспортируемые картинки

Редактор пиксель-арта полностью функционален и готов к использованию.
